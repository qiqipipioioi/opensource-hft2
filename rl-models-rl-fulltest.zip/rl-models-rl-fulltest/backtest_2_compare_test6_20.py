import numpy as np
import pandas as pd
from args import args
import datetime
import matplotlib.dates as dates
import matplotlib.pyplot as plt
from numba import jit
import wandb
np.set_printoptions(threshold=200)

wandb.init(project="stock_prediction", entity="zhouuxx96")

def genflist(date_list):
    print(date_list)
    start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
    print(start_month, start_day, end_month, end_day)
    start = datetime.date(2022,start_month,start_day)
    end = datetime.date(2022,end_month,end_day)
    x_l = []
    print(start, end)
    for i in range((end-start).days+1):
        day = start + datetime.timedelta(days=i)
        month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
        day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
        x_l.append(month_str+'_'+day_str)
    return x_l

flist = genflist(args.test[0])
print(flist)
filename = "fu"
data = pd.DataFrame()
first = True
tmp_lst = []
for file in flist:
    if args.test[0] == "09_26-11_01" and file == "10_26":
        continue
    tmp = pd.read_pickle('data_6/data_'+file+'.pkl')
    tmp = pd.DataFrame(tmp, columns=['mid_fu', "predict1", 'ap1_fu', 'bp1_fu', 'sellpriceT_'+filename, 'buypriceT_'+filename])
    tmp_lst.append(tmp)
data = pd.concat(tmp_lst)
ts = pd.Timestamp(2022, 11, 19, 22, 9, 13)
start = (data.index > ts).nonzero()[0][0]
print(data.index[start:start+100])
ts = pd.Timestamp(2022, 11, 20, 4, 9, 16)
end = (data.index > ts).nonzero()[0][0]
print(data.index[end:end+100])
dout = 4
import os
data = data.iloc[start:end]
data['mid_fu'] = data['ap1_fu']/2+data['bp1_fu']/2
from influxdb import DataFrameClient
client = DataFrameClient('***.***.***.***', 8086, 'xz', 'xzquant2022', 'signal')
result = client.query("SELECT * FROM \"model\" WHERE exchange='fu' AND pair='ETHUSDT' AND  type='transformer' AND account='mk2' AND time >= 1668895753000ms and time <= 1668917356000ms;")
result['model'].index.name='time'
raw2 = result['model'].reset_index(level=0)
raw2['time'] = pd.to_datetime(raw2['time']).dt.tz_localize(None)
raw2 = raw2.set_index('time')
del result['model']
print("raw", raw2)
print("data", data)
data['predict1'] = pd.DataFrame(raw2['y0'].to_numpy(), index = data.index)

buy_price = data['bp1_'+filename].to_numpy()*(1-4/1e4)
buy_price *= (1+np.clip(4*data['predict1'].to_numpy()/1e4, -20/1e4, 0))

data['buy_init'] = pd.DataFrame(buy_price, index = data.index)

if args.wandb:
    i= 0
    for i in range(1, int(len(data[['buy_init']])//1e5)):
        print((i-1)*int(1e5), i*int(1e5))
        client.write_points(data[['buy_init']][(i-1)*int(1e5):i*int(1e5)], "backtest_buy_init", {})
    print(i*int(1e5), len(data[['buy_init']]))

    client.write_points(data[['buy_init']][i*int(1e5):], "backtest_buy_init", {})
    i= 0

    tpb = data['sellpriceT_'+filename][1:].to_numpy()
    print("why ---------------------",tpb )
    tpb = np.concatenate([tpb, np.zeros(1)], axis=0)
    data['sellpriceT_fu_1'] = pd.DataFrame(tpb, index = data.index)

    for i in range(1, int(len(data[['sellpriceT_fu_1']])//1e5)):
        print((i-1)*int(1e5), i*int(1e5))
        client.write_points(data[['sellpriceT_fu_1']][(i-1)*int(1e5):i*int(1e5)], "sellpriceT_fu_1", {})
    print(i*int(1e5), len(data[['sellpriceT_fu_1']]))

    client.write_points(data[['sellpriceT_fu_1']][i*int(1e5):], "sellpriceT_fu_1", {})

    tpb = data['sellpriceT_'+filename][2:].to_numpy()
    tpb = np.concatenate([tpb, np.zeros(2)], axis=0)
    data['sellpriceT_fu_2'] = pd.DataFrame(tpb, index = data.index)

    for i in range(1, int(len(data[['sellpriceT_fu_2']])//1e5)):
        print((i-1)*int(1e5), i*int(1e5))
        client.write_points(data[['sellpriceT_fu_2']][(i-1)*int(1e5):i*int(1e5)], "sellpriceT_fu_2", {})
    print(i*int(1e5), len(data[['sellpriceT_fu_2']]))

    client.write_points(data[['sellpriceT_fu_2']][i*int(1e5):], "sellpriceT_fu_2", {})
 
def backtest_11():
    data['mid_fu'] = data['ap1_fu']/2+data['bp1_fu']/2
    max_p = np.max(data['mid_fu'].to_numpy())
    print(max_p)
    max_p = 1625.985
    p1='predict1'
    filename='fu'
    profit_b_all, profit_s_all = np.zeros((len(data), 7)), np.zeros((len(data), 7))
    data_p1 = data[p1].to_numpy()
    sum_m12 = {}
    p_d_sum_buy = {1:{i:0 for i in range(0, 6)}, 5:{i:0 for i in range(0, 6)}}
    p_d_sum_sell = {1:{i:0 for i in range(0, 6)}, 5:{i:0 for i in range(0, 6)}}
    thres = 0.00
    for dout in [4]:
        for m1 in [2]:
            for m2 in [4]:
                for lag, lag2 in [(1, 1), (2, 2)]:
                    print("-----------", dout, m1, m2, lag, lag2, "---------------")
                    sell_price = data['ap1_'+filename].to_numpy()*(1+dout/1e4)
                    sell_price *= (1+np.clip(m1*data[p1].to_numpy()/1e4, 0, 20/1e4))
                    data['sell_init'] = pd.DataFrame(sell_price, index = data.index)

                    i= 0
                    for i in range(1, int(len(data[['sell_init']])//1e5)):
                        print((i-1)*int(1e5), i*int(1e5))
                    client.write_points(data[['sell_init']][(i-1)*int(1e5):i*int(1e5)], "sell_init", {})
                    print(i*int(1e5), len(data[['sell_init']]))
                    client.write_points(data[['sell_init']][i*int(1e5):], "sell_init", {})

                    tp = data['buypriceT_'+filename][lag2:].to_numpy()
                    tp = np.concatenate([tp, np.zeros(lag2)], axis=0)
                    profit_b = np.zeros((len(data), 7))
                    valid_sellpoint = (np.logical_and(tp >= sell_price+thres, tp != 0)).nonzero()[0]

                    data['buypriceT_fu'+str(lag2)] = pd.DataFrame(tp, index = data.index)

                    for i in range(1, int(len(data[['buypriceT_fu'+str(lag2)]])//1e5)):
                        print((i-1)*int(1e5), i*int(1e5))
                        client.write_points(data[['buypriceT_fu'+str(lag2)]][(i-1)*int(1e5):i*int(1e5)], 'buypriceT_fu'+str(lag2), {})
                    print(i*int(1e5), len(data[['buypriceT_fu'+str(lag2)]]))

                    client.write_points(data[['buypriceT_fu'+str(lag2)]][i*int(1e5):], 'buypriceT_fu'+str(lag2), {})

                    datawritten = data.iloc[valid_sellpoint]
                    print(datawritten)
                    print(len(valid_sellpoint))
                    i= 0
                    for i in range(1, int(len(datawritten[['sell_init']])//1e5)):
                        print((i-1)*int(1e5), i*int(1e5))
                    client.write_points(datawritten[['sell_init']][(i-1)*int(1e5):i*int(1e5)], "backtest_sell_init_filled_lag"+str(lag), {})
                    print(i*int(1e5), len(datawritten[['sell_init']]))
                    client.write_points(datawritten[['sell_init']][i*int(1e5):], "backtest_sell_init_filled_lag"+str(lag), {})
                    valid_sellprice = np.zeros(len(data))
                    valid_sellprice_index = np.zeros(len(data))
                    start, end = 0, 0
                    for i in range(len(valid_sellpoint)):
                        end = valid_sellpoint[i].astype(int)
                        valid_sellprice[start:end-lag2+1] = sell_price[end]
                        valid_sellprice_index[start:end-lag2+1] = i
                        start = end-lag2+1
                    buckets = [[] for i in range(len(valid_sellpoint))]
                    buy_price_base = data['bp1_'+filename].to_numpy()*(1+np.clip(m2*data[p1].to_numpy()/1e4, -20/1e4, 0))
                    tpb = data['sellpriceT_'+filename][lag:].to_numpy()
                    tpb = np.concatenate([tpb, np.zeros(lag)], axis=0)
                    p = data['predict1'].to_numpy()
                    for d in range(0, 6):
                        buy_price = data['bp1_'+filename].to_numpy()*(1-d/1e4)
                        buy_price *= (1+np.clip(m2*data[p1].to_numpy()/1e4, -20/1e4, 0))
                        valid_buypoint = (np.logical_and(tpb <= buy_price-thres, tpb != 0)).nonzero()[0]
                        datawritten = data.iloc[valid_buypoint]
                        if d == 4:
                            print(datawritten)
                            print(len(valid_buypoint))
                            i= 0
                            for i in range(1, int(len(datawritten[['buy_init']])//1e5)):
                                print((i-1)*int(1e5), i*int(1e5))
                            client.write_points(datawritten[['buy_init']][(i-1)*int(1e5):i*int(1e5)], "backtest_buy_init_filled_lag"+str(lag), {})
                            print(i*int(1e5), len(datawritten[['buy_init']]))
                            client.write_points(datawritten[['buy_init']][i*int(1e5):], "backtest_buy_init_filled_lag"+str(lag), {})
                        if d == 0:
                            valid_buypoint_0 = valid_buypoint
                        for i in range(len(valid_buypoint)):
                            point = valid_buypoint[i]
                            if valid_sellprice[point] != 0:
                                if d == 0:
                                    buckets[valid_sellprice_index[point].astype(int)].append(point)
                                profit_b[point, d] = (valid_sellprice[point]-buy_price[point] + 0.4/1e4*(buy_price[point]+valid_sellprice[point]))/max_p
                    print("valid_sellpoint", valid_sellpoint, len(valid_sellpoint))
                    print("valid_buypoint", valid_buypoint_0, len(valid_buypoint_0))
                    nonemptybuckets = []
                    for i in range(len(buckets)):
                        if len(buckets[i]) != 0:
                            nonemptybuckets.append(buckets[i])
                    p_sum1 = 0
                    lines1 = []
                    for pos in [1, 5]:
                        for din in range(0, 6):
                            p, executed_trades, num_tr = calculate_profit_with_chosen(valid_sellpoint-lag2+1, profit_b[:, din], position=pos, lag=lag, lag2=lag2)
                            if din == 4:
                                executed_trades_0_buy = executed_trades
                            print("with position", pos, din, p, num_tr)
                            p_sum1 += p
                            p_d_sum_buy[pos][din] += p
                    

                    buy_price = data['bp1_'+filename].to_numpy()*(1-dout/1e4)
                    buy_price *= (1+np.clip(m1*data[p1].to_numpy()/1e4, -20/1e4, 0))
                    tp = data['sellpriceT_'+filename][lag2:].to_numpy()
                    tp = np.concatenate([tp, np.zeros(lag2)], axis=0)
                    profit_s = np.zeros((len(data), 7))
                    valid_buypoint = (np.logical_and(tp <= buy_price-thres, tp != 0)).nonzero()[0]
                    valid_buyprice = np.zeros(len(data))
                    valid_buyprice_index = np.zeros(len(data))
                    start, end = 0, 0
                    for i in range(len(valid_buypoint)):
                        end = valid_buypoint[i].astype(int)
                        valid_buyprice[start:end-lag2+1] = buy_price[end]
                        valid_buyprice_index[start:end-lag2+1] = i
                        start = end-lag2+1
                    buckets = [[] for i in range(len(valid_buypoint))]
                    sell_price_base = data['ap1_'+filename].to_numpy()*(1+np.clip(m2*data[p1].to_numpy()/1e4, 0, 20/1e4))
                    tps = data['buypriceT_'+filename][lag:].to_numpy()
                    tps = np.concatenate([tps, np.zeros(lag)], axis=0)

                    for d in range(0, 6):
                        sell_price = data['ap1_'+filename].to_numpy()*(1+d/1e4)
                        sell_price *= (1+np.clip(m2*data[p1].to_numpy()/1e4, 0, 20/1e4))
                        
                        valid_sellpoint = np.logical_and(tps >= sell_price+thres, tps != 0).nonzero()[0]
                        if d == 0:
                            valid_sellpoint_0 = valid_sellpoint
                        for i in range(len(valid_sellpoint)):
                            point = valid_sellpoint[i]
                            if valid_buyprice[point] != 0:
                                if d == 0:
                                    buckets[valid_buyprice_index[point].astype(int)].append(point)
                                profit_s[point, d] = (sell_price[point] - valid_buyprice[point] + 0.4/1e4*(sell_price[point] + valid_buyprice[point]))/max_p
                    print("valid_buypoint", valid_buypoint, len(valid_buypoint))
                    print("valid_sellpoint", valid_sellpoint_0, len(valid_sellpoint_0))
                    nonemptybuckets = []
                    for i in range(len(buckets)):
                        if len(buckets[i]) != 0:
                            nonemptybuckets.append(buckets[i])
                    p_sum2 = 0
                    for pos in [1, 5]:
                        for din in range(0, 6):
                            p, executed_trades, num_tr = calculate_profit_with_chosen(valid_buypoint-lag2+1, profit_s[:, din], position=pos, lag=lag, lag2=lag2)

                            if din == 4:
                                executed_trades_0_sell = executed_trades
                            print("with position", pos, din, p, num_tr)
                            p_sum2 += p
                            p_d_sum_sell[pos][din] += p
    return executed_trades_0_buy, executed_trades_0_sell

@jit
def calculate_profit_with_chosen(valid_sellpoint, chosen_value_total, position=5, lag=1, lag2=1):
    chosen_vt = chosen_value_total
    positions_dict = [0 for i in range(len(valid_sellpoint))]

    valid_buypoint = (chosen_vt != 0).nonzero()[0]
    profit_position = np.zeros(len(chosen_vt))
    def get_loc(vb):
        for i in range(len(valid_sellpoint)):
            if vb < valid_sellpoint[i]:
                return i, False
            if valid_sellpoint[i] <= vb and vb < valid_sellpoint[i] + lag + lag2 -1:
                return i, True

    total_profit = 0
    deferred_positions = [(0, 0)]
    deferred_positions = deferred_positions[1:]
    for vb in valid_buypoint:
        i = 0
        retained_items = []
        for i in range(len(deferred_positions)):
            if vb >= deferred_positions[i][1]:
                positions_dict[deferred_positions[i][0]] += 1
            else:
                retained_items.append(deferred_positions[i])
        deferred_positions = retained_items
        if vb < valid_sellpoint[-1]:
            bin, atpoint = get_loc(vb)
            if not atpoint:
                if positions_dict[bin] < position:
                    total_profit += chosen_vt[vb]
                    profit_position[vb] = chosen_vt[vb]
                    deferred_positions.append((bin, vb + lag))
            else:
                if positions_dict[bin+1] < position:
                    total_profit += chosen_vt[vb]
                    profit_position[vb] = chosen_vt[vb]
                    deferred_positions.append((bin, vb + lag))
                    deferred_positions.append((bin+1, vb + lag))
        else:
            print(vb, valid_sellpoint[-1], valid_sellpoint)
            print("why larger")
    return total_profit, profit_position, sum(positions_dict)
 
backtest_11()
