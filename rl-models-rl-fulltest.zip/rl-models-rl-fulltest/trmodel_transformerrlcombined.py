import torch
import models
from args import args
args.temp = 1

# model = torch.load("best_model_y"+args.arch+args.y+"_"+';'.join(args.train)+"_"+';'.join(args.test)+str(args.seed)+".pt")
model = torch.load("results/best_model_RLTSTransformerEncoderRLCombined_08_11-09_15_09_16-09_254125641808.pt")
model.eval()
model.cpu()
input = torch.ones(1, args.input_size, args.T)
traced_script_module = torch.jit.trace(model, input)
print(model(input), model(input).size())
# traced_script_module.save("best_model_y"+args.arch+args.y+"_"+";".join(args.train)+"_"+";".join(args.test)+str(args.seed)+"script.pt")
traced_script_module.save("results_new_2/best_model_RLTSTransformerEncoderRLCombined_08_11-09_15_09_16-09_254125641808_script.pt")


m1 = model.m1
model.cpu()
input = torch.ones(1, args.input_size, args.T)
traced_script_modulem1 = torch.jit.trace(m1, input)
traced_script_modulem1.save("results_new_2/best_model_RLTSTransformerEncoderRLCombinedbuy_08_11-09_15_09_16-09_254125641808_script.pt")


m2 = model.m2
model.cpu()
input = torch.ones(1, args.input_size, args.T)
traced_script_modulem2 = torch.jit.trace(m2, input)
traced_script_modulem2.save("results_new_2/best_model_RLTSTransformerEncoderRLCombinedsell_08_11-09_15_09_16-09_254125641808_script.pt")