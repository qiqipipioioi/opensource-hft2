import pandas as pd
import numpy as np
from args import args
import datetime
# def tr(loc):
#     a = pd.read_pickle(loc)
#     c = a.to_numpy()
#     with open(loc[:-4]+".npy", 'wb') as f:
#         np.save(f, c)
# tr("data_4/xnn_05_24.pkl")
# tr("data_4/xnn_05_25.pkl")
# tr("data_4/xnn_05_26.pkl")
# tr("data_4/xnn_05_27.pkl")
# tr("data_4/xnn_05_28.pkl")
# tr("data_4/xnn_05_29.pkl")
# tr("data_4/xnn_05_30.pkl")
# tr("data_4/xnn_05_31.pkl")

def tr_data(date_list, tp, old=2):
    start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
    print(start_month, start_day, end_month, end_day)
    start = datetime.date(2022,start_month,start_day)
    if end_month < start_month:
        year = 2023
    else:
        year = 2022
    end = datetime.date(year,end_month,end_day)
    x_l = []
    print(start, end)
    for i in range((end-start).days+1):
        day = start + datetime.timedelta(days=i)
        print(day, day.month, day.day)
        month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
        day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
        loc = 'data_6/'+tp+'_'+month_str+'_'+day_str+'.pkl'
        a = pd.read_pickle(loc)
        print(a.shape)
        # print(a.iloc[829611+73])

        c = a.to_numpy()
        if old == 4:
            with open('data_6/'+"xnn3"+'_'+month_str+'_'+day_str+'.npy', 'wb') as f:
                np.save(f, c)
            with open('data_6/'+"xnn"+'_'+month_str+'_'+day_str+'.npy', 'wb') as f:
                np.save(f, c)
        elif old == 1:
            with open('data_6/'+"xnn3"+'_'+month_str+'_'+day_str+'.npy', 'wb') as f:
                np.save(f, c)
            with open('data_6/'+"xnn"+'_'+month_str+'_'+day_str+'.npy', 'wb') as f:
                np.save(f, c)
        elif old == 3:
            with open('data_6/'+"xnn3"+'_'+month_str+'_'+day_str+'.npy', 'wb') as f:
                np.save(f, c)
        elif old == 2:
            with open('data_6/'+"xnn"+'_'+month_str+'_'+day_str+'.npy', 'wb') as f:
                np.save(f, c)
        elif old == 5:
            with open('data_6/'+"xnn4"+'_'+month_str+'_'+day_str+'.npy', 'wb') as f:
                np.save(f, c)
        elif old == 6:
            with open('data_6/'+"xnn4"+'_'+month_str+'_'+day_str+'.npy', 'wb') as f:
                np.save(f, c)
            with open('data_6/'+"xnn"+'_'+month_str+'_'+day_str+'.npy', 'wb') as f:
                np.save(f, c)
        elif old == 7:
            with open('data_6/'+"xnn5"+'_'+month_str+'_'+day_str+'.npy', 'wb') as f:
                np.save(f, c)
        elif old == 8:
            with open('data_6/'+"xnn6"+'_'+month_str+'_'+day_str+'.npy', 'wb') as f:
                np.save(f, c)
if args.old == 1:
    tr_data(args.train[0], "xnn2", 1)
elif args.old == 2:
    tr_data(args.train[0], "xnn2", 2)
elif args.old == 3:
    tr_data(args.train[0], "xnn3", 3)
elif args.old == 4:
    tr_data(args.train[0], "xnn3", 4)
elif args.old == 5:
    tr_data(args.train[0], "xnn4", 5)
elif args.old == 6:
    tr_data(args.train[0], "xnn4", 6)
elif args.old == 7:
    tr_data(args.train[0], "xnn5", 7)
elif args.old == 8:
    tr_data(args.train[0], "xnn6", 8)
