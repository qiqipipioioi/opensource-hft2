source ~/.bashrc

conda activate python38
python backtest_2_compare_test6_19_4.py  --test 11_19-12_07 --profit_type 19 --seed 8313747812    

python backtest_2_compare_test6_19_4.py  --test 10_27-11_08 --profit_type 19 --seed 8313747812    

python backtest_2_compare_test6_19_4.py  --test 08_11-10_20 --profit_type 19 --seed 8313747812    

python backtest_2_compare_test6_19_4.py  --test 10_21-10_25 --profit_type 19 --seed 8313747812    
