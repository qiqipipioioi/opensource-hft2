import numpy as np
import pandas as pd
from args import args
import datetime
import matplotlib.dates as dates
import matplotlib.pyplot as plt


def genflist(date_list):
    print(date_list)
    start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
    print(start_month, start_day, end_month, end_day)
    start = datetime.date(2022,start_month,start_day)
    end = datetime.date(2022,end_month,end_day)
    x_l = []
    print(start, end)
    for i in range((end-start).days+1):
        day = start + datetime.timedelta(days=i)
        month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
        day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
        x_l.append(month_str+'_'+day_str)
    return x_l

print(args.test, "???")
flist = genflist(args.test[0])
print(flist)
filename = "fu"
data = pd.DataFrame()

first = True
for file in flist:
    if first:
        data = pd.read_pickle('data_6/data_'+file+'.pkl')
        print(data['sellprice_'+filename])
        print(data['sellpriceT_'+filename])
        print(data.shape)
        first = False
        with open('data_6/y_'+file+'.npy', 'rb') as f:
            y_true = np.load(f)
    else:
        tmp = pd.read_pickle('data_6/data_'+file+'.pkl')
        print(data['sellprice_'+filename])
        print(data['sellpriceT_'+filename])
        print(tmp.shape)
        data = pd.concat([data, tmp])

        with open('data_6/y_'+file+'.npy', 'rb') as f:
            tmp = np.load(f)
        y_true = np.concatenate((y_true, tmp), axis=0)

with open("data_7/y0_"+args.arch+"_"+";".join(args.train)+"_"+";".join(args.valid)+"_"+";".join(args.test)+str(args.rand_number0)+".npy", 'rb') as f:
    y_predict0 = np.load(f)
# y_predict0 = np.concatenate((np.zeros(4), y_predict0), axis=0)

if args.double_test:
    with open("data_7/y0_"+args.arch+"_"+";".join(args.train3)+"_"+";".join(args.valid3)+"_"+";".join(args.test)+str(args.rand_number3)+".npy", 'rb') as f:
        y_predict1 = np.load(f)
timepoint = 200000000
def backtest(a, b, d, y, type):
    state = 'empty'
    total_profit = 0
    cnt = 0
    takercnt = 0

    data['mid_fu'] = data['ap1_fu']/2+data['bp1_fu']/2
    data['predict1']=pd.DataFrame(y, index = data.index)

    p1='predict1'

    resl = []
    lag = 0 
    filename='fu'
    for i in range(0, len(data)-1-lag):
        if state == 'empty':
            buy_price = data['bp1_'+filename][i]*(1-d/1e4)
            if type == "predict":
                buy_price *= (1+np.clip(4*(data[p1][i]-0.0)/1e4, -20/1e4, 0/1e4))
            tpb = data['sellpriceT_'+filename][i+1]
            if tpb <= buy_price-0.01 and tpb != 0:
                state = 'buy'
                total_profit += 0.4/1e4
                continue
            sell_price = data['ap1_'+filename][i]*(1+d/1e4)
            if type == "predict":
                sell_price *= (1+np.clip(4*(data[p1][i]+0.0)/1e4,-0/1e4, 20/1e4))
            tps = data['buypriceT_'+filename][i+1]
            if tps >= sell_price+0.01 and tps != 0:
                state = 'sell'
                total_profit += 0.4/1e4
                continue
        
        if state == 'buy' and data[p1][i] < -b:
            sell_price = data['bp1_fu'][i+5]*(1.0)
            state = 'empty'
            total_profit += sell_price / buy_price - 1 - 2/1e4
            cnt += 1
            takercnt += 1
            resl.append((data.index[i], total_profit))
            continue

        if state == 'sell' and data[p1][i] > b:
            buy_price = data['ap1_fu'][i+5]*(1.0)
            state = 'empty'
            total_profit += sell_price / buy_price - 1 - 2/1e4
            cnt += 1
            takercnt += 1
            resl.append((data.index[i], total_profit))
            continue
        
        if state == 'buy':
            sell_price = data['ap1_'+filename][i]*(1+d/1e4)
            if type == "predict":
                sell_price *= (1+np.clip(2*(data[p1][i]+0.0)/1e4,-0/1e4, 20/1e4))
            tp = data['buypriceT_'+filename][i+1]
            if tp >= sell_price+0.01 and tp != 0:
                state = 'empty'
                total_profit += sell_price / buy_price - 1 + 0.4/1e4
                resl.append((data.index[i], total_profit))
                cnt += 1
                continue
        
        if state == 'sell':
            buy_price = data['bp1_'+filename][i]*(1-d/1e4)
            if type == "predict":
                buy_price *= (1+np.clip(2*(data[p1][i]-0.0)/1e4, -20/1e4, 0/1e4))
            tp = data['sellpriceT_'+filename][i+1]
            if tp <= buy_price-0.01 and tp != 0:
                state = 'empty'
                total_profit += sell_price / buy_price - 1 + 0.4/1e4
                cnt += 1
                resl.append((data.index[i], total_profit))
            continue

        # if i > 2000000:
            # break
    print(total_profit, cnt, takercnt)
    return total_profit, cnt, takercnt, resl

def add_vol(l, i):
    l[i][1] += 1

def backtest_2(a, b, d, y, type, thres, thres2=0):
    total_profit = 0
    cnt = 0
    takercnt = 0

    data['mid_fu'] = data['ap1_fu']/2+data['bp1_fu']/2
    data['predict1']=pd.DataFrame(y, index = data.index)

    p1='predict1'

    resl = []
    lag = 0 
    filename='fu'
    volume_buy = [[data.index[i], 0] for i in range(len(data))]
    volume_sell = [[data.index[i], 0] for i in range(len(data))]
    occupy_buy = [0 for i in range(len(data))]
    occupy_sell = [0 for i in range(len(data))]

    for i in range(0, len(data)-1-lag):
        buy_price = data['bp1_'+filename][i]*(1-d/1e4)
        if type == "predict":
            buy_price *= (1+np.clip(4*(data[p1][i]-0.0)/1e4, -20/1e4, 0/1e4))
        tpb = data['sellpriceT_'+filename][i+1]
        profit = 0
        if volume_buy[i][1] - volume_sell[i][1] < thres:
            if tpb <= buy_price-0.01 and tpb != 0:
                profit += 0.4/1e4
                j = i
                add_vol(volume_buy, j)
                while(True):
                    j += 1
                    add_vol(volume_buy, j)
                    if occupy_buy[j] > thres2:
                        continue
                    if j+5 >= len(data):
                        profit = 0
                        break
                    if data[p1][j] < -b:
                        sell_price = data['bp1_fu'][j+5]*(1.0)
                        profit += sell_price / buy_price - 1 - 2/1e4
                        occupy_buy[j] += 1
                        break
                    sell_price = data['ap1_'+filename][j]*(1+d/1e4)
                    if type == "predict":
                        sell_price *= (1+np.clip(2*(data[p1][j]+0.0)/1e4,-0/1e4, 20/1e4))
                    tp = data['buypriceT_'+filename][j+1]
                    if tp >= sell_price+0.01 and tp != 0:
                        profit += sell_price / buy_price - 1 + 0.4/1e4
                        occupy_buy[j] += 1
                        break
                total_profit += profit

        sell_price = data['ap1_'+filename][i]*(1+d/1e4)
        if type == "predict":
            sell_price *= (1+np.clip(4*(data[p1][i]+0.0)/1e4,-0/1e4, 20/1e4))
        tps = data['buypriceT_'+filename][i+1]
        profit = 0
        if volume_buy[i][1] - volume_sell[i][1] > -thres:
            if tps >= sell_price+0.01 and tps != 0:
                profit += 0.4/1e4
                j = i
                add_vol(volume_sell, j)
                while(True):
                    j += 1
                    add_vol(volume_sell, j)
                    if occupy_sell[j] > thres2:
                        continue
                    if j+5 >= len(data):
                        profit = 0
                        break
                    if data[p1][j] > b:
                        buy_price = data['ap1_fu'][j+5]*(1.0)
                        profit += sell_price / buy_price - 1 - 2/1e4
                        occupy_sell[j] += 1
                        break

                    buy_price = data['bp1_'+filename][j]*(1-d/1e4)
                    if type == "predict":
                        buy_price *= (1+np.clip(2*(data[p1][j]-0.0)/1e4, -20/1e4, 0/1e4))
                    tp = data['sellpriceT_'+filename][j+1]
                    if tp <= buy_price-0.01 and tp != 0:
                        profit += sell_price / buy_price - 1 + 0.4/1e4
                        occupy_sell[j] += 1
                        break
                total_profit += profit
            resl.append((data.index[i], total_profit))
        
        if i > timepoint: 
            break
    print(total_profit, cnt, takercnt)
    return total_profit, cnt, takercnt, resl, volume_buy, volume_sell



def backtest_3(a, b, d, y, type, thres, thres2=0):
    total_profit = 0
    cnt = 0
    takercnt = 0

    data['mid_fu'] = data['ap1_fu']/2+data['bp1_fu']/2
    data['predict1']=pd.DataFrame(y, index = data.index)

    p1='predict1'
    resl = []
    lag = 0 
    filename='fu'
    buy_prices = []
    sell_prices = []
    volume_buy = [0]
    volume_sell = [0] 
    occupy_buy = [0 for i in range(len(data))]
    occupy_sell = [0 for i in range(len(data))]
    
    def buy_logic(buy_prices, volume_buy, volume_sell):
        delta_profit = 0
        if volume_buy[0] - volume_sell[0] <= thres:
            buy_price = data['bp1_'+filename][i]*(1-d/1e4)
            if type == "predict":
                buy_price *= (1+np.clip(4*(data[p1][i]-0.0)/1e4, -20/1e4, 0/1e4))
            tpb = data['sellpriceT_'+filename][i+1]
            if tpb <= buy_price-0.01 and tpb != 0:
                volume_buy[0] += 1
                delta_profit += 0.4/1e4
                buy_prices.append(buy_price)
                return delta_profit, buy_prices
        if data[p1][i] < -b:
            sell_price = data['bp1_fu'][i+5]*(1.0)
            volume_buy[0] -= len(buy_prices)
            for k in range(len(buy_prices)):
                delta_profit += sell_price / buy_prices[k] - 1 - 2/1e4
            buy_prices = []
            return delta_profit, buy_prices
        sell_price = data['ap1_'+filename][i]*(1+d/1e4)
        if type == "predict":
            sell_price *= (1+np.clip(2*(data[p1][i]+0.0)/1e4,-0/1e4, 20/1e4))
        tp = data['buypriceT_'+filename][i+1]
        if tp >= sell_price+0.01 and tp != 0:
            volume_buy[0] -= len(buy_prices)
            for k in range(len(buy_prices)):
                delta_profit += sell_price / buy_prices[k] - 1 + 0.4/1e4
            buy_prices = []
            return delta_profit, buy_prices
        return delta_profit, buy_prices

    def sell_logic(sell_prices, volume_buy, volume_sell):
        delta_profit = 0
        if volume_buy[0] - volume_sell[0] >= -thres:
            sell_price = data['ap1_'+filename][i]*(1+d/1e4)
            if type == "predict":
                sell_price *= (1+np.clip(4*(data[p1][i]+0.0)/1e4,-0/1e4, 20/1e4))
            tps = data['buypriceT_'+filename][i+1]
            if tps >= sell_price+0.01 and tps != 0:
                volume_sell[0] += 1
                delta_profit += 0.4/1e4
                sell_prices.append(sell_price)
                return delta_profit, sell_prices
        if data[p1][i] > b:
            buy_price = data['ap1_fu'][i+5]*(1.0)
            volume_sell[0] -= len(sell_prices)
            for k in range(len(sell_prices)):
                delta_profit += sell_prices[k] / buy_price - 1 - 2/1e4
            sell_prices = []
            return delta_profit, sell_prices
        buy_price = data['bp1_'+filename][i]*(1-d/1e4)
        if type == "predict":
            buy_price *= (1+np.clip(2*(data[p1][i]-0.0)/1e4, -20/1e4, 0/1e4))
        tp = data['sellpriceT_'+filename][i+1]
        if tp <= buy_price-0.01 and tp != 0:
            volume_sell[0] -= len(sell_prices)
            for k in range(len(sell_prices)):
                delta_profit += sell_prices[k] / buy_price - 1 + 0.4/1e4
            sell_prices = []
            return delta_profit, sell_prices
        return delta_profit, sell_prices


    for i in range(0, len(data)-1-lag):
        if i+5 >= len(data):
            total_profit -= 0.4/1e4 * (len(buy_prices)+len(sell_prices))
            break
        # print(buy_prices, sell_prices, total_profit)
        delta_profit, buy_prices = buy_logic(buy_prices, volume_buy, volume_sell)
        total_profit += delta_profit
        # print(buy_prices, sell_prices, total_profit)
        delta_profit, sell_prices = sell_logic(sell_prices, volume_buy, volume_sell)
        total_profit += delta_profit
        resl.append((data.index[i], total_profit))
        if i > timepoint: 
            break
    print(total_profit, cnt, takercnt)
    return total_profit, cnt, takercnt, resl, volume_buy, volume_sell



def backtest_6(a, b, d, y, type, thres, thres2=0):
    total_profit = 0
    cnt = 0
    takercnt = 0

    data['mid_fu'] = data['ap1_fu']/2+data['bp1_fu']/2
    data['predict1']=pd.DataFrame(y, index = data.index)

    p1='predict1'
    resl = []
    lag = 0 
    filename='fu'
    buy_prices = []
    sell_prices = []
    volume_buy = [0]
    volume_sell = [0] 
    
    def buy_logic(buy_prices, volume_buy, volume_sel, buy_closed):
        delta_profit = 0
        if data[p1][i] < -b:
            sell_price = data['bp1_fu'][i+5]*(1.0)
            volume_buy[0] -= len(buy_prices)
            for k in range(len(buy_prices)):
                delta_profit += sell_price / buy_prices[k] - 1 - 2/1e4
            buy_prices = []
            # return delta_profit, buy_prices
        else:
            sell_price = data['ap1_'+filename][i]*(1+d/1e4)
            if type == "predict":
                sell_price *= (1+np.clip(2*(data[p1][i]+0.0)/1e4,-0/1e4, 20/1e4))
            tp = data['buypriceT_'+filename][i+1]
            if tp >= sell_price+0.01 and tp != 0:
                volume_buy[0] -= len(buy_prices)
                for k in range(len(buy_prices)):
                    delta_profit += sell_price / buy_prices[k] - 1 + 0.4/1e4
                buy_prices = []

        if volume_buy[0] - volume_sell[0] <= thres: #因为买入的现在是不知道买没买的，所以卖不了
            buy_price = data['bp1_'+filename][i]*(1-d/1e4)
            if type == "predict":
                buy_price *= (1+np.clip(4*(data[p1][i]-0.0)/1e4, -20/1e4, 0/1e4))
            tpb = data['sellpriceT_'+filename][i+1]
            if tpb <= buy_price-0.01 and tpb != 0:
                volume_buy[0] += 1
                delta_profit += 0.4/1e4
                buy_prices.append(buy_price)
        return delta_profit, buy_prices

    def sell_logic(buy_prices, sell_prices, volume_buy, volume_sell, sell_closed):
        delta_profit = 0
        if data[p1][i] > b:
            buy_price = data['ap1_fu'][i+5]*(1.0)
            volume_sell[0] -= len(sell_prices)
            for k in range(len(sell_prices)):
                delta_profit += sell_prices[k] / buy_price - 1 - 2/1e4
            sell_prices = []
        else:
            buy_price = data['bp1_'+filename][i]*(1-d/1e4)
            if type == "predict":
                buy_price *= (1+np.clip(2*(data[p1][i]-0.0)/1e4, -20/1e4, 0/1e4))
            tp = data['sellpriceT_'+filename][i+1]
            if tp <= buy_price-0.01 and tp != 0:
                volume_sell[0] -= len(sell_prices)
                for k in range(len(sell_prices)):
                    delta_profit += sell_prices[k] / buy_price - 1 + 0.4/1e4
                sell_prices = []
        if volume_buy[0] - volume_sell[0] >= -thres:
            sell_price = data['ap1_'+filename][i]*(1+d/1e4)
            if type == "predict":
                sell_price *= (1+np.clip(4*(data[p1][i]+0.0)/1e4,-0/1e4, 20/1e4))
            tps = data['buypriceT_'+filename][i+1]
            if tps >= sell_price+0.01 and tps != 0:
                # if len(buy_prices) == 1:
                #     volume_buy[0] -= 1
                #     delta_profit += sell_price / buy_prices[0] - 1 + 0.4/1e4
                # else:
                volume_sell[0] += 1
                delta_profit += 0.4/1e4
                sell_prices.append(sell_price)
        return delta_profit, sell_prices


    for i in range(0, len(data)-1-lag):
        if i+5 >= len(data):
            total_profit -= 0.4/1e4 * (len(buy_prices)+len(sell_prices))
            break

        delta_profit, buy_prices = buy_logic(buy_prices, volume_buy, volume_sell, False)
        total_profit += delta_profit
        delta_profit, sell_prices = sell_logic(buy_prices, sell_prices, volume_buy, volume_sell, False)
        total_profit += delta_profit
        resl.append((data.index[i], total_profit))
        if i > timepoint: 
            break
    print(total_profit, cnt, takercnt)
    return total_profit, cnt, takercnt, resl, volume_buy, volume_sell

def backtest_4(a, b, d, y, type, thres, thres2=0):
    total_profit = 0
    cnt = 0
    takercnt = 0

    data['mid_fu'] = data['ap1_fu']/2+data['bp1_fu']/2
    data['predict1']=pd.DataFrame(y, index = data.index)

    p1='predict1'
    resl = []
    lag = 0 
    filename='fu'
    buy_prices = []
    sell_prices = []
    volume_buy = [0]
    volume_sell = [0] 
    occupy_buy = [0 for i in range(len(data))]
    occupy_sell = [0 for i in range(len(data))]
    
    def buy_logic(buy_prices, volume_buy, volume_sel, buy_closed):
        delta_profit = 0
        if data[p1][i] < -b:
            sell_price = data['bp1_fu'][i+5]*(1.0)
            volume_buy[0] -= len(buy_prices)
            for k in range(len(buy_prices)):
                delta_profit += sell_price / buy_prices[k] - 1 - 2/1e4
            buy_prices = []
            # return delta_profit, buy_prices
        else:
            sell_price = data['ap1_'+filename][i]*(1+d/1e4)
            if type == "predict":
                sell_price *= (1+np.clip(2*(data[p1][i]+0.0)/1e4,-0/1e4, 20/1e4))
            tp = data['buypriceT_'+filename][i+1]
            if tp >= sell_price+0.01 and tp != 0:
                volume_buy[0] -= len(buy_prices)
                for k in range(len(buy_prices)):
                    delta_profit += sell_price / buy_prices[k] - 1 + 0.4/1e4
                buy_prices = []

        if volume_buy[0] - volume_sell[0] <= thres and not buy_closed: #因为买入的现在是不知道买没买的，所以卖不了
            buy_price = data['bp1_'+filename][i]*(1-d/1e4)
            if type == "predict":
                buy_price *= (1+np.clip(4*(data[p1][i]-0.0)/1e4, -20/1e4, 0/1e4))
            tpb = data['sellpriceT_'+filename][i+1]
            if tpb <= buy_price-0.01 and tpb != 0:
                volume_buy[0] += 1
                delta_profit += 0.4/1e4
                buy_prices.append(buy_price)
        return delta_profit, buy_prices

    def sell_logic(buy_prices, sell_prices, volume_buy, volume_sell, sell_closed):
        delta_profit = 0
        if data[p1][i] > b:
            buy_price = data['ap1_fu'][i+5]*(1.0)
            volume_sell[0] -= len(sell_prices)
            for k in range(len(sell_prices)):
                delta_profit += sell_prices[k] / buy_price - 1 - 2/1e4
            sell_prices = []
        else:
            buy_price = data['bp1_'+filename][i]*(1-d/1e4)
            if type == "predict":
                buy_price *= (1+np.clip(2*(data[p1][i]-0.0)/1e4, -20/1e4, 0/1e4))
            tp = data['sellpriceT_'+filename][i+1]
            if tp <= buy_price-0.01 and tp != 0:
                volume_sell[0] -= len(sell_prices)
                for k in range(len(sell_prices)):
                    delta_profit += sell_prices[k] / buy_price - 1 + 0.4/1e4
                sell_prices = []
        if volume_buy[0] - volume_sell[0] >= -thres and not sell_closed:
            sell_price = data['ap1_'+filename][i]*(1+d/1e4)
            if type == "predict":
                sell_price *= (1+np.clip(4*(data[p1][i]+0.0)/1e4,-0/1e4, 20/1e4))
            tps = data['buypriceT_'+filename][i+1]
            if tps >= sell_price+0.01 and tps != 0:
                if len(buy_prices) == 1:
                    volume_buy[0] -= 1
                    delta_profit += sell_price / buy_prices[0] - 1 + 0.4/1e4
                else:
                    volume_sell[0] += 1
                    delta_profit += 0.4/1e4
                    sell_prices.append(sell_price)
        return delta_profit, sell_prices


    for i in range(0, len(data)-1-lag):
        if i+5 >= len(data):
            total_profit -= 0.4/1e4 * (len(buy_prices)+len(sell_prices))
            break
        sell_price = data['ap1_'+filename][i]*(1+d/1e4)
        if type == "predict":
            sell_price *= (1+np.clip(2*(data[p1][i]+0.0)/1e4,-0/1e4, 20/1e4))
        tp = data['buypriceT_'+filename][i+1]
        if tp >= sell_price+0.01 and tp != 0 and len(buy_prices) != 0:
            sell_closed = True
        else:
            sell_closed = False
        buy_price = data['bp1_'+filename][i]*(1-d/1e4)
        if type == "predict":
            buy_price *= (1+np.clip(2*(data[p1][i]-0.0)/1e4, -20/1e4, 0/1e4))
        tp = data['sellpriceT_'+filename][i+1]
        if tp <= buy_price-0.01 and tp != 0 and len(sell_prices) != 0:
            buy_closed = True
        else:
            buy_closed = False

        # print(buy_prices, sell_prices, total_profit)
        delta_profit, buy_prices = buy_logic(buy_prices, volume_buy, volume_sell, buy_closed)
        total_profit += delta_profit
        # print(buy_prices, sell_prices, total_profit)
        delta_profit, sell_prices = sell_logic(buy_prices, sell_prices, volume_buy, volume_sell, sell_closed)
        total_profit += delta_profit
        resl.append((data.index[i], total_profit))
        if i > timepoint: 
            break
    print(total_profit, cnt, takercnt)
    return total_profit, cnt, takercnt, resl, volume_buy, volume_sell


def backtest_5(a, b, d, y, type, thres, thres2=0):
    total_profit = 0
    cnt = 0
    takercnt = 0

    data['mid_fu'] = data['ap1_fu']/2+data['bp1_fu']/2
    data['predict1']=pd.DataFrame(y, index = data.index)

    p1='predict1'
    resl = []
    lag = 0 
    filename='fu'
    buy_prices = []
    sell_prices = []
    volume_buy = [0]
    volume_sell = [0] 
    occupy_buy = [0 for i in range(len(data))]
    occupy_sell = [0 for i in range(len(data))]
    
    def buy_logic(buy_prices, volume_buy, volume_sel, buy_closed):
        delta_profit = 0
        if data[p1][i] < -b:
            sell_price = data['bp1_fu'][i+5]*(1.0)
            volume_buy[0] -= len(buy_prices)
            for k in range(len(buy_prices)):
                delta_profit += sell_price / buy_prices[k] - 1 - 2/1e4
            buy_prices = []
            # return delta_profit, buy_prices
        else:
            sell_price = data['ap1_'+filename][i]*(1+d/1e4)
            if type == "predict":
                sell_price *= (1+np.clip(2*(data[p1][i]+0.0)/1e4,-0/1e4, 20/1e4))
            tp = data['buypriceT_'+filename][i+1]
            if tp >= sell_price+0.01 and tp != 0:
                volume_buy[0] -= len(buy_prices)
                for k in range(len(buy_prices)):
                    delta_profit += sell_price / buy_prices[k] - 1 + 0.4/1e4
                buy_prices = []

        if volume_buy[0] - volume_sell[0] <= thres and not buy_closed: #因为买入的现在是不知道买没买的，所以卖不了
            buy_price = data['bp1_'+filename][i]*(1-d/1e4)
            if type == "predict":
                buy_price *= (1+np.clip(4*(data[p1][i]-0.0)/1e4, -20/1e4, 0/1e4))
            tpb = data['sellpriceT_'+filename][i+1]
            if tpb <= buy_price-0.01 and tpb != 0:
                volume_buy[0] += 1
                delta_profit += 0.4/1e4
                buy_prices.append(buy_price)
        return delta_profit, buy_prices

    def sell_logic(buy_prices, sell_prices, volume_buy, volume_sell, sell_closed):
        delta_profit = 0
        if data[p1][i] > b:
            buy_price = data['ap1_fu'][i+5]*(1.0)
            volume_sell[0] -= len(sell_prices)
            for k in range(len(sell_prices)):
                delta_profit += sell_prices[k] / buy_price - 1 - 2/1e4
            sell_prices = []
        else:
            buy_price = data['bp1_'+filename][i]*(1-d/1e4)
            if type == "predict":
                buy_price *= (1+np.clip(2*(data[p1][i]-0.0)/1e4, -20/1e4, 0/1e4))
            tp = data['sellpriceT_'+filename][i+1]
            if tp <= buy_price-0.01 and tp != 0:
                volume_sell[0] -= len(sell_prices)
                for k in range(len(sell_prices)):
                    delta_profit += sell_prices[k] / buy_price - 1 + 0.4/1e4
                sell_prices = []
        if volume_buy[0] - volume_sell[0] >= -thres and not sell_closed:
            sell_price = data['ap1_'+filename][i]*(1+d/1e4)
            if type == "predict":
                sell_price *= (1+np.clip(4*(data[p1][i]+0.0)/1e4,-0/1e4, 20/1e4))
            tps = data['buypriceT_'+filename][i+1]
            if tps >= sell_price+0.01 and tps != 0:
                if len(buy_prices) == 1:
                    volume_buy[0] -= 1
                    delta_profit += sell_price / buy_prices[0] - 1 + 0.4/1e4
                else:
                    volume_sell[0] += 1
                    delta_profit += 0.4/1e4
                    sell_prices.append(sell_price)
        return delta_profit, sell_prices


    for i in range(0, len(data)-1-lag):
        if i+5 >= len(data):
            total_profit -= 0.4/1e4 * (len(buy_prices)+len(sell_prices))
            break
        # print(i, total_profit)
        sell_price = data['ap1_'+filename][i]*(1+d/1e4)
        if type == "predict":
            sell_price *= (1+np.clip(2*(data[p1][i]+0.0)/1e4,-0/1e4, 20/1e4))
        tp = data['buypriceT_'+filename][i+1]
        if tp >= sell_price+0.01 and tp != 0 and len(buy_prices) != 0:
            sell_closed = True
        else:
            sell_closed = False
        buy_price = data['bp1_'+filename][i]*(1-d/1e4)
        if type == "predict":
            buy_price *= (1+np.clip(2*(data[p1][i]-0.0)/1e4, -20/1e4, 0/1e4))
        tp = data['sellpriceT_'+filename][i+1]
        if tp <= buy_price-0.01 and tp != 0 and len(sell_prices) != 0:
            buy_closed = True
        else:
            buy_closed = False

        # print(buy_prices, sell_prices, total_profit)
        delta_profit, buy_prices = buy_logic(buy_prices, volume_buy, volume_sell, False)
        # print(delta_profit)
        total_profit += delta_profit
        # print(buy_prices, sell_prices, total_profit)
        delta_profit, sell_prices = sell_logic(buy_prices, sell_prices, volume_buy, volume_sell, False)
        # print(delta_profit)
        total_profit += delta_profit
        resl.append((data.index[i], total_profit))
        if i > timepoint: 
            break
    print(total_profit, cnt, takercnt)
    return total_profit, cnt, takercnt, resl, volume_buy, volume_sell

import pickle
dic = {}
for a in [1.0]:
    for b in [10]:
            for d in [4]:
                import matplotlib.pyplot as plt
                fig, ax1 = plt.subplots()
                fig.set_figwidth(16)
                fig.set_figheight(12)
                ax2 = ax1.twinx()
                # for thres in [1,3,5,7,10,15,20]:
                    # total_profit, cnt, takercnt, resl = backtest(a, b, d, y_predict, "true")
                    # total_profit2, cnt2, takercnt2, resl2= backtest_2(a, b, d, y_predict, "true")
    # 
                # total_profit, cnt, takercnt, resl3 = backtest(a, b, d, y_predict0, "predict")
                if args.double_test:
                    total_profit, cnt, takercnt, resl7 = backtest(a, b, d, y_predict1, "predict")

                # total_profit2, cnt2, takercnt2, resl4, volume_buy4, volume_sell4= backtest_2(a, b, d, y_predict0, "predict", 5, 100)   
                total_profit2, cnt2, takercnt2, resl4, volume_buy4, volume_sell4= backtest_3(a, b, d, y_predict0, "predict", 5, 100)             
                total_profit2, cnt2, takercnt2, resl5, volume_buy4, volume_sell4= backtest_4(a, b, d, y_predict0, "predict", 5, 100)             
                total_profit2, cnt2, takercnt2, resl6, volume_buy4, volume_sell4= backtest_5(a, b, d, y_predict0, "predict", 5, 100)             

                # total_profit5, cnt5, takercnt5, resl5, volume_buy5, volume_sell5= backtest_2(a, b, d, y_predict0, "predict", 20, 0)


                # remainder = [[data.index[i], volume_buy4[i][1]-volume_sell4[i][1]] for i in range(2500005)]

                
                # ax1.plot(*zip(*resl), color='red')
                # ax1.plot(*zip(*resl2), color='green')
                # ax1.plot(*zip(*resl3), color='black')
                # ax1.plot(*zip(*resl3))
                ax1.plot(*zip(*resl4))
                ax1.plot(*zip(*resl5))
                ax1.plot(*zip(*resl6))

                if args.double_test:
                    ax1.plot(*zip(*resl7))

                # ax1.plot(*zip(*volume_buy4), color='green')
                # ax1.plot(*zip(*volume_sell4), color='black')
                # ax1.plot(*zip(*remainder), color='red')

                plt.grid()
                ax2.plot(data.index, (data['mid_fu']), color='blue')


                plt.title(args.arch+";a:"+str(a)+"b:"+str(b)+"d:"+str(d))
                plt.legend()
                plt.show()
                plt.savefig("result"+args.arch+";".join(args.train)+"_"+";".join(args.valid)+"_"+";".join(args.test)+str(a)+"_"+str(b)+"_"+str(d)+"compare.png")
