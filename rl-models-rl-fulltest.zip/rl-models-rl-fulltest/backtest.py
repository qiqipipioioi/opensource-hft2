import numpy as np
import pandas as pd
from args import args
import datetime
import matplotlib.dates as dates
import matplotlib.pyplot as plt

def genflist(date_list):
    print(date_list)
    start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
    print(start_month, start_day, end_month, end_day)
    start = datetime.date(2022,start_month,start_day)
    end = datetime.date(2022,end_month,end_day)
    x_l = []
    print(start, end)
    for i in range((end-start).days+1):
        day = start + datetime.timedelta(days=i)
        month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
        day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
        x_l.append(month_str+'_'+day_str)
    return x_l

print(args.test, "???")
flist = genflist(args.test[0])
print(flist)

data = pd.DataFrame()
first = True
for file in flist:
    if first:
        data = pd.read_pickle('data_6/data_'+file+'.pkl')
        # linear_y = pd.read_pickle('data_6/xnn2_'+file+'.pkl')["predict"]
        # print(linear_y)
        first = False
        with open('data_6/y_'+file+'.npy', 'rb') as f:
            y_true = np.load(f)
        print(data.columns)
        print(data.shape)
        # with open('data_6/y3_'+file+'.npy', 'rb') as f:
            # y3_true = np.load(f)
        # with open('data_6/y4_'+file+'.npy', 'rb') as f:
            # y4_true = np.load(f)
        # xnn = pd.read_pickle('data_6/xnn2_'+file+'.pkl')
    else:
        # tmp = pd.read_pickle('data_6/xnn2_'+file+'.pkl')
        # xnn = pd.concat([xnn, tmp])
        tmp = pd.read_pickle('data_6/data_'+file+'.pkl')
        data = pd.concat([data, tmp])
        # linear_y = pd.concat([linear_y, pd.read_pickle('data_6/xnn2_'+file+'.pkl')["predict"]])

        with open('data_6/y_'+file+'.npy', 'rb') as f:
            tmp = np.load(f)
        y_true = np.concatenate((y_true, tmp), axis=0)
        # with open('data_6/y3_'+file+'.npy', 'rb') as f:
            # tmp = np.load(f)
        # y3_true = np.concatenate((y3_true, tmp), axis=0)
        # with open('data_6/y4_'+file+'.npy', 'rb') as f:
            # tmp = np.load(f)
        # y4_true = np.concatenate((y4_true, tmp), axis=0)

data = data.iloc[4:]
for i in data.columns:
    print(i)
y_true = y_true[4:]
from matplotlib.dates import HourLocator


# y3_true = y3_true[4:]
# y4_true = y4_true[4:]

print(data.index)

import matplotlib.pyplot as plt
fig, ax1 = plt.subplots()
fig.set_figwidth(16)
fig.set_figheight(12)
ax1.plot(data.index, (data['ap1_fu']), color='blue')
print("a")
# ax1.set_xticks(data.index)
# print("b")

ax1.xaxis.set_major_locator(HourLocator(range(0, 25, 8)))
print("c")




plt.legend(args.arch)
plt.show()
plt.savefig("resultT2.png")

# import lightgbm as lgb
# modell = lgb.Booster(model_file='modell.txt')
# modelp = lgb.Booster(model_file='modelp.txt')
# modelm = lgb.Booster(model_file='modelm.txt')


with open("data_7/y0_"+args.arch+"_"+";".join(args.train)+"_"+";".join(args.valid)+"_"+";".join(args.test)+str(args.rand_number0)+".npy", 'rb') as f:
    y = np.load(f)
# with open('data_7/y3_'+alldate+'.npy', 'rb') as f:
#     y3 = np.load(f)[5956223:]
# with open('data_7/y4_'+alldate+'.npy', 'rb') as f:
#     y4 = np.load(f)[5956223:]

with open("data_7/y3_"+args.arch+"_"+";".join(args.train)+"_"+";".join(args.valid)+"_"+";".join(args.test)+str(args.rand_number3)+".npy", 'rb') as f:
    y3 = np.load(f)

with open("data_7/y4_"+args.arch+"_"+";".join(args.train)+"_"+";".join(args.valid)+"_"+";".join(args.test)+str(args.rand_number4)+".npy", 'rb') as f:
    y4 = np.load(f)

# y3 = modelp.predict(xnn[:])[4:]
# y4 = modelm.predict(xnn[:])[4:]

# from sklearn.metrics import mean_squared_error, r2_score

# print(r2_score(y_true, y))
# print(r2_score(y3_true, y3))
# print(r2_score(y4_true, y4))

# print(data, data.shape)
# print(y, y.shape)

# # y = linear_y
# print(y, y.shape)




lag = 0 # time lag cuz in real trading there will be network lag
lag_taker = 4
def backtest(a, b, c, d=1.5):
    def select(x):
        return (d+np.maximum(x,0)/2)*1
    def select2(x):
        return (d+np.maximum(x,0)/2)*1
    resl = []
    state = 'empty'
    total_profit = 0
    cnt = 0
    takercnt = 0

    data['mid_fu'] = data['ap1_fu']/2+data['bp1_fu']/2
    data['predict1']=pd.DataFrame(y, index = data.index)
    data['stdp2']=pd.DataFrame(y3, index = data.index)
    data['stdm2']=pd.DataFrame(y4, index = data.index)

    p1='predict1'
    p2='predict1'
    stp='stdp2'
    stm='stdm2'
    st='std2'
    up_total = 0
    up_correct = 0
    down_total = 0
    down_correct = 0
    for i in range(0, len(data)-1-lag_taker):
        # if data.index[i] < pd.Timestamp(2022, 8, 2, 13):
            # continue
        # if data.index[i] > pd.Timestamp(2022, 8, 2, 14):
            # exit(-1)
        # print(i, data.index[i], data[p1][i], data['mid_fu'][i])

        #current_price = data['mid_fu'][i]
        
        # if data[p1][i]>0.4:
        #     if y_true[i]>0:
        #         up_correct += 1
        #     up_total += 1
        
        # if data[p1][i]<-0.4:
        #     if y_true[i]<0:
        #         down_correct += 1
        #     down_total += 1
        # print(i, up_total, up_correct, down_total, down_correct)
        # if up_total > 0 and down_total >0:
        #     print(i, float(up_correct)/up_total, float(down_correct)/down_total)

        # # print("predict", data[p1][i]>0.4, "groundtruth", y_true[i]>0)
        if state == 'empty' and (data[p1][i]+data[p2][i])/2 < -b:
            sell_price = data['bp1_fu'][i+lag_taker]#(current_price)
            state = 'sell'
            print(data.index[i],data[p1][i], y_true[i])
            print('sell', sell_price)
            takercnt += 1
            total_profit -= 1.5e-4
            continue
    
        if state == 'empty' and (data[p1][i]+data[p2][i])/2 > b:
            buy_price = data['ap1_fu'][i+lag_taker]#(current_price)
            state = 'buy'
            print(data.index[i],data[p1][i], y_true[i])
            print('buy', buy_price)
            takercnt += 1
            total_profit -= 1.5e-4
            continue


        if state == 'empty' and (data[p1][i]+data[p2][i])/2 > a:
            buy_price = data['bp1_fu'][i]*(1-select(data[stm][i])/1e4)#*(1-select(data[st][i])*np.maximum(data[stm][i],0.0)/1e4)#-data['fu_efsp'][i]#(current_price)
            # tp = data['sellprice_fu'][i+1+lag]
            # if i >= 851525:
            tp = data['sellpriceT_fu'][i+1+lag]
            #print(data['time'][i], buy_price, tp)
            if tp <= buy_price-0.01 and tp != 0:
                #print(data['predict3'][i])
                state = 'buy'
                # print(data.index[i],data[p1][i])
                print('buy',i, buy_price, tp, data['buyprice_fu'][i+1], data['mid_fu'][i], data[stp][i], data[stm][i])
                total_profit += + 0.5/1e4
            continue
        
        if state == 'empty' and (data[p1][i]+data[p2][i])/2 < -a:
            sell_price = data['ap1_fu'][i]*(1+select(data[stp][i])/1e4)#*(1+select(data[st][i])*np.maximum(data[stp][i],0.0)/1e4)
            #+data['fu_efsp'][i]#(current_price)
            # tp = data['buyprice_fu'][i+1+lag]
            # if i >= 851525:
            tp = data['buypriceT_fu'][i+1+lag]
            if tp >= sell_price+0.01 and tp != 0:
                #print(data['predict3'][i])
                state = 'sell'
                # print(data.index[i],data[p1][i])
                print('sell',i, sell_price, data['mid_fu'][i], data[stp][i], data[stm][i])
                total_profit += + 0.5/1e4
            continue
        
        if state == 'buy' and (data[p1][i]+data[p2][i])/2 < -b:
            sell_price = data['bp1_fu'][i+lag_taker]
            state = 'empty'
            # print(data.index[i],data[p1][i])
            # print('sell close', sell_price)
            total_profit += sell_price / buy_price - 1 - 1.5e-4
            # total_profit += sell_price / buy_price - 1
            cnt += 1
            takercnt += 1
            resl.append((data.index[i], total_profit))
            continue

        if state == 'sell' and (data[p1][i]+data[p2][i])/2 > b:
            buy_price = data['ap1_fu'][i+lag_taker]
            state = 'empty'
            # print(data.index[i],data[p1][i])
            # print('buy close', buy_price)
            total_profit += sell_price / buy_price - 1 - 1.5e-4
            # total_profit += sell_price / buy_price - 1 
            cnt += 1
            takercnt += 1
            resl.append((data.index[i], total_profit))
            continue
        
        if state == 'buy' and (data[p1][i]+data[p2][i])/2 < -c:
            sell_price = data['ap1_fu'][i]*(1+select2(data[stp][i])/1e4)#*(1.0+select2(data[st][i])*np.maximum(data[stp][i],0.0)/1e4)#(current_price)
            # tp = data['buyprice_fu'][i+1+lag]
            # if i >=/ 851525:
            tp = data['buypriceT_fu'][i+1+lag]
            #print(data['time'][i], sell_price, tp)
            if tp >= sell_price+0.01 and tp != 0:
                state = 'empty'
                # print(data.index[i],data[p1][i])
                print('sell close', sell_price)
                total_profit += sell_price / buy_price - 1 + 0.5/1e4
                cnt += 1
                resl.append((data.index[i], total_profit))
            continue
        
        if state == 'sell' and (data[p1][i]+data[p2][i])/2 > c:
            buy_price = data['bp1_fu'][i]*(1-select2(data[stm][i])/1e4)#*(1.0-select2(data[st][i])*np.maximum(data[stm][i],0.0)/1e4)#(current_price)
            # tp = data['sellprice_fu'][i+1+lag]
            # if i >= 851525:
            tp = data['sellpriceT_fu'][i+1+lag]
            if tp <= buy_price-0.01 and tp != 0:
                state = 'empty'
                # print(data.index[i],data[p1][i])
                print('buy close', buy_price)
                total_profit += sell_price / buy_price - 1 + 0.5/1e4
                cnt += 1
                resl.append((data.index[i], total_profit))
            continue
    # print(total_profit, cnt, takercnt)
    return total_profit, cnt, takercnt, resl
# backtest(0.2, 5, 0.2)
import pickle
dic = {}
# for a in [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0]:
    # for b in [10]:
        # for c in [-2.1, -1.9, -1.7, -1.5, -1.3, -1.1, -0.9, -0.7, -0.5, -0.3, -0.1, 0, 0.1, 0.3, 0.5, 0.7, 0.9]:
            # for d in [1.5, 2.5]:
for a, b, c, d in [(0.8, 10, -0.4, 1.5), (0.8, 10, -2.1, 1.5)]:
                # a,b,c = 0.9,10,-2.1
                total_profit, cnt, takercnt, resl = backtest(a, b, c, d)
                # print(total_profit, cnt, takercnt, resl)
                # print(tuple(total_profit, cnt, takercnt))
                dic[(a, b, c, d)] = tuple([total_profit, cnt, takercnt])
                # print(resl)
                import matplotlib.pyplot as plt
                fig, ax1 = plt.subplots()
                fig.set_figwidth(16)
                fig.set_figheight(12)
                ax2 = ax1.twinx()
                ax1.plot(*zip(*resl), color='red')
                plt.grid()
                ax2.plot(data.index, (data['mid_fu']), color='blue')
                ax1.xaxis.set_major_locator(HourLocator(range(0, 25, 6)))
                ax2.xaxis.set_major_locator(HourLocator(range(0, 25, 6)))


                plt.title(args.arch+";a:"+str(a)+"b:"+str(b)+"c:"+str(c)+"d:"+str(d))
                plt.show()
                plt.savefig("result"+args.arch+";".join(args.train)+"_"+";".join(args.valid)+"_"+";".join(args.test)+str(a)+"_"+str(b)+"_"+str(c)+"_"+str(d)+"T.png")
                with open('backtest_result_'+args.arch+";".join(args.train)+"_"+";".join(args.valid)+"_"+";".join(args.test)+'.pickle', 'wb') as f:
                    pickle.dump(dic, f)
                print(dic)
