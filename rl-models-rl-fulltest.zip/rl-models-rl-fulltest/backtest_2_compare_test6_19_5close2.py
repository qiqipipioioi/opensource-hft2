import numpy as np
import pandas as pd
from args import args
import datetime
import matplotlib.dates as dates
import matplotlib.pyplot as plt
from numba import jit
import wandb
np.set_printoptions(threshold=200)

thres = 0.01
# wandb.init(project="stock_prediction", entity="zhouuxx96")

@jit
def calculate_profit_with_chosen_2(valid_sellpoint, chosen_value_total, position=5, lag=1, lag2=1, record=False):
    # print(valid_sellpoint)
    chosen_vt = chosen_value_total
    positions_dict = [0 for i in range(len(valid_sellpoint))]
    # profit_positions = [0 for i in range(len(valid_sellpoint))]
    # addedvb_positions = [[] for i in range(len(valid_sellpoint))]

    valid_buypoint = (chosen_vt != 0).nonzero()[0]
    # for i in range(len(chosen_vt)):
        # print(chosen_vt[i])
    profit_position = np.zeros(len(chosen_vt))
    profit_position_2 = np.zeros(len(chosen_vt))

    def get_loc(vb):
        for i in range(len(valid_sellpoint)):
            if vb < valid_sellpoint[i]:
                return i, False
            if valid_sellpoint[i] <= vb and vb < valid_sellpoint[i] + lag + lag2 -1:
                return i, True

    total_profit = 0
    # print(len(valid_buypoint))
    deferred_positions = [(0, 0)]
    deferred_positions = deferred_positions[1:]
    trades = []
    position_np = np.zeros(len(chosen_vt))
    print(len(valid_buypoint))
    for vb in valid_buypoint:
        i = 0
        retained_items = []
        for i in range(len(deferred_positions)):
            if vb >= deferred_positions[i][1]:
                positions_dict[deferred_positions[i][0]] += 1
            else:
                retained_items.append(deferred_positions[i])
        deferred_positions = retained_items
        # print(positions_dict[:10], max(positions_dict), deferred_positions, lag)
        if vb < valid_sellpoint[-1]:
            bin, atpoint = get_loc(vb)
            if not atpoint:
                if positions_dict[bin] < position:
                    total_profit += chosen_vt[vb]
                    profit_position[valid_sellpoint[bin]+lag2-1] += chosen_vt[vb]
                    profit_position_2[vb] += chosen_vt[vb]
                    trades.append((vb, vb+lag, valid_sellpoint[bin]+lag-1, valid_sellpoint[bin]+lag+lag2-1))
                    deferred_positions.append((bin, vb + lag))
                    # print(deferred_positions)
                    if vb == 1010076:
                        print("here!!!", chosen_vt[vb], valid_sellpoint[bin]+lag-1, vb)


            else:
                if positions_dict[bin] < position:
                    total_profit += chosen_vt[vb]
                    profit_position[valid_sellpoint[bin+1]+lag2-1] += chosen_vt[vb]
                    profit_position_2[vb] += chosen_vt[vb]
                    deferred_positions.append((bin, vb + lag))
                    deferred_positions.append((bin+1, vb + lag))
                    trades.append((vb, vb+lag, valid_sellpoint[bin+1]+lag-1, valid_sellpoint[bin+1]+lag+lag2-1))
                    if vb == 1010076:
                        print("here!!!", chosen_vt[vb], valid_sellpoint[bin+1]+lag-1, vb)

                    # print(deferred_positions)
        else:
            print(vb, valid_sellpoint[-1], valid_sellpoint)
            print("why larger")
    return total_profit, profit_position, sum(positions_dict), trades, position_np

def load_data_length(date_list, tp):
    start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
    print(start_month, start_day, end_month, end_day)
    start = datetime.date(2022,start_month,start_day)
    end = datetime.date(2022,end_month,end_day)
    x_l = 0
    print(start, end)
    for i in range((end-start).days+1):
        day = start + datetime.timedelta(days=i)
        print(day, day.month, day.day)
        month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
        day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
        x_l += np.load('data_6/'+tp+'_'+month_str+'_'+day_str+'.npy', mmap_mode="r").shape[0]
    return x_l

def genflist(date_list):
    # print(date_list)
    start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
    # print(start_month, start_day, end_month, end_day)
    start = datetime.date(2022,start_month,start_day)
    if end_month < start_month:
        year = 2023
    else:
        year = 2022
    end = datetime.date(year,end_month,end_day)
    x_l = []
    # print(start, end)
    for i in range((end-start).days+1):
        day = start + datetime.timedelta(days=i)
        month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
        day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
        x_l.append(month_str+'_'+day_str)
    return x_l

@jit
def calculate_profit_with_position(y0, valid_sellpoint, d=4, position=5, lag=1):
    # print(valid_sellpoint)

    profit = y0
    positions_dict = [0 for i in range(len(valid_sellpoint))]
    valid_buypoint = (y0[:, d] != 0).nonzero()[0]
    profit_position = np.zeros(len(y0))
    deferred_position_bin = -1
    def get_loc(vb):
        for i in range(len(valid_sellpoint)):
            if vb < valid_sellpoint[i]:
                return i, False
            if valid_sellpoint[i] <= vb and vb < valid_sellpoint[i] + 2*lag-1:
                return i, True

    total_profit = 0
    deferred_positions = [(0, 0)]
    deferred_positions = deferred_positions[1:]
    for vb in valid_buypoint:
        i = 0
        retained_items = []
        for i in range(len(deferred_positions)):
            if vb >= deferred_positions[i][1]:
                positions_dict[deferred_positions[i][0]] += 1
            else:
                retained_items.append(deferred_positions[i])
        deferred_positions = retained_items    
        if vb < valid_sellpoint[-1]:
            bin, atpoint = get_loc(vb)
            if not atpoint:
                if positions_dict[bin] < position:
                    total_profit += profit[vb, d]
                    profit_position[vb] = profit[vb, d]
                    deferred_positions.append((bin, vb + lag))
            else:
                if positions_dict[bin] < position:
                    total_profit += profit[vb, d]
                    profit_position[vb] = profit[vb, d]
                    deferred_positions.append((bin, vb + lag))
                    deferred_positions.append((bin+1, vb + lag))
        else:
            print("why larger")
    return total_profit, profit_position      

for dout in [0,1,2,3,4,5]:
    dout = 4
    lag, lag2 = 1,1
    profit_s = np.load(abbr+str(args.profit_type)+"dout"+str(dout)+"easy_profit_sell"+"_"+";".join(args.test)+"std"+"_"+str(lag)+str(lag2)+".npy")
    valid_buypoint_minus_lag_1 = np.load(abbr+str(args.profit_type)+"dout"+str(dout)+"valid_buy2ndpoint"+"_"+";".join(args.test)+"std"+"_"+str(lag)+str(lag2)+".npy")

    profit_s5 = np.zeros((len(profit_s), 7))
    profit_s1 = np.zeros((len(profit_s), 7))

    for pos in [5]:
        for din in range(0, 6):
            p, profit_position, trades_num, trades, position_np = calculate_profit_with_chosen_2(valid_buypoint_minus_lag_1, profit_s[:, din], position=pos, lag=lag, lag2=lag2)
            profit_s5[:, din] = profit_position
    for pos in [1]:
        for din in range(0, 6):
            p, profit_position, trades_num, trades, position_np = calculate_profit_with_chosen_2(valid_buypoint_minus_lag_1, profit_s[:, din], position=pos, lag=lag, lag2=lag2)
            profit_s1[:, din] = profit_position
    np.save(abbr+str(args.profit_type)+"dout"+str(dout)+"easy_profit_sellpos5"+"_"+";".join(args.test)+"std"+"_"+str(lag)+str(lag2)+".npy", profit_s5)
    np.save(abbr+str(args.profit_type)+"dout"+str(dout)+"easy_profit_sellpos1"+"_"+";".join(args.test)+"std"+"_"+str(lag)+str(lag2)+".npy", profit_s1)