for filen in "x_data"
do
# for wdate in "01_01" "01_02" "01_03" "01_04" "01_05" "01_06" "01_07" "01_08" "01_09" "01_10" "01_11" "01_12" "01_13" "01_14" "01_15" "01_16" "01_17" "01_18" "01_19" "01_20" "01_21" "01_22" "01_23" "01_24" "01_25"  "01_26"  "01_27" "01_28"  "01_29"  "01_30"   "01_31"  "02_01"  "02_02" "02_03" "02_04" "02_05"  "02_06" "02_07" "02_08" "02_09" "02_12" "02_10" "02_11"
for wdate in $1
do  
mv $filen/x_23_$wdate.aa $filen/x_$wdate.aa
mv $filen/x_23_$wdate.ab $filen/x_$wdate.ab
mv $filen/x_23_$wdate.ac $filen/x_$wdate.ac
mv $filen/x_23_$wdate.ad $filen/x_$wdate.ad
mv $filen/x_23_$wdate.npy $filen/x_$wdate.npy

mv $filen/x2_23_$wdate.aa $filen/x2_$wdate.aa
mv $filen/x2_23_$wdate.ab $filen/x2_$wdate.ab
mv $filen/x2_23_$wdate.ac $filen/x2_$wdate.ac
mv $filen/x2_23_$wdate.ad $filen/x2_$wdate.ad
mv $filen/x2_23_$wdate.npy $filen/x2_$wdate.npy
mv $filen/x3_23_$wdate.aa $filen/x3_$wdate.aa
mv $filen/x3_23_$wdate.ab $filen/x3_$wdate.ab
mv $filen/x3_23_$wdate.ac $filen/x3_$wdate.ac
mv $filen/x3_23_$wdate.ad $filen/x3_$wdate.ad
mv $filen/x3_23_$wdate.npy $filen/x3_$wdate.npy

mv $filen/xnn4_23_$wdate.pkl $filen/xnn4_$wdate.pkl
mv $filen/xnn5_23_$wdate.pkl $filen/xnn5_$wdate.pkl
mv $filen/xnn6_23_$wdate.pkl $filen/xnn6_$wdate.pkl



mv $filen/y_23_$wdate.npy $filen/y_$wdate.npy

mv $filen/data_23_$wdate.pkl $filen/data_$wdate.pkl 

echo "x"$wdate
#cat data_6/xabs_$wdate.a? > data_6/x_abs_$wdate.npy 
#echo "xabs_"$wdate
done  
done
