#!/usr/bin/env python
# coding: utf-8

# In[ ]:
import numpy as np
import datetime
import matplotlib.dates as dates
from influxdb import DataFrameClient
import pandas as pd
from args import args
import os

def genflist(date_list):
    print(date_list)
    start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
    print(start_month, start_day, end_month, end_day)
    start = datetime.date(2022,start_month,start_day)
    end = datetime.date(2022,end_month,end_day)
    x_l = []
    print(start, end)
    for i in range((end-start).days+1):
        day = start + datetime.timedelta(days=i)
        month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
        day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
        x_l.append(month_str+'_'+day_str)
    return x_l

flist = genflist(args.test[0])
filename = "fu"
data = pd.DataFrame()
first = True
tmp_lst = []
for file in flist:
    tmp = pd.read_pickle('data_6/data_'+file+'.pkl')
    tmp = pd.DataFrame(tmp, columns=['mid_fu', "predict1", 'ap1_fu', 'bp1_fu', 'sellpriceT_'+filename, 'buypriceT_'+filename])
    tmp_lst.append(tmp)
data = pd.concat(tmp_lst)
data['time'] = data.index
ts = pd.Timestamp(2022, 11, 19, 22, 9, 13)
start = (data.index > ts).nonzero()[0][0]
# print(data.index[start:start+100])
ts = pd.Timestamp(2022, 11, 20, 4, 9, 16)
end = (data.index > ts).nonzero()[0][0]
# print(data.index[end:end+100])
dout = 4
data = data.iloc[start:end]

start = 1668895753000
end = 1668917356000
client = DataFrameClient('***.***.***.***', 8086, 'xz', 'xzquant2022', 'signal')

result2 = client.query("SELECT * FROM \"order\" WHERE exchange='fu' AND pair='ETHUSDT' AND account='mk2' AND (type='filled' OR type='partially_filled') AND time >= 1668895753000ms and time <= 1668917356000ms;")
result2['order'].index.name='time'
raw2 = result2['order'].reset_index(level=0)
raw2['time'] = pd.to_datetime(raw2['time']).dt.tz_localize(None)
raw2.set_index('time')
del result2['order']
# print(raw, raw2)

data['mid_fu'] = data['ap1_fu']/2+data['bp1_fu']/2
result = client.query("SELECT * FROM \"model\" WHERE exchange='fu' AND pair='ETHUSDT' AND  type='transformer' AND account='mk2' AND time >= 1668895753000ms and time <= 1668917356000ms;")
result['model'].index.name='time'
raw3 = result['model'].reset_index(level=0)
raw3['time'] = pd.to_datetime(raw3['time']).dt.tz_localize(None)
raw3 = raw3.set_index('time')
del result['model']
valid_sellpoint_l = {}
thres = 0
m1, m2 = 2, 4
data['predict1'] = pd.DataFrame(raw3['y0'].to_numpy(), index = data.index)
sell_price = data['ap1_'+filename].to_numpy()*(1+dout/1e4)
sell_price *= (1+np.clip(m1*data['predict1'].to_numpy()/1e4, 0, 20/1e4))

for lag2 in range(0, 11):
    tp = data['buypriceT_'+filename][lag2:].to_numpy()
    tp = np.concatenate([tp, np.zeros(lag2)], axis=0)
    valid_sellpoint_l[lag2] = (np.logical_and(tp >= sell_price+thres, tp != 0))

buy_price = data['bp1_'+filename].to_numpy()*(1-dout/1e4)
buy_price *= (1+np.clip(m2*data['predict1'].to_numpy()/1e4, -20/1e4, 0))

valid_buypoint_l = {}
for lag in range(0, 11):
    tpb = data['sellpriceT_'+filename][lag:].to_numpy()
    tpb = np.concatenate([tpb, np.zeros(lag)], axis=0)
    valid_buypoint_l[lag] = (np.logical_and(tpb <= buy_price-thres, tpb != 0))

for i in range(len(raw2)):
    print("For filled i consider its validaity", raw2.iloc[i])
    result = client.query("SELECT * FROM \"order\" WHERE exchange='fu' AND pair='ETHUSDT' AND account='mk2' AND type='init' AND client_id='"+str(raw2.iloc[i]['client_id'])+"' AND time >= 1668895753000ms and time <= 1668917356000ms;")
    result['order'].index.name='time'
    raw = result['order'].reset_index(level=0)
    raw['time'] = pd.to_datetime(raw['time']).dt.tz_localize(None)
    raw.set_index('time')
    print("init_time", raw.iloc[0]['time'])
    print("filled_time", raw2.iloc[i]['time'])
    tmp = data.index.values.astype(int)
    start = np.argmin(np.abs(tmp - raw.iloc[0]['time'].to_datetime64().astype(int)))
    for j in range(-1, 10):
        print(data.iloc[start+j]['time'])
        if (raw2.iloc[i]['time'] - data.iloc[start+j]['time']) < pd.Timedelta(milliseconds=(120)) and (raw2.iloc[i]['time'] - data.iloc[start+j]['time']) > pd.Timedelta(milliseconds=(20)):
            print("SHOULD BE IN LAG ", j+1)
            if j >= 1:
                print("CHECK WHY LAG >1:")
                result = client.query("SELECT * FROM \"order\" WHERE exchange='fu' AND pair='ETHUSDT' AND account='mk2' AND client_id='"+str(raw2.iloc[i]['client_id'])+"' AND time >= 1668895753000ms and time <= 1668917356000ms;")
                result['order'].index.name='time'
                raw = result['order'].reset_index(level=0)
                raw['time'] = pd.to_datetime(raw['time']).dt.tz_localize(None)
                raw.set_index('time')
                print(raw)
            print("THEN CHECK IF IN BACKTEST ALSO LAG ", j+1)
            print(data.iloc[start])
            if raw2.iloc[i]["side"] == "sell":
                if valid_sellpoint_l[j+1][start] == True:
                    print(i, "VALID SUCCESS! SELL", "lag", j+1)
                else:
                    print("!!!!!!!!!!!!!!!!!!!VALID FAILURE SELL!!!!!!!!!!!!!!!")
            elif raw2.iloc[i]["side"] == "buy":
                if valid_buypoint_l[j+1][start] == True:
                    print(i, "VALID SUCCESS! BUY", "lag", j+1)
                else:
                    print("!!!!!!!!!!!!!!!!!!!VALID FAILURE BUY!!!!!!!!!!!!!!!")
            break
                
for lag in range(1, 3):
    for vs in valid_sellpoint_l[lag]:
        print(data.iloc[vs]['time'], data.iloc[vs])

exit(-1)
# profit_list =  np.zeros((len(raw2), ))
# total_profit = 0
# j = 1
# sellable_list = []
# for i in range(len(raw2)):
#     if raw2.iloc[i]["side"] == "buy":
#         sellable_list.append((raw2.iloc[i]['price'], raw2.iloc[i]['volume']))
#         total_profit = total_profit + (0.4*(raw2.iloc[i]['price']/1e4))*raw2.iloc[i]['volume']
#     if raw2.iloc[i]["side"] == "sell":
#         # for s in sellable_list:

#         total_profit = total_profit + (raw2.iloc[i]['price'] + 0.4*(raw2.iloc[i]['price']/1e4))*raw2.iloc[i]['volume']
#     if abs(total_profit) < 1:
#         profit_list[j:i] = profit_list[j-1]
#         profit_list[i] = total_profit
#         print(i, total_profit)
#         j = i+1

# print(profit_list[:j])
# profit_list = profit_list[:j]
# import matplotlib.pyplot as plt
# fig, ax1 = plt.subplots()
# fig.set_figwidth(16)
# fig.set_figheight(12)
# plt.grid()
# ax1.plot( raw2.iloc[:j]["time"], profit_list, color='blue')
# plt.savefig("results_new_3/result_profit.png")

# print(profit_list, raw2.iloc[:j]["time"])

time_list =  np.zeros((len(raw2), ))
init_cancel_list =  np.zeros((len(raw2), ))
init_new_list =  np.zeros((len(raw2), ))
import numpy as np
for i in range(len(raw2)):
    print(raw2.iloc[i])
    con0 = ((raw2.iloc[i]['time']- raw['time']) < pd.Timedelta(milliseconds=10000)) &((raw['time'] - raw2.iloc[i]['time']) < pd.Timedelta(milliseconds=10000)) & (raw['client_id'] == raw2.iloc[i]['client_id'])
    selected = raw[con0]
    print(selected)
    print(selected[selected['type'] == "init"]['time'].shape, selected[selected['type'] == "filled"]['time'].shape)
    tmp1 = selected[selected['type'] == "filled"]['time'].to_numpy()
    tmp2 = selected[selected['type'] == "init"]['time'].to_numpy()
    tmp3 = selected[selected['type'] == "initcancel"]['time'].to_numpy()
    print("tmp3", tmp3)
    tmp4 = selected[selected['type'] == "new"]['time'].to_numpy()
    amd = tmp1-tmp2
    amd2 = tmp3-tmp2
    amd3 = tmp4 -tmp2

    print(amd.shape, selected[selected['type'] == "filled"]['time'], selected[selected['type'] == "init"]['time'])

    print("----", amd)
    if amd.shape[0] == 1:
        time_list[i] = (amd)*1e-6
    if amd2.shape[0] == 1:
        init_cancel_list[i] = (amd2)*1e-6
    if amd3.shape[0] == 1:
        init_new_list[i] = (amd3)*1e-6

print(time_list)
import matplotlib.pyplot as plt
fig, ax1 = plt.subplots()
fig.set_figwidth(16)
fig.set_figheight(12)
ax2 = ax1.twinx()
plt.grid()
# ax2.plot(raw['time'], (raw['price']), color='blue')
n, bins, patches = plt.hist(time_list, 50, density=True, facecolor='g', alpha=0.75,  weights=np.ones_like(time_list) / len(time_list))

plt.savefig("results_new_3/result_filledinittime.png")

print(init_cancel_list)
import matplotlib.pyplot as plt
fig, ax1 = plt.subplots()
fig.set_figwidth(16)
fig.set_figheight(12)
ax2 = ax1.twinx()
plt.grid()
# ax2.plot(raw['time'], (raw['price']), color='blue')
n, bins, patches = plt.hist(init_cancel_list, 50, density=True, facecolor='g', alpha=0.75,  weights=np.ones_like(init_cancel_list) / len(init_cancel_list))

plt.savefig("results_new_3/result_initinitcanceltime.png")

print(init_new_list)
import matplotlib.pyplot as plt
fig, ax1 = plt.subplots()
fig.set_figwidth(16)
fig.set_figheight(12)
ax2 = ax1.twinx()
plt.grid()
# ax2.plot(raw['time'], (raw['price']), color='blue')
n, bins, patches = plt.hist(init_new_list, 50, density=True, facecolor='g', alpha=0.75,  weights=np.ones_like(init_cancel_list) / len(init_cancel_list))

plt.savefig("results_new_3/result_initnewtime.png")
exit(-1)

print(raw, raw.columns, raw[['order_id', 'pair', 'price', 'side']])

stats = {}
ci = -1
for i in range(len(raw)):
    print(raw.iloc[i][['type', 'client_id']], raw.iloc[i]['time'])
    if raw.iloc[i]['client_id'] not in stats:
        stats[raw.iloc[i]['client_id']] = {}
    stats[raw.iloc[i]['client_id']][raw.iloc[i]['type']] = raw.iloc[i]['time']
    if raw.iloc[i]['type'] == 'fill':
        print(raw, "-----------------------------")
import numpy as np
print(stats)
init_times = np.zeros((len(stats), ))
cancel_times = np.zeros((len(stats), ))
for k,v in stats.items():
    print(k, v['new']-v['init'], v['cancelled']-v['init_cancel'])
    init_times[int(k)-1] = (v['new']-v['init']).to_numpy()*1e-6
    cancel_times[int(k)-1] = (v['cancelled']-v['init_cancel']).to_numpy()*1e-6
    if cancel_times[int(k)-1] > 100 or init_times[int(k)-1]  > 100:
        print(v)
print(init_times.mean(), cancel_times.mean())
import matplotlib.pyplot as plt
fig, ax1 = plt.subplots()
fig.set_figwidth(16)
fig.set_figheight(12)
ax2 = ax1.twinx()
plt.grid()
# ax2.plot(raw['time'], (raw['price']), color='blue')
n, bins, patches = plt.hist(init_times, 50, density=True, facecolor='g', alpha=0.75)

plt.savefig("results_new_3/result_inittime.png")


import matplotlib.pyplot as plt
fig, ax1 = plt.subplots()
fig.set_figwidth(16)
fig.set_figheight(12)
ax2 = ax1.twinx()
plt.grid()
# ax2.plot(raw['time'], (raw['price']), color='blue')
n, bins, patches = plt.hist(cancel_times, 50, density=True, facecolor='g', alpha=0.75)

plt.savefig("results_new_3/result_canceltime.png")
# result = client.query("SELECT * FROM \"input\" WHERE type='rl_seq_621' AND time >= 1668149122896ms and time <= 1668149139780ms;")
# result['input'].index.name='time'
# raw2 = result['input'].reset_index(level=0)#.astype('float32')
# raw2['time'] = pd.to_datetime(raw2['time']).dt.tz_localize(None)
# raw2 = raw2.set_index('time')
# del result['input']

# print(raw2)


# fig, ax1 = plt.subplots()
# fig.set_figwidth(16)
# fig.set_figheight(12)
# ax1.plot(np.cumsum(np.concatenate([profit2, profit4], axis=0))[::interval], label="rl")
# plt.legend()
# plt.show()
# plt.savefig("results_new_2/result_"+args.arch+";".join(args.test2)+";".join(args.test4)+"RLfix"+args.type+"position"+str(5)+args.rand_number+".png")
# plt.close('all')


# import matplotlib.pyplot as plt
# fig, ax1 = plt.subplots()
# fig.set_figwidth(16)
# fig.set_figheight(12)
# ax2 = ax1.twinx()
# # ax1.plot(*zip(*resl), color='red')
# plt.grid()
# ax2.plot(raw['time'], (raw['price']), color='blue')
# plt.savefig("results_new_3/result.png")

# for trades, use user='mk1', mk2, mk3, mk4 to switch between accounts.
# client = DataFrameClient('***.***.***.***', 8086, 'xz', 'xzquant2022', 'user-trades')
# result = client.query("SELECT * FROM trades WHERE \"user\"='mk2' AND pair='ETHUSDT' AND time >= 1667808000000ms and time <= 1667894399000ms;")
# result['trades'].index.name='time'
# raw = result['trades'].reset_index(level=0)#.astype('float32')
# raw['time'] = pd.to_datetime(raw['time']).dt.tz_localize(None)
# raw.set_index('time')
# del result['trades']

# print(raw)

