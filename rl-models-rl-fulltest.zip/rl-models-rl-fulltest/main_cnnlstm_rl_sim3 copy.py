from args import args
from plistlib import load
from re import T
import torch
import torch.nn as nn
import stock
import pickle5 as pickle
# with open('/home/ubuntu/55data_influx.pkl', "rb") as fh:
    # raw3 = pickle.load(fh)

import numpy as np
import tqdm
import logger
import wandb
import models
import torch.utils.benchmark as benchmark
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
import matplotlib.pyplot as plt
torch.set_default_dtype(torch.float32)
epochs = 1000
lr = args.lr
from stock import StockEnv, abs_profit, mean_profit, std_profit
import datetime
args.temp = 1
max_r2 = 0
max_r2_itr = -1
min_l = 0
min_l_itr = -1
max_test2_r2 = 0
max_test2_r2_itr = -1
corr_test2_r2 = 0
max_p = -1
max_p_itr = -1
corr_p = 0
from numba import jit
import random
import numpy as np
import torch
if args.set_seed:
    torch.manual_seed(3407)
    random.seed(3407)
    np.random.seed(3407)
    
def mean(l):
    return sum(l)/len(l)

def count_parameters(model):
    return sum(p.numel() for p in model.parameters() if p.requires_grad)

def assign_learning_rate(optimizer, new_lr):
    for param_group in optimizer.param_groups:
        param_group["lr"] = new_lr
import pandas as pd
interval = int(1e3)
def calculate_train_RLd3_34(model, dataset, rlbuy_profit_path, rlsell_profit_path, valid_sellpoint, valid_buypoint, step=0, tag="train", rand_number=str(args.seed)):
    model = model.actor_mean
    model.eval()
    # model.cpu()
    args.eval = True
    loader_seq = torch.utils.data.DataLoader(dataset, shuffle=False, sampler=torch.utils.data.SequentialSampler(dataset), batch_size=args.batch_size, num_workers=4, pin_memory=True)
    y_hat_total = torch.zeros((dataset.data_X.size(0))).cuda()
    y_hat_total_shrink = torch.zeros((len(dataset),)).cuda()
    # y_hat_total = torch.zeros((dataset.data_X.size(0)))
    # y_hat_total_shrink = torch.zeros((len(dataset),))
    with torch.no_grad():
        start, end = 0, 0
        for i, (x, y, index, mask) in tqdm.tqdm(enumerate(loader_seq), ascii=True, total=len(loader_seq)):
            x = x.cuda()
            out = model(x).squeeze()
            end += out.size(0)
            y_hat_total[index] = out
            y_hat_total_shrink[start:end] = out
            start = end
    print(y_hat_total.size())

    time_index = np.load("19dout4time"+"_"+";".join(args.test4)+"std"+".npy")
    # time_index = np.load("55data_backtesttime.npy")
    # with open('55data_influx.pkl', "rb") as fh:
    #     raw3 = pickle.load(fh)

    np.save("data_7/d"+args.type+args.test4[0]+args.seed+".npy", torch.exp(y_hat_total).cpu().detach().numpy())

    print(torch.sum(torch.exp(y_hat_total) > 5)/y_hat_total.size(0))
    
    
    from influxdb import DataFrameClient

    client = DataFrameClient(args.ip, 8086, 'xz', 'xzquant2022', 'signal')
    
    if args.write_db:
        data_1 = pd.DataFrame()
        data_1['time'] = pd.DataFrame(time_index)
        data_1['d'] = pd.DataFrame(torch.exp(y_hat_total).cpu().detach().numpy())
        data_1.index = data_1.time
        i = 0
        for i in range(1, int(len(data_1.index)//1e5)):
            print((i-1)*int(1e5), i*int(1e5))
            client.write_points(data_1[['d']][(i-1)*int(1e5):i*int(1e5)], "backtest_d"+args.type, {})
        print(i*int(1e5), len(data_1[['d']]))
        client.write_points(data_1[['d']][i*int(1e5):],  "backtest_d"+args.type, {})
    return torch.exp(y_hat_total).cpu().detach().numpy()
    # print(torch.histc(y_hat_total))
    # tmp = torch.clamp(torch.exp(y_hat_total), max=50).detach().cpu().numpy()
    # import matplotlib.pyplot as plt
    # fig, ax1 = plt.subplots()
    # fig.set_figwidth(16)
    # fig.set_figheight(12)
    # ax2 = ax1.twinx()
    # plt.grid()
    # n, bins, patches = plt.hist(tmp, 50, density=True, facecolor='g', alpha=0.75,  weights=np.ones_like(tmp) / len(tmp))
    # plt.savefig("results_new_3/result_filledinittime"+args.type+".png")

    for j in range(args.d_num):
        print("buy portition", j, torch.sum(torch.argmax(y_hat_total_shrink[:, :args.d_num], axis=1) == j)/y_hat_total_shrink.size(0))
        print("buy portition", j, torch.sum(torch.argmax(y_hat_total[:, :args.d_num], axis=1) == j)/y_hat_total.size(0))
        # print("sell portition", j, torch.sum(torch.argmax(y_hat_total_shrink[:, args.d_num:], axis=1) == j)/y_hat_total_shrink.size(0))
    tmp_ind = 0
    print(y_hat_total[tmp_ind], nn.Softmax(dim=-1)(y_hat_total[tmp_ind]))
    print(torch.argmax(y_hat_total_shrink[tmp_ind:tmp_ind+100], axis=1))
    print(torch.argmax(y_hat_total[tmp_ind:tmp_ind+100], axis=1))
    actions = torch.argmax(y_hat_total_shrink[tmp_ind:tmp_ind+100], axis=1).detach().cpu().float().numpy()

    fig, ax1 = plt.subplots()
    fig.set_figwidth(16)
    fig.set_figheight(12)
    ax1.plot(actions, label="rl")
    plt.legend()
    plt.show()
    plt.savefig("results_new_3/d"+args.arch+";".join(args.test)+"RLfix"+args.type+"position"+str(5)+args.rand_number+".png")

    actions[actions==6] = float('nan')

    dout = 4
    buy_price_base = np.load("14dout"+str(dout)+"buy_price_base"+"_"+";".join(args.test)+"std"+"_"+str(args.lag)+".npy")
    buy_price = buy_price_base[tmp_ind:tmp_ind+100]*(1-actions/1e4)
    print(buy_price)


    # y_hat_total = y_hat_total.detach().cpu()
    
    # p_sum1, lines_p1, line_chosen_p1 = calculate_profit(y_hat_total, rlbuy_profit_path, valid_sellpoint, valid_buypoint, "buy", step, tag=tag, rand_number=rand_number)
    # p_sum2, lines_p2, line_chosen_p2 = calculate_profit(y_hat_total[:, args.d_num:], rlsell_profit_path, valid_sellpoint, valid_buypoint, "sell", step, tag=tag, rand_number=rand_number)
    # wandb.log({tag+"/profit_constrained_all": p_sum1+p_sum2}, step=step)
    # wandb.log({tag+"/profit_constrained_buy": p_sum1}, step=step)
    # wandb.log({tag+"/profit_constrained_sell": p_sum2}, step=step)


    for lag in range(args.start, args.lag):
        if args.draw:
            fig, ax1 = plt.subplots()
            fig.set_figwidth(16)
            fig.set_figheight(12)
            for j in range(0, args.d_num-1):
                ax1.plot(lines_p1[lag][j][::interval]+lines_p2[lag][j][::interval])
            ax1.plot(line_chosen_p1[lag][::interval] + line_chosen_p2[lag][::interval])
            plt.legend()
            plt.show()
            plt.savefig("result_"+args.arch+";".join(args.train)+"_"+";".join(args.test)+"_"+";".join(args.test2)+"RLfixall"+args.rand_number+"_"+str(args.rand_number0)+"_"+str(lag+1)+"_position"+str(args.pos)+".png")  
            plt.clf()
    if args.draw:
        fig, ax1 = plt.subplots()
        fig.set_figwidth(16)
        fig.set_figheight(12)

        for j in range(args.start, args.d_num-1):
            ax1.plot(lines_p1[0][j][::interval]+lines_p2[0][j][::interval]+lines_p1[1][j][::interval]+lines_p2[1][j][::interval])
        ax1.plot(line_chosen_p1[0][::interval] + line_chosen_p2[0][::interval] + line_chosen_p1[1][::interval] + line_chosen_p2[1][::interval])
        plt.legend()
        plt.show()
        plt.savefig("result_"+args.arch+";".join(args.train)+"_"+";".join(args.test)+"_"+";".join(args.test2)+"RLfixall"+args.rand_number+"_"+str(args.rand_number0)+"_123position"+str(args.pos)+".png")
        plt.clf()
    return 0

def calculate_profit(y_hat_total, rl_profit_path, valid_sellpoint_path, valid_buypoint_path, type_, step, tag="test", rand_number="0"):
    p_d_sum = {i:0 for i in range(0, args.d_num-1)}
    p_sum = []
    y_total_123 = None
    chosen_value_total_123 = None
    max_total_123 = None
    lines_lag, line_chosen_lag, lines_position_lag, line_chosen_position_lag, y_total_lag, chosen_value_total_lag = [], [], [], [], [], []

    for lag in range(1, args.lag+1):
        y0 = np.load(rl_profit_path+"_"+str(lag)+".npy")
        y_total = torch.from_numpy(y0)
        print("----------For ", tag, type_, lag, "----------")
        chosen_value_total = y_total.gather(1, torch.argmax(y_hat_total, axis=1).unsqueeze(1)).squeeze()
        max_total = torch.max(y_total, axis=1)[0]
        chosen_value_total_lag.append(chosen_value_total)
        lines = np.cumsum(y0, axis=0)
        lines_lag.append(lines)

        if args.draw:
            fig, ax1 = plt.subplots()
            fig.set_figwidth(16)
            fig.set_figheight(12)
            for j in range(args.start, args.d_num):
                ax1.plot(lines[::interval, j])
            
            line_chosen = np.cumsum(chosen_value_total.cpu().detach().numpy())
            line_chosen_lag.append(line_chosen)
            ax1.plot(line_chosen[::interval])

            plt.legend()
            plt.show()
            plt.savefig("results_new/result_"+args.arch+";".join(args.train)+"_"+";".join(args.test)+"_"+";".join(args.test2)+"RLfix"+type_+rand_number+"_"+str(lag)+".png")

        lines_position = []
        

            
        # for j in range(6):
        #     print(torch.sum(torch.argmax(y_hat_total, axis=1) == j)/y_hat_total.size(0))

        if lag == 1:
            y_total_123 = y_total
            chosen_value_total_123 = chosen_value_total
            max_total_123 = max_total
        else:
            y_total_123 = y_total + y_total_123
            chosen_value_total_123 = chosen_value_total + chosen_value_total_123
            max_total_123 = max_total + max_total_123

        if type_ == "buy":
            valid_sellpoint = np.load(valid_sellpoint_path+"_"+str(lag)+".npy")
            for thres in range(0, 1, 1):
                for pos in [args.pos, 10000]:
                    masking_matrix = (torch.max(y_hat_total, axis=1)[0] > float(thres)/100).float()
                    temp_chosen_total = chosen_value_total * masking_matrix
                    temp_chosen_total = temp_chosen_total.cpu().detach().numpy()
                    p, profit_chosen, pos_dict = calculate_profit_with_chosen(valid_sellpoint, temp_chosen_total, position=pos, lag=lag)
                    profit_chosen_pt = torch.from_numpy(profit_chosen).cuda()
                    nonzero_mask = (profit_chosen_pt!=0)
                    print("chosen buy, pos, p, thres", pos, p, thres, (torch.sum(profit_chosen_pt)/(-torch.sum(torch.clamp(profit_chosen_pt, max=0))+1e-20)).item(), (torch.mean(profit_chosen_pt[nonzero_mask])/(1e-20+torch.std(profit_chosen_pt[nonzero_mask]))).item())
                    print("pos dict mean, max", sum(pos_dict)/len(pos_dict), max(pos_dict), sum(pos_dict), len(pos_dict))   
                    # exit(-1)

                    if thres == 0 and pos == args.pos:
                        p_sum.append(p)  
                        torch.save(pos_dict, "pos_dict.pttestbuy"+str(lag)+str(args.rand_number))
                        line_chosen_postion = np.cumsum(profit_chosen)
                    if args.wandb:
                        wandb.log({tag+str(type_)+str(lag)+"/pos_mean_chosen"+str(args.pos): sum(pos_dict)/len(pos_dict)}, step=step)
                        wandb.log({tag+str(type_)+str(lag)+"/pos_max_chosen"+str(args.pos): max(pos_dict)}, step=step)
            for pos in [args.pos]:
                for j in range(0, args.d_num-1): 
                    p, profit_fix_position, pos_dict = calculate_profit_with_chosen(valid_sellpoint, y0[:, j], position=pos, lag=lag)
                    profit_fix_position_pt = torch.from_numpy(profit_fix_position).cuda()
                    nonzero_mask = (profit_fix_position_pt!=0)
                    print("fix buy, pos, j, p", pos, j, p, (torch.sum(profit_fix_position_pt)/(-torch.sum(torch.clamp(profit_fix_position_pt, max=0))+1e-20)).item(), (torch.mean(profit_fix_position_pt[nonzero_mask])/(1e-20+torch.std(profit_fix_position_pt[nonzero_mask]))).item())
                    print("pos dict mean, max", sum(pos_dict)/len(pos_dict), max(pos_dict), sum(pos_dict), len(pos_dict))   
                    if args.wandb:
                        wandb.log({tag+str(type_)+str(lag)+"/pos_mean"+str(j): sum(pos_dict)/len(pos_dict)}, step=step)
                        wandb.log({tag+str(type_)+str(lag)+"/pos_max"+str(j): max(pos_dict)}, step=step) 
                    p_d_sum[j] += p
                    lines_position.append(np.cumsum(profit_fix_position))
            p, profit_fix_position, pos_dict = calculate_profit_with_chosen(valid_sellpoint, np.max(y0, axis=1), position=pos, lag=lag)
            profit_fix_position_pt = torch.from_numpy(profit_fix_position).cuda()
            nonzero_mask = (profit_fix_position_pt!=0)
            print("max buy, pos, j, p", pos, j, p, (torch.sum(profit_fix_position_pt)/(-torch.sum(torch.clamp(profit_fix_position_pt, max=0))+1e-20)).item(), (torch.mean(profit_fix_position_pt[nonzero_mask])/(1e-20+torch.std(profit_fix_position_pt[nonzero_mask]))).item())
            print("pos dict mean, max", sum(pos_dict)/len(pos_dict), max(pos_dict), sum(pos_dict), len(pos_dict))   
        if type_ == "sell":
            valid_buypoint = np.load(valid_buypoint_path+"_"+str(lag)+".npy")
            for thres in range(0, 1, 1):
                for pos in [args.pos, 10000]:
                    masking_matrix = (torch.max(y_hat_total, axis=1)[0] > float(thres)/100).float()
                    temp_chosen_total = chosen_value_total * masking_matrix
                    temp_chosen_total = temp_chosen_total.cpu().detach().numpy()
                    p, profit_chosen, pos_dict = calculate_profit_with_chosen(valid_buypoint, temp_chosen_total, position=pos, lag=lag)
                    profit_chosen_pt = torch.from_numpy(profit_chosen).cuda()
                    nonzero_mask = (profit_chosen_pt!=0)
                    print("chosen sell, pos, p, thres", pos, p, thres, (torch.sum(profit_chosen_pt)/(-torch.sum(torch.clamp(profit_chosen_pt, max=0))+1e-20)).item(), (torch.mean(profit_chosen_pt[nonzero_mask])/(1e-20+torch.std(profit_chosen_pt[nonzero_mask]))).item())    
                    print("pos dict mean, max", sum(pos_dict)/len(pos_dict), max(pos_dict), sum(pos_dict), len(pos_dict))   


                    if thres == 0 and pos == args.pos:
                        p_sum.append(p)  
                        torch.save(pos_dict, "pos_dict.pttestsell"+str(lag)+str(args.rand_number))
                        line_chosen_postion = np.cumsum(profit_chosen)
                    if args.wandb:
                        wandb.log({tag+str(type_)+str(lag)+"/pos_mean_chosen"+str(args.pos): sum(pos_dict)/len(pos_dict)}, step=step)
                        wandb.log({tag+str(type_)+str(lag)+"/pos_max_chosen"+str(args.pos): max(pos_dict)}, step=step)

            for pos in [args.pos]:
                for j in range(0, args.d_num-1): 
                    p, profit_fix_position, pos_dict = calculate_profit_with_chosen(valid_buypoint, y0[:, j], position=pos, lag=lag)
                    profit_fix_position_pt = torch.from_numpy(profit_fix_position).cuda()
                    nonzero_mask = (profit_fix_position_pt!=0)
                    print("fix sell, pos, j, p", pos, j, p, (torch.sum(profit_fix_position_pt)/(-torch.sum(torch.clamp(profit_fix_position_pt, max=0))+1e-20)).item(), (torch.mean(profit_fix_position_pt[nonzero_mask])/(1e-20+torch.std(profit_fix_position_pt[nonzero_mask]))).item()) 
                    print("pos dict mean, max", sum(pos_dict)/len(pos_dict), max(pos_dict), sum(pos_dict), len(pos_dict), )  
                    if args.wandb: 
                        wandb.log({tag+str(type_)+str(lag)+"/pos_mean"+str(j): sum(pos_dict)/len(pos_dict)}, step=step)
                        wandb.log({tag+str(type_)+str(lag)+"/pos_max"+str(j): max(pos_dict)}, step=step) 
                    p_d_sum[j] += p
                    lines_position.append(np.cumsum(profit_fix_position))

        if args.draw:
            fig, ax1 = plt.subplots()
            fig.set_figwidth(16)
            fig.set_figheight(12)
            for j in range(args.start, args.d_num-1):
                ax1.plot(lines_position[j][::interval])
            ax1.plot(line_chosen_postion[::interval])
            plt.legend()
            plt.show()
            plt.savefig("results_new/result_"+args.arch+";".join(args.train)+"_"+";".join(args.test)+"_"+";".join(args.test2)+"RLfix"+type_+rand_number+"_"+str(lag)+"position"+str(args.pos)+".png")
            lines_position_lag.append(lines_position)
            line_chosen_position_lag.append(line_chosen_postion)
        if args.wandb: 
            for j in range(0, 6):
                wandb.log({tag+str(type_)+str(lag)+"/profit-loss"+str(j): torch.sum(y_total[:, j]).item()}, step=step)
                wandb.log({tag+str(type_)+str(lag)+"/(profit-loss~loss)"+str(j): (torch.sum(y_total[:, j])/(-torch.sum(torch.clamp(y_total[:, j], max=0))+1e-20)).item()}, step=step)
                wandb.log({tag+str(type_)+str(lag)+"/profit"+str(j): (torch.sum(torch.clamp(y_total[:, j], min=0))).item()}, step=step)
                wandb.log({tag+str(type_)+str(lag)+"/loss"+str(j): (-torch.sum(torch.clamp(y_total[:, j], max=0))).item()}, step=step)
                wandb.log({tag+str(type_)+str(lag)+"/sharpe"+str(j): (torch.mean(y_total[:, j])/(1e-20+torch.std(y_total[:, j]))).item()}, step=step)

            wandb.log({tag+str(type_)+str(lag)+"/(profit-loss)_chosen": (torch.sum(chosen_value_total)).item()}, step=step)
            wandb.log({tag+str(type_)+str(lag)+"/(profit-loss)_max": (torch.sum(max_total)).item()}, step=step)
            wandb.log({tag+str(type_)+str(lag)+"/((profit-loss~loss))_chosen": (torch.sum(chosen_value_total)/(-torch.sum(torch.clamp(chosen_value_total, max=0))+1e-20)).item()}, step=step)
            wandb.log({tag+str(type_)+str(lag)+"/((profit-loss~loss))_max": (torch.sum(max_total)/(-torch.sum(torch.clamp(max_total, max=0))+1e-20)).item()}, step=step)
            wandb.log({tag+str(type_)+str(lag)+"/profit_chosen": (torch.sum(torch.clamp(chosen_value_total, min=0))).item()}, step=step)
            wandb.log({tag+str(type_)+str(lag)+"/profit_max": (torch.sum(torch.clamp(max_total, min=0))).item()}, step=step)
            wandb.log({tag+str(type_)+str(lag)+"/loss_chosen": (-torch.sum(torch.clamp(chosen_value_total, max=0))).item()}, step=step)
            wandb.log({tag+str(type_)+str(lag)+"/loss_max": (-torch.sum(torch.clamp(max_total, max=0))).item()}, step=step)
            wandb.log({tag+str(type_)+str(lag)+"/sharpe chosen": (torch.mean(chosen_value_total)/(1e-20+torch.std(chosen_value_total))).item()}, step=step)
            wandb.log({tag+str(type_)+str(lag)+"/sharpe max": (torch.mean(max_total)/(1e-20+torch.std(max_total))).item()}, step=step)


        
        
        for j in range(0, args.d_num-1): 
            print(torch.nonzero(y_total[:, j]).size(), y_total[:, j].size())
            tmp = torch.index_select(y_total[:, j], 0, torch.nonzero(y_total[:, j]).squeeze())
            print(tmp.size(), tmp.std())
            print("d=", j, "profit-loss, (profit-loss/loss), profit, loss, sharpe", torch.sum(y_total[:, j]).item(), (torch.sum(y_total[:, j])/(-torch.sum(torch.clamp(y_total[:, j], max=0))+1e-20)).item(), (torch.sum(torch.clamp(y_total[:, j], min=0))).item(), (-torch.sum(torch.clamp(y_total[:, j], max=0))).item(), (torch.mean(y_total[:, j])/(1e-20+torch.std(y_total[:, j]))).item(), torch.std(y_total[:, j]).item())
        tmp = torch.index_select(chosen_value_total, 0, torch.nonzero(chosen_value_total).squeeze())
        print(tmp.size(), tmp.std())
        
        print("(profit-loss)_chosen, ((profit-loss/loss))_chosen, profit_chosen, loss_chosen, sharpe max", (torch.sum(chosen_value_total)).item(), (torch.sum(chosen_value_total)/(-torch.sum(torch.clamp(chosen_value_total, max=0))+1e-20)).item(),  (torch.sum(torch.clamp(chosen_value_total, min=0))).item(), (-torch.sum(torch.clamp(chosen_value_total, max=0))).item(), (torch.mean(chosen_value_total)/(1e-20+torch.std(chosen_value_total))).item(), torch.std(chosen_value_total).item())
        tmp = torch.index_select(max_total, 0, torch.nonzero(max_total).squeeze())
        print(tmp.size(), tmp.std())
        print("(profit-loss)_max, ((profit-loss/loss))_max, profit_max, loss_max, sharpe chosen", (torch.sum(max_total)).item(), (torch.sum(max_total)/(-torch.sum(torch.clamp(max_total, max=0))+1e-20)).item(),  (torch.sum(torch.clamp(max_total, min=0))).item(), (-torch.sum(torch.clamp(max_total, max=0))).item(), (torch.mean(max_total)/(1e-20+torch.std(max_total))).item(), torch.std(max_total).item())
    
    if args.draw:
        fig, ax1 = plt.subplots()
        fig.set_figwidth(16)
        fig.set_figheight(12)
        for j in range(args.start, args.d_num-1):
            if args.lag == 2:
                ax1.plot(lines_lag[0][::interval, j]+lines_lag[1][::interval, j])
            else:
                ax1.plot(lines_lag[0][::interval, j]+lines_lag[1][::interval, j]+lines_lag[2][::interval, j])
        if args.lag == 2:
            ax1.plot(line_chosen_lag[0][::interval]+line_chosen_lag[1][::interval])
        else:
            ax1.plot(line_chosen_lag[0][::interval]+line_chosen_lag[1][::interval]+line_chosen_lag[2][::interval])

        plt.legend()
        plt.show()
        plt.savefig("results_new/result_"+args.arch+";".join(args.train)+"_"+";".join(args.test)+"_"+";".join(args.test2)+"RLfix"+type_+rand_number+"_123"+".png")
        plt.clf()

        fig, ax1 = plt.subplots()
        fig.set_figwidth(16)
        fig.set_figheight(12)

        for j in range(args.start, args.d_num-1):
            if args.lag == 2:
                ax1.plot(lines_position_lag[0][j][::interval]+lines_position_lag[1][j][::interval])
            else:
                ax1.plot(lines_position_lag[0][j][::interval]+lines_position_lag[1][j][::interval]+lines_position_lag[2][j][::interval])
        if args.lag == 2:
            ax1.plot(line_chosen_position_lag[0][::interval]+line_chosen_position_lag[1][::interval])
        else:
            ax1.plot(line_chosen_position_lag[0][::interval]+line_chosen_position_lag[1][::interval]+line_chosen_position_lag[2][::interval])
        plt.legend()
        plt.show()
        plt.savefig("results_new/result_"+args.arch+";".join(args.train)+"_"+";".join(args.test)+"_"+";".join(args.test2)+"RLfix"+type_+rand_number+"_123position"+str(args.pos)+".png")
        plt.clf()
    if args.wandb:
        lag = 123
        for j in range(0, args.d_num-1):
            wandb.log({tag+str(type_)+str(lag)+"/profit-loss"+str(j): torch.sum(y_total_123[:, j]).item()}, step=step)
            wandb.log({tag+str(type_)+str(lag)+"/(profit-loss~loss)"+str(j): (torch.sum(y_total_123[:, j])/(-torch.sum(torch.clamp(y_total_123[:, j], max=0))+1e-20)).item()}, step=step)
            wandb.log({tag+str(type_)+str(lag)+"/profit"+str(j): (torch.sum(torch.clamp(y_total_123[:, j], min=0))).item()}, step=step)
            wandb.log({tag+str(type_)+str(lag)+"/loss"+str(j): (-torch.sum(torch.clamp(y_total_123[:, j], max=0))).item()}, step=step)
            wandb.log({tag+str(type_)+str(lag)+"/sharpe"+str(j): (torch.mean(y_total_123[:, j])/(1e-20+torch.std(y_total_123[:, j]))).item()}, step=step)

        wandb.log({tag+str(type_)+str(lag)+"/(profit-loss)_chosen": (torch.sum(chosen_value_total_123)).item()}, step=step)
        wandb.log({tag+str(type_)+str(lag)+"/(profit-loss)_max": (torch.sum(max_total_123)).item()}, step=step)
        wandb.log({tag+str(type_)+str(lag)+"/((profit-loss~loss))_chosen": (torch.sum(chosen_value_total_123)/(-torch.sum(torch.clamp(chosen_value_total_123, max=0))+1e-20)).item()}, step=step)
        wandb.log({tag+str(type_)+str(lag)+"/((profit-loss~loss))_max": (torch.sum(max_total_123)/(-torch.sum(torch.clamp(max_total_123, max=0))+1e-20)).item()}, step=step)
        wandb.log({tag+str(type_)+str(lag)+"/profit_chosen": (torch.sum(torch.clamp(chosen_value_total_123, min=0))).item()}, step=step)
        wandb.log({tag+str(type_)+str(lag)+"/profit_max": (torch.sum(torch.clamp(max_total_123, min=0))).item()}, step=step)
        wandb.log({tag+str(type_)+str(lag)+"/loss_chosen": (-torch.sum(torch.clamp(chosen_value_total_123, max=0))).item()}, step=step)
        wandb.log({tag+str(type_)+str(lag)+"/loss_max": (-torch.sum(torch.clamp(max_total_123, max=0))).item()}, step=step)
        wandb.log({tag+str(type_)+str(lag)+"/sharpe chosen": (torch.mean(chosen_value_total_123)/(1e-20+torch.std(chosen_value_total_123))).item()}, step=step)
        wandb.log({tag+str(type_)+str(lag)+"/sharpe max": (torch.mean(max_total_123)/(1e-20+torch.std(max_total_123))).item()}, step=step)


    print("Profit comparison chosen", sum(p_sum))
    if args.wandb:
        wandb.log({tag+str(type_)+str(lag)+"/profit123 chosen": sum(p_sum)}, step=step)

    for j in range(0, args.d_num-1): 
        print("Profit comparison d", j, p_d_sum[j])
        if args.wandb:
            wandb.log({tag+str(type_)+str(lag)+"/profit123"+str(j): p_d_sum[j]}, step=step)



    for j in range(0, args.d_num-1): 
        print("d=", j, "profit-loss, (profit-loss/loss), profit, loss, sharpe", torch.sum(y_total_123[:, j]).item(), (torch.sum(y_total_123[:, j])/(-torch.sum(torch.clamp(y_total_123[:, j], max=0))+1e-20)).item(), (torch.sum(torch.clamp(y_total_123[:, j], min=0))).item(), (-torch.sum(torch.clamp(y_total_123[:, j], max=0))).item(), (torch.mean(y_total_123[:, j])/(1e-20+torch.std(y_total_123[:, j]))).item())
    print("(profit-loss)_chosen, ((profit-loss/loss))_chosen, profit_chosen, loss_chosen, sharpe max", (torch.sum(chosen_value_total_123)).item(), (torch.sum(chosen_value_total_123)/(-torch.sum(torch.clamp(chosen_value_total_123, max=0))+1e-20)).item(),  (torch.sum(torch.clamp(chosen_value_total_123, min=0))).item(), (-torch.sum(torch.clamp(chosen_value_total_123, max=0))).item(), (torch.mean(chosen_value_total_123)/(1e-20+torch.std(chosen_value_total_123))).item())
    print("(profit-loss)_max, ((profit-loss/loss))_max, profit_max, loss_max, sharpe chosen", (torch.sum(max_total_123)).item(), (torch.sum(max_total_123)/(-torch.sum(torch.clamp(max_total_123, max=0))+1e-20)).item(),  (torch.sum(torch.clamp(max_total_123, min=0))).item(), (-torch.sum(torch.clamp(max_total_123, max=0))).item(), (torch.mean(max_total_123)/(1e-20+torch.std(max_total_123))).item())

    return sum(p_sum), lines_position_lag, line_chosen_position_lag

def train(model, loader, opt, epoch):
    global max_r2, max_r2_itr, min_l, min_l_itr, max_test2_r2_itr, max_test2_r2, corr_test2_r2, max_p, max_p_itr, corr_p
    model.train()
    pg_loss_meter = logger.AverageMeter("pg_loss", ":.3f")
    ratio_meter = logger.AverageMeter("ratio", ":.3f")
    opt.zero_grad()
    l = [pg_loss_meter, ratio_meter]
    progress = logger.ProgressMeter(len(loader), l, prefix=f"Train Epoch: [{epoch}]")
    num_updates = 0
    for i, (b_obs, b_logprobs, b_actions, b_returns) in tqdm.tqdm(enumerate(loader), ascii=True, total=len(loader)):
        model.train()
        #
        b_obs, b_logprobs, b_actions, b_returns = b_obs.cuda(), b_logprobs.cuda(), b_actions.cuda(), b_returns.cuda()
        # print(b_actions, b_actions.float())
        # with torch.no_grad():
        _, newlogprob = model.get_action(b_obs, b_actions.unsqueeze(-1))
        logratio = newlogprob - b_logprobs
        # for i in range(2048):
            # print("newlogprob, b_logprobs", newlogprob[i], b_logprobs[i])
        # print("newlogprob, b_logprobs", newlogprob, b_logprobs, torch.isinf(newlogprob).sum(), torch.isinf(b_logprobs).sum())
        ratio = torch.clamp(logratio, max=50).exp()
        # print("2", ratio, ratio.mean(), torch.isinf(ratio).sum(), torch.isinf(logratio).sum(), torch.isinf(ratio).nonzero())
        # if i >= 3:
            # ind = torch.isinf(ratio).nonzero()[0]
            # print("why", logratio[ind], ratio[ind], newlogprob[ind], b_logprobs[ind]) 

        pg_loss1 = -b_returns * ratio

        pg_loss2 = -b_returns * torch.clamp(ratio, 1 - args.clip_coef, 1 + args.clip_coef)
        # print("3", pg_loss1.mean(), pg_loss2.mean())
        pg_loss = torch.max(pg_loss1, pg_loss2).mean()
        # print(pg_loss)
        loss = pg_loss
        pg_loss_meter.update(pg_loss.item(), b_obs.size(0))
        ratio_meter.update(ratio.mean().item(), b_obs.size(0))
        wandb.log({"train/pg_loss": pg_loss.item()}, step=epoch)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 3)
        if (i+1) % args.gradient_acc_step == 0:
            if args.div_grad_acc:
                for name, param in model.named_parameters():
                    param.grad.data = param.grad.data/args.gradient_acc_step
                # print(name, param.grad, args.gradient_acc_step)
                
            opt.step()
            opt.zero_grad()
            num_updates += 1
            if num_updates >= args.updates_thres:
                break
            


        if "RL" in args.arch:
            if i % 200 == 0:
                progress.display(i) 
    return 0, 0, 0


@jit
def calculate_profit_with_chosen(valid_sellpoint, chosen_value_total, position=5, lag=1, lag2=1):
    # print(valid_sellpoint)
    chosen_vt = chosen_value_total
    positions_dict = [0 for i in range(len(valid_sellpoint))]
    # profit_positions = [0 for i in range(len(valid_sellpoint))]
    # addedvb_positions = [[] for i in range(len(valid_sellpoint))]

    valid_buypoint = (chosen_vt != 0).nonzero()[0]
    # for i in range(len(chosen_vt)):
        # print(chosen_vt[i])
    profit_position = np.zeros(len(chosen_vt))
    def get_loc(vb):
        for i in range(len(valid_sellpoint)):
            if vb < valid_sellpoint[i]:
                return i, False
            if valid_sellpoint[i] <= vb and vb < valid_sellpoint[i] + lag + lag2 -1:
                return i, True

    total_profit = 0
    # print(len(valid_buypoint))
    deferred_positions = [(0, 0)]
    deferred_positions = deferred_positions[1:]
    for vb in valid_buypoint:
        i = 0
        retained_items = []
        for i in range(len(deferred_positions)):
            if vb >= deferred_positions[i][1]:
                positions_dict[deferred_positions[i][0]] += 1
            else:
                retained_items.append(deferred_positions[i])
        deferred_positions = retained_items
        # print(positions_dict[:10], max(positions_dict), deferred_positions, lag)
        if vb < valid_sellpoint[-1]:
            bin, atpoint = get_loc(vb)
            if not atpoint:
                if positions_dict[bin] < position:
                    total_profit += chosen_vt[vb]
                    # profit_position[vb] = chosen_vt[vb]
                    profit_position[valid_sellpoint[bin]+2*lag-1] += chosen_vt[vb]

                    deferred_positions.append((bin, vb + lag))
                    # print(deferred_positions)

            else:
                if positions_dict[bin+1] < position:
                    total_profit += chosen_vt[vb]
                    # profit_position[vb] = chosen_vt[vb]
                    profit_position[valid_sellpoint[bin+1]+2*lag-1] += chosen_vt[vb]

                    # deferred_positions.append((bin, vb + lag))
                    deferred_positions.append((bin+1, vb + lag))
                    # print(deferred_positions)
        else:
            print(vb, valid_sellpoint[-1], valid_sellpoint)
            print("why larger")
        # if vb > 10000:
            # break
    return total_profit, profit_position, positions_dict  



@jit
def calculate_profit_with_chosen_2(valid_sellpoint, chosen_value_total, position=5, lag=1, lag2=1):
    # print(valid_sellpoint)
    chosen_vt = chosen_value_total
    positions_dict = [0 for i in range(len(valid_sellpoint))]
    # profit_positions = [0 for i in range(len(valid_sellpoint))]
    # addedvb_positions = [[] for i in range(len(valid_sellpoint))]

    valid_buypoint = (chosen_vt != 0).nonzero()[0]
    # for i in range(len(chosen_vt)):
        # print(chosen_vt[i])
    profit_position = np.zeros(len(chosen_vt))
    def get_loc(vb):
        for i in range(len(valid_sellpoint)):
            if vb < valid_sellpoint[i]:
                return i, False
            if valid_sellpoint[i] <= vb and vb < valid_sellpoint[i] + lag + lag2 -1:
                return i, True

    total_profit = 0
    # print(len(valid_buypoint))
    deferred_positions = [(0, 0)]
    deferred_positions = deferred_positions[1:]
    # trades = []
    for vb in valid_buypoint:
        i = 0
        retained_items = []
        for i in range(len(deferred_positions)):
            if vb >= deferred_positions[i][1]:
                positions_dict[deferred_positions[i][0]] += 1
            else:
                retained_items.append(deferred_positions[i])
        deferred_positions = retained_items
        # print(positions_dict[:10], max(positions_dict), deferred_positions, lag)
        if vb < valid_sellpoint[-1]:
            bin, atpoint = get_loc(vb)
            if not atpoint:
                if positions_dict[bin] < position:
                    total_profit += chosen_vt[vb]
                    profit_position[valid_sellpoint[bin]+lag+lag2-1] += chosen_vt[vb]
                    # trades.append((vb, vb+lag, valid_sellpoint[bin]+lag-1, valid_sellpoint[bin]+lag+lag2-1))
                    deferred_positions.append((bin, vb + lag))
                    # print(deferred_positions)

            else:
                if positions_dict[bin] < position:
                    total_profit += chosen_vt[vb]
                    profit_position[valid_sellpoint[bin+1]+lag+lag2-1] += chosen_vt[vb]
                    deferred_positions.append((bin, vb + lag))
                    deferred_positions.append((bin+1, vb + lag))
                    # trades.append((vb, vb+lag, valid_sellpoint[bin+1]+lag-1, valid_sellpoint[bin+1]+lag+lag2-1))

                    # print(deferred_positions)
        else:
            print(vb, valid_sellpoint[-1], valid_sellpoint)
            print("why larger")
    return total_profit, profit_position, sum(positions_dict)

@jit
def calculate_profit_with_chosen_2(valid_sellpoint, chosen_value_total, position=5, lag=1, lag2=1):
    # print(valid_sellpoint)
    chosen_vt = chosen_value_total
    positions_dict = [0 for i in range(len(valid_sellpoint))]
    # profit_positions = [0 for i in range(len(valid_sellpoint))]
    # addedvb_positions = [[] for i in range(len(valid_sellpoint))]

    valid_buypoint = (chosen_vt != 0).nonzero()[0]
    # for i in range(len(chosen_vt)):
        # print(chosen_vt[i])
    profit_position = np.zeros(len(chosen_vt))
    def get_loc(vb):
        for i in range(len(valid_sellpoint)):
            if vb < valid_sellpoint[i]:
                return i, False
            if valid_sellpoint[i] <= vb and vb < valid_sellpoint[i] + lag + lag2 -1:
                return i, True

    total_profit = 0
    # print(len(valid_buypoint))
    deferred_positions = [(0, 0)]
    deferred_positions = deferred_positions[1:]
    for vb in valid_buypoint:
        i = 0
        retained_items = []
        for i in range(len(deferred_positions)):
            if vb >= deferred_positions[i][1]:
                positions_dict[deferred_positions[i][0]] += 1
            else:
                retained_items.append(deferred_positions[i])
        deferred_positions = retained_items
        # print(positions_dict[:10], max(positions_dict), deferred_positions, lag)
        if vb < valid_sellpoint[-1]:
            bin, atpoint = get_loc(vb)
            if not atpoint:
                if positions_dict[bin] < position:
                    total_profit += chosen_vt[vb]
                    # profit_position[vb] = chosen_vt[vb]
                    profit_position[valid_sellpoint[bin]+2*lag-1] += chosen_vt[vb]

                    deferred_positions.append((bin, vb + lag))
                    # print(deferred_positions)

            else:
                if positions_dict[bin+1] < position:
                    total_profit += chosen_vt[vb]
                    # profit_position[vb] = chosen_vt[vb]
                    profit_position[valid_sellpoint[bin+1]+2*lag-1] += chosen_vt[vb]

                    # deferred_positions.append((bin, vb + lag))
                    deferred_positions.append((bin+1, vb + lag))
                    # print(deferred_positions)
        else:
            print(vb, valid_sellpoint[-1], valid_sellpoint)
            print("why larger")
        # if vb > 10000:
            # break
    return total_profit, profit_position, positions_dict 


# @jit
# def calculate_profit_with_chosen(valid_sellpoint, chosen_value_total, position=5, lag=1):
#     # print(valid_sellpoint)
#     chosen_vt = chosen_value_total
#     positions_dict = [0 for i in range(len(valid_sellpoint))]
#     # profit_positions = [0 for i in range(len(valid_sellpoint))]
#     # addedvb_positions = [[] for i in range(len(valid_sellpoint))]

#     valid_buypoint = (chosen_vt != 0).nonzero()[0]
#     # for i in range(len(chosen_vt)):
#         # print(chosen_vt[i])
#     profit_position = np.zeros(len(chosen_vt))
#     def get_loc(vb):
#         for i in range(len(valid_sellpoint)):
#             if vb < valid_sellpoint[i]:
#                 return i, False
#             if valid_sellpoint[i] <= vb and vb < valid_sellpoint[i] + 2*lag-1:
#                 return i, True

#     total_profit = 0
#     # print(len(valid_buypoint))
#     deferred_positions = [(0, 0)]
#     deferred_positions = deferred_positions[1:]
#     for vb in valid_buypoint:
#         i = 0
#         retained_items = []
#         for i in range(len(deferred_positions)):
#             if vb >= deferred_positions[i][1]:
#                 positions_dict[deferred_positions[i][0]] += 1
#             else:
#                 retained_items.append(deferred_positions[i])
#         deferred_positions = retained_items
#         # print(positions_dict[:10], max(positions_dict), deferred_positions, lag)
#         if vb < valid_sellpoint[-1]:
#             bin, atpoint = get_loc(vb)
#             if not atpoint:
#                 if positions_dict[bin] < position:
#                     total_profit += chosen_vt[vb]
#                     # profit_position[vb] = chosen_vt[vb]
#                     profit_position[valid_sellpoint[bin]+2*lag-1] += chosen_vt[vb]

#                     deferred_positions.append((bin, vb + lag))
#                     # print(deferred_positions)

#             else:
#                 if positions_dict[bin] < position:
#                     total_profit += chosen_vt[vb]
#                     # profit_position[vb] = chosen_vt[vb]
#                     profit_position[valid_sellpoint[bin+1]+2*lag-1] += chosen_vt[vb]

#                     deferred_positions.append((bin, vb + lag))
#                     deferred_positions.append((bin+1, vb + lag))
#                     # print(deferred_positions)
#         else:
#             print(vb, valid_sellpoint[-1], valid_sellpoint)
#             print("why larger")
#         # if vb > 10000:
#             # break
#     return total_profit, profit_position, positions_dict  
model = models.__dict__[args.arch]()
model = model.cuda()
print("number of parameters:", count_parameters(model))
print(model)


bn_params = [v for n, v in list(model.named_parameters()) if ("bn" in n) and v.requires_grad]
rest_params = [v for n, v in list(model.named_parameters()) if ("bn" not in n) and v.requires_grad]

opt = torch.optim.AdamW([
    {
        "params": bn_params,
        "weight_decay": 0 if args.no_bn_decay else args.wd,
    },
    {"params": rest_params, "weight_decay": args.wd},
], lr=lr, weight_decay = args.wd)

from random import randrange
import time
args.rand_number = str(time.time())

import gym


def make_env(fulltest=False, i=0, split="train", num_envs=256, lag1=1, lag2=1):
    def thunk():
        if args.old == 38:
            env = stock.StockEnv38(fulltest, i, split, num_envs, lag1, lag2)
        elif args.old == 37:
            env = stock.StockEnv37(fulltest, i, split, num_envs, lag1, lag2)
        elif args.old == 36:
            env = stock.StockEnv36(fulltest, i, split, num_envs)
        elif args.old == 35:
            env = stock.StockEnv35(fulltest, i, split, num_envs)
        else:
            env = stock.StockEnv(fulltest, i, split, num_envs)
        return env
    return thunk



def transAct(preaction):
    if args.clamp_neg:
        action = torch.clamp(preaction, min=0)
    elif args.sigmoid_neg:
        action = torch.sigmoid(preaction)*args.sig_alpha
    elif args.exp_neg:
        action = torch.exp(preaction)
    else:
        action = preaction
    return action


if args.generate_test_predict:
    print(args.valid)
    args.rand_number = str(args.seed)
    # model = torch.load("best_model_y"+args.arch+args.y+"_"+';'.join(args.train)+"_"+';'.join(args.valid)+"_copy.pt")
    model = torch.load("results/best_model_RL"+args.arch+"_"+';'.join(args.train)+"_"+';'.join(args.valid)+"_"+';'.join(args.test2)+args.rand_number+"lagallavg.pt")
    # model = torch.jit.load("/home/xzhoubi/paperreading/results_new_3/best_model_RLTSTransformerEncoderRLSeq3_08_11-10_20_10_21-10_25_10_27-11_081669902193.173553lagallavg_script(1).pt")
    model.eval()

    old_test_dataset = stock.StockAggregate35("test4")
    d = calculate_train_RLd3_34(model, old_test_dataset, args.rlbuy_profit_path4, args.rlsell_profit_path4, args.valid_2ndsellpoint4, args.valid_2ndbuypoint4, step=0, tag="test4")
    
    
    env_num = args.num_envs
    for lag1, lag2 in [(1, 1), (1, 2), (2, 1), (2, 2)]:
        envs0 = getattr(gym.vector, args.synctype)(
            [make_env(True, i, "test4", env_num, lag1, lag2) for i in range(env_num)],
        )
        ob0 = torch.Tensor(envs0.reset()).cuda()
        reward_sum = 0
        reward_l = []
        running_steps = 0
        mask = np.ones((env_num,))
        pre_traj_index = np.zeros((env_num, 1))
        profit = np.zeros((stock.y04.shape[0], ))
        profit_clamp = np.zeros((stock.y04.shape[0], ))
        actions = np.ones((stock.y04.shape[0], )) * (-1)
        pre_traj_index_list = torch.zeros((args.num_steps*100, args.num_envs))

        dout = 4
        actions_exe = np.zeros((stock.y04.shape[0], ))
        valid_sellpoint = np.load(args.valid_2ndsellpoint4+"_"+str(lag1)+str(lag2)+".npy")
        time_index = np.load("19dout4time"+"_"+";".join(args.test4)+"std"+".npy")
        trades = {}
        for step in range(0, 2000000):
            with torch.no_grad():
                action, _ = model.get_action(ob0, argmax=True)
            ob0, reward, done0, info = envs0.step(transAct(action).cpu().numpy())
            ob0 = torch.Tensor(ob0).cuda()
            for i in range(len(info)):
                if info[i]["traj_index"] < pre_traj_index[i]:
                    mask[i] = mask[i]-1
                    if np.sum(mask==1) == 0:
                        break
                pre_traj_index[i] = info[i]["traj_index"]
                pre_traj_index_list[step][i] = info[i]["traj_index"]
                if mask[i] == 1:
                    if transAct(action[i]) < 5:
                        profit_clamp[info[i]["full_range_step"]] = (reward[i] * stock.std_profit + stock.mean_profit)*stock.abs_profit
                    profit[info[i]["full_range_step"]] = (reward[i] * stock.std_profit + stock.mean_profit)*stock.abs_profit
                    actions[info[i]["full_range_step"]] = transAct(action[i])
                    if info[i]["execute"]:
                        actions_exe[info[i]["full_range_step"]] = transAct(action[i])
                        if info[i]["traj_index"] not in trades:
                            trades[info[i]["traj_index"]] = []
                        trades[info[i]["traj_index"]].append((time_index[info[i]["full_range_step"]], time_index[valid_sellpoint[valid_sellpoint > info[i]["full_range_step"]][0]]))
                    reward_sum += (reward[i] * stock.std_profit + stock.mean_profit)*stock.abs_profit
                
            if np.sum(mask==1) == 0:
                break

        print(trades)
        print("for argmax sampler:", lag1, lag2, reward_sum, np.sum(profit),)

        import pandas as pd
        from influxdb import DataFrameClient

        client = DataFrameClient(args.ip, 8086, 'xz', 'xzquant2022', 'signal')

        data = pd.DataFrame()
        data['time'] = pd.DataFrame(time_index)
        data.index = data.time

        itemp = 'rl'+args.type+'profit_lag'+str(lag1)+str(lag2)
        b_ = 5351.4 if args.type == "buy" else 746.7
        data[itemp]=pd.DataFrame(np.cumsum(profit)*max_p*0.01+b_)
        i = 0
        for i in range(1, int(len(data[[itemp]])//1e5)):
            print((i-1)*int(1e5), i*int(1e5))
            client.write_points(data[[itemp]][(i-1)*int(1e5):i*int(1e5)], itemp, {})
        print(i*int(1e5), len(data[[itemp]]))
        client.write_points(data[[itemp]][i*int(1e5):], itemp, {}) 



        print("for argmax sampler:", lag1, lag2, reward_sum, np.sum(profit), np.sum(profit_clamp))
        print(actions_exe.shape)
        print(np.sum(actions_exe == 0), np.sum(np.logical_and(actions_exe != 0, actions_exe < 4)), np.sum(actions_exe > 4))
        print(np.sum(actions_exe == 0), np.sum(np.logical_and(actions_exe != 0, actions_exe < 5)), np.sum(actions_exe > 5))
        print(np.sum(actions_exe == 0), np.sum(np.logical_and(actions_exe != 0, actions_exe < 6)), np.sum(actions_exe > 6))
        print(np.sum(actions_exe == 0), np.sum(np.logical_and(actions_exe != 0, actions_exe < 7)), np.sum(actions_exe > 7))
        print(np.sum(actions_exe == 0), np.sum(np.logical_and(actions_exe != 0, actions_exe < 10)), np.sum(actions_exe > 10))


        print(np.sum(actions == 0), np.sum(np.logical_and(actions != 0, actions < 4)), np.sum(actions > 4))
        print(np.sum(actions == 0), np.sum(np.logical_and(actions != 0, actions < 5)), np.sum(actions > 5))
        print(np.sum(actions == 0), np.sum(np.logical_and(actions != 0, actions < 6)), np.sum(actions > 6))
        print(np.sum(actions == 0), np.sum(np.logical_and(actions != 0, actions < 7)), np.sum(actions > 7))
        print(np.sum(actions == 0), np.sum(np.logical_and(actions != 0, actions < 10)), np.sum(actions > 10))

        lines_position = []
        
        y0 = np.load(args.rlbuy_profit_path4+"_"+str(lag1)+str(lag2)+".npy")
        for pos in [args.pos]:
            for j in range(0, args.d_num-1): 
                p, profit_fix_position, pos_dict = calculate_profit_with_chosen(valid_sellpoint, y0[:, j], position=5, lag=lag1, lag2=lag2)
                lines_position.append(np.cumsum(profit_fix_position))
            
        fig, ax1 = plt.subplots()
        fig.set_figwidth(16)
        fig.set_figheight(12)
        for j in range(args.start, args.d_num-1):
            ax1.plot(lines_position[j][::interval], label=str(j))
        ax1.plot(np.cumsum(profit)[::interval], label="rl")
        plt.legend()
        plt.show()
        plt.savefig("results_new_3/result_"+args.arch+";".join(args.test4)+"RLfix"+args.type+"position"+str(5)+args.rand_number+str(lag1)+str(lag2)+".png")
        np.save("lines_poisiton.npy"+args.rand_number, lines_position)
        np.save("profit.npy"+args.rand_number, np.cumsum(profit))
    
    exit(-1)



envs = getattr(gym.vector, args.synctype)(
    [make_env(num_envs=args.num_envs)] * args.num_envs,
)

obs = torch.zeros((args.num_steps, args.num_envs, args.input_size, args.T))
actions = torch.zeros((args.num_steps, args.num_envs))
logprobs = torch.zeros((args.num_steps, args.num_envs))
rewards = torch.zeros((args.num_steps, args.num_envs))
dones = torch.zeros((args.num_steps, args.num_envs))
execute_point = torch.zeros((args.num_steps, args.num_envs))

envs.reset()
ob = torch.Tensor(envs.reset()).cuda()
done = torch.zeros(args.num_envs)
max_p = np.zeros((4, ))
pathwise_p = np.zeros((epochs, 4))
max_p_sum = 0
max_p_itr_all = 0
for epoch in range(epochs):
    model.eval()
    if epoch >= args.start:
        for lag1, lag2 in [(1, 1), (1, 2), (2, 1), (2, 2)]:
            envs0 = getattr(gym.vector, args.synctype)(
                [make_env(True, i, "train", 256, lag1, lag2) for i in range(256)],
            )
            ob0 = torch.Tensor(envs0.reset()).cuda()
            reward_sum = 0
            reward_l = []
            running_steps = 0
            mask = np.ones((256,))
            pre_traj_index = np.zeros((256, 1))
            profit_tr = np.zeros((stock.y01.shape[0], ))

            for step in range(0, 4000000):
                with torch.no_grad():
                    action, _ = model.get_action(ob0, argmax=True)
                ob0, reward, done0, info = envs0.step(transAct(action).cpu().numpy())
                ob0 = torch.Tensor(ob0).cuda()
                for i in range(len(info)):
                    if info[i]["traj_index"] < pre_traj_index[i]:
                        mask[i] = 0 
                    pre_traj_index[i] = info[i]["traj_index"]
                    if mask[i] != 0:
                        profit_tr[info[i]["full_range_step"]] = (reward[i] * stock.std_profit + stock.mean_profit)*stock.abs_profit
                        reward_sum += (reward[i] * stock.std_profit + stock.mean_profit)*stock.abs_profit
                    # reward_sum += (reward[i] * stock.std_profit + stock.mean_profit)*stock.abs_profit
                    
                if np.sum(mask) == 0:
                    break
            running_steps = step
            print("for argmax sampler:", reward_sum, np.sum(profit_tr), reward_sum/running_steps)
            if lag1*lag2 == 1:
                wandb.log({"train/reward_sum": reward_sum}, step=epoch)
            else:
                wandb.log({"train/reward_sum"+str(lag1)+str(lag2): reward_sum}, step=epoch)



            envs0 = getattr(gym.vector, args.synctype)(
                [make_env(True, i, "test", 256, lag1, lag2) for i in range(256)],
            )
            ob0 = torch.Tensor(envs0.reset()).cuda()
            reward_sum = 0
            reward_l = []
            running_steps = 0
            mask = np.ones((256,))
            pre_traj_index = np.zeros((256, 1))
            profit0 = np.zeros((stock.y02.shape[0], ))
            for step in range(0, 4000000):
                with torch.no_grad():
                    action, _ = model.get_action(ob0, argmax=True)
                ob0, reward, done0, info = envs0.step(transAct(action).cpu().numpy())
                ob0 = torch.Tensor(ob0).cuda()
                for i in range(len(info)):
                    if info[i]["traj_index"] < pre_traj_index[i]:
                        mask[i] = 0 
                    pre_traj_index[i] = info[i]["traj_index"]
                    if mask[i] != 0:
                        profit0[info[i]["full_range_step"]] = (reward[i] * stock.std_profit + stock.mean_profit)*stock.abs_profit
                        reward_sum += (reward[i] * stock.std_profit + stock.mean_profit)*stock.abs_profit
                if np.sum(mask) == 0:
                    break
            running_steps = step
            print("for argmax sampler:", reward_sum, np.sum(profit0), reward_sum/running_steps)
            if lag1*lag2 == 1:
                wandb.log({"test/reward_sum": reward_sum}, step=epoch)
            else:
                wandb.log({"test/reward_sum"+str(lag1)+str(lag2): reward_sum}, step=epoch)
            reward_sum0 = reward_sum
            

            envs0 = getattr(gym.vector, args.synctype)(
                [make_env(True, i, "test2", 256, lag1, lag2) for i in range(256)],
            )
            ob0 = torch.Tensor(envs0.reset()).cuda()
            reward_sum = 0
            reward_l = []
            running_steps = 0
            mask = np.ones((256,))
            pre_traj_index = np.zeros((256, 1))
            profit2 = np.zeros((stock.y03.shape[0], ))
            for step in range(0, 4000000):
                with torch.no_grad():
                    action, _ = model.get_action(ob0, argmax=True)
                ob0, reward, done0, info = envs0.step(transAct(action).cpu().numpy())
                ob0 = torch.Tensor(ob0).cuda()
                for i in range(len(info)):
                    if info[i]["traj_index"] < pre_traj_index[i]:
                        mask[i] = 0 
                    pre_traj_index[i] = info[i]["traj_index"]
                    if mask[i] != 0:
                        profit2[info[i]["full_range_step"]] = (reward[i] * stock.std_profit + stock.mean_profit)*stock.abs_profit
                        reward_sum += (reward[i] * stock.std_profit + stock.mean_profit)*stock.abs_profit
                if np.sum(mask) == 0:
                    break

            

            running_steps = step
            print("for argmax sampler:", reward_sum, np.sum(profit2), reward_sum/running_steps)

            if lag1*lag2 == 1:
                wandb.log({"test2/reward_sum": reward_sum}, step=epoch)
            else:
                wandb.log({"test2/reward_sum"+str(lag1)+str(lag2): reward_sum}, step=epoch)
            reward_sum2 = reward_sum
            pathwise_p[epoch][2*(lag1-1)+lag2-1] = reward_sum2+reward_sum0
            best_epoch = False
            if reward_sum2+reward_sum0 >= max_p[2*(lag1-1)+lag2-1]:
                max_p[2*(lag1-1)+lag2-1] = reward_sum2+reward_sum0
                max_p_itr = epoch
                best_epoch = True
                torch.save(model, "results/best_model_RL"+args.arch+"_"+';'.join(args.train)+"_"+';'.join(args.test)+"_"+';'.join(args.test2)+args.rand_number+"lag"+str(lag1)+str(lag2)+".pt")
            print("max_p_itr, max_p, rand_number", max_p_itr, max_p, args.rand_number)


            if best_epoch:
                lines_position0 = []
                y0 = np.load(args.rlbuy_profit_path2+"_"+str(lag1)+str(lag2)+".npy")
                valid_sellpoint = np.load(args.valid_2ndsellpoint2+"_"+str(lag1)+str(lag2)+".npy")
                for pos in [args.pos]:
                    for j in range(0, args.d_num-1): 
                        p, profit_fix_position, pos_dict = calculate_profit_with_chosen(valid_sellpoint, y0[:, j], position=5, lag=lag1, lag2=lag2)
                        lines_position0.append(profit_fix_position)
                fig, ax1 = plt.subplots()
                fig.set_figwidth(16)
                fig.set_figheight(12)
                for j in range(args.start, args.d_num-1):
                    ax1.plot(np.cumsum(lines_position0[j])[::interval], label=str(j))
                ax1.plot(np.cumsum(profit0)[::interval], label="rl")
                plt.legend()
                plt.show()
                plt.savefig("results_new_2/result_"+args.arch+";".join(args.test)+"RLfix"+args.type+"position"+str(5)+args.rand_number+str(lag1)+str(lag2)+".png")
                plt.close('all')

                lines_position = []
                y0 = np.load(args.rlbuy_profit_path+"_"+str(lag1)+str(lag2)+".npy")
                valid_sellpoint = np.load(args.valid_2ndsellpoint+"_"+str(lag1)+str(lag2)+".npy")
                for pos in [args.pos]:
                    for j in range(0, args.d_num-1): 
                        p, profit_fix_position, pos_dict = calculate_profit_with_chosen(valid_sellpoint, y0[:, j], position=5, lag=lag1, lag2=lag2)
                        lines_position.append(profit_fix_position)
                fig, ax1 = plt.subplots()
                fig.set_figwidth(16)
                fig.set_figheight(12)
                for j in range(args.start, args.d_num-1):
                    ax1.plot(np.cumsum(lines_position[j])[::interval], label=str(j))
                ax1.plot(np.cumsum(profit_tr)[::interval], label="rl")
                plt.legend()
                plt.show()
                plt.savefig("results_new_2/result_"+args.arch+";".join(args.train)+"RLfix"+args.type+"position"+str(5)+args.rand_number+str(lag1)+str(lag2)+".png")
                plt.close('all')

            if best_epoch:
                lines_position2 = []
                y0 = np.load(args.rlbuy_profit_path3+"_"+str(lag1)+str(lag2)+".npy")
                valid_sellpoint = np.load(args.valid_2ndsellpoint3+"_"+str(lag1)+str(lag2)+".npy")
                for pos in [args.pos]:
                    for j in range(0, args.d_num-1): 
                        p, profit_fix_position, pos_dict = calculate_profit_with_chosen(valid_sellpoint, y0[:, j], position=5, lag=lag1, lag2=lag2)
                        lines_position2.append(profit_fix_position)
                fig, ax1 = plt.subplots()
                fig.set_figwidth(16)
                fig.set_figheight(12)
                for j in range(args.start, args.d_num-1):
                    ax1.plot(np.cumsum(lines_position2[j])[::interval], label=str(j))
                ax1.plot(np.cumsum(profit2)[::interval], label="rl")
                plt.legend()
                plt.show()
                plt.savefig("results_new_2/result_"+args.arch+";".join(args.test2)+"RLfix"+args.type+"position"+str(5)+args.rand_number+str(lag1)+str(lag2)+".png")
                plt.close('all')

            envs0 = getattr(gym.vector, args.synctype)(
                [make_env(True, i, "test4", 256, lag1, lag2) for i in range(256)],
            )
            ob0 = torch.Tensor(envs0.reset()).cuda()
            reward_sum = 0
            reward_l = []
            running_steps = 0
            mask = np.ones((256,))
            pre_traj_index = np.zeros((256, 1))
            profit4 = np.zeros((stock.y04.shape[0], ))
            for step in range(0, 4000000):
                with torch.no_grad():
                    action, _ = model.get_action(ob0, argmax=True)
                ob0, reward, done0, info = envs0.step(transAct(action).cpu().numpy())
                ob0 = torch.Tensor(ob0).cuda()
                for i in range(len(info)):
                    if info[i]["traj_index"] < pre_traj_index[i]:
                        mask[i] = 0 
                    pre_traj_index[i] = info[i]["traj_index"]
                    if mask[i] != 0:
                        profit4[info[i]["full_range_step"]] = (reward[i] * stock.std_profit + stock.mean_profit)*stock.abs_profit
                        reward_sum += (reward[i] * stock.std_profit + stock.mean_profit)*stock.abs_profit
                if np.sum(mask) == 0:
                    break
            running_steps = step
            print("for argmax sampler:", reward_sum, np.sum(profit4), reward_sum/running_steps)
            if lag1*lag2 == 1:
                wandb.log({"test4/reward_sum": reward_sum}, step=epoch)
                wandb.log({"test4+2/reward_sum": reward_sum+reward_sum2}, step=epoch) 
                wandb.log({"test4+2+0/reward_sum": reward_sum+reward_sum2+reward_sum0}, step=epoch) 
                wandb.log({"test2+0/reward_sum": reward_sum2+reward_sum0}, step=epoch) 
            else:
                wandb.log({"test4/reward_sum"+str(lag1)+str(lag2): reward_sum}, step=epoch)
                wandb.log({"test4+2/reward_sum"+str(lag1)+str(lag2): reward_sum+reward_sum2}, step=epoch) 
                wandb.log({"test4+2+0/reward_sum"+str(lag1)+str(lag2): reward_sum+reward_sum2+reward_sum0}, step=epoch) 
                wandb.log({"test2+0/reward_sum"+str(lag1)+str(lag2): reward_sum2+reward_sum0}, step=epoch) 


            if best_epoch:
                lines_position4 = []
                y0 = np.load(args.rlbuy_profit_path4+"_"+str(lag1)+str(lag2)+".npy")
                valid_sellpoint = np.load(args.valid_2ndsellpoint4+"_"+str(lag1)+str(lag2)+".npy")
                for pos in [args.pos]:
                    for j in range(0, args.d_num-1): 
                        p, profit_fix_position, pos_dict = calculate_profit_with_chosen(valid_sellpoint, y0[:, j], position=5, lag=lag1, lag2=lag2)
                        lines_position4.append(profit_fix_position)
                fig, ax1 = plt.subplots()
                fig.set_figwidth(16)
                fig.set_figheight(12)
                for j in range(args.start, args.d_num-1):
                    ax1.plot(np.cumsum(lines_position4[j])[::interval], label=str(j))
                ax1.plot(np.cumsum(profit4)[::interval], label="rl")
                plt.legend()
                plt.show()
                plt.savefig("results_new_2/result_"+args.arch+";".join(args.test4)+"RLfix"+args.type+"position"+str(5)+args.rand_number+str(lag1)+str(lag2)+".png")
                plt.close('all')

            if best_epoch:
                fig, ax1 = plt.subplots()
                fig.set_figwidth(16)
                fig.set_figheight(12)
                for j in range(args.start, args.d_num-1):
                    ax1.plot(np.cumsum(np.concatenate([lines_position2[j], lines_position4[j]], axis=0))[::interval], label=str(j))
                ax1.plot(np.cumsum(np.concatenate([profit2, profit4], axis=0))[::interval], label="rl")
                plt.legend()
                plt.show()
                plt.savefig("results_new_2/result_"+args.arch+";".join(args.test2)+";".join(args.test4)+"RLfix"+args.type+"position"+str(5)+args.rand_number+str(lag1)+str(lag2)+".png")
                plt.close('all')

                fig, ax1 = plt.subplots()
                fig.set_figwidth(16)
                fig.set_figheight(12)
                for j in range(args.start, args.d_num-1):
                    ax1.plot(np.cumsum(np.concatenate([lines_position0[j], lines_position2[j], lines_position4[j]], axis=0))[::interval], label=str(j))
                ax1.plot(np.cumsum(np.concatenate([profit0, profit2, profit4], axis=0))[::interval], label="rl")
                plt.legend()
                plt.show()
                plt.savefig("results_new_2/result_"+args.arch+";".join(args.test)+";".join(args.test2)+";".join(args.test4)+"RLfix"+args.type+"position"+str(5)+args.rand_number+str(lag1)+str(lag2)+".png")
                plt.close('all')

                fig, ax1 = plt.subplots()
                fig.set_figwidth(16)
                fig.set_figheight(12)
                for j in range(args.start, args.d_num-1):
                    ax1.plot(np.cumsum(np.concatenate([lines_position0[j], lines_position2[j]], axis=0))[::interval], label=str(j))
                ax1.plot(np.cumsum(np.concatenate([profit0, profit2], axis=0))[::interval], label="rl")
                plt.legend()
                plt.show()
                plt.savefig("results_new_2/result_"+args.arch+";".join(args.test)+";".join(args.test2)+"RLfix"+args.type+"position"+str(5)+args.rand_number+str(lag1)+str(lag2)+".png")
                plt.close('all')
            if lag1 == 2 and lag2 == 2 and np.sum(pathwise_p[epoch]) > max_p_sum:
                max_p_sum = np.sum(pathwise_p[epoch])
                max_p_itr_all = epoch
                torch.save(model, "results/best_model_RL"+args.arch+"_"+';'.join(args.train)+"_"+';'.join(args.test)+"_"+';'.join(args.test2)+args.rand_number+"epoch"+str(epoch)+"lagallavg.pt")

            print("All avg max_p_itr, max_p_sum, rand_number", max_p_itr_all, max_p_sum, args.rand_number)

    # envs0 = stock.StockEnv(True)
    # ob0 = torch.Tensor(envs0.reset()).cuda()
    # reward_sum = 0
    # reward_l = []
    # running_steps = 0
    
    # for step in range(0, 4000000):
    #     with torch.no_grad():
    #         action, _, _, _ = model.get_action_and_value(ob0.unsqueeze(0).cuda())
    #     # print("action.size(), logprob.size(), value.size()", action.size(), logprob.size(), value.size())
    #     # print("action", step, action)
    #     ob0, reward, done, info = envs0.step(action.cpu().numpy())
        
    #     # print("reward, done, info", reward, done, info)
    #     if ob0 == "False":
    #         break
    #     else:
    #         # print((reward * stock.std_profit + stock.mean_profit)*stock.abs_profit, info)
    #         reward_sum += (reward.astype(float) * stock.std_profit + stock.mean_profit)*stock.abs_profit
    #         # reward_l.append((reward.astype(float) * stock.std_profit + stock.mean_profit)*stock.abs_profit)
    # running_steps = step
    # print("for random sampler:", reward_sum, reward_sum/running_steps)
    # # print(reward_l)

    for step in range(0, args.num_steps):
        obs[step] = ob.detach().cpu()
        dones[step] = done 
        with torch.no_grad():
            action, logprob = model.get_action(ob)
            # print(action, logprob)
        actions[step] = action
        logprobs[step] = logprob

        ob, reward, done, info = envs.step(transAct(action).cpu().numpy())
        for i in range(len(info)):
            # print(i, info[i]["execute"])
            execute_point[step][i] = info[i]["execute"]
        rewards[step] = torch.tensor(reward).cuda().view(-1)
        ob, done = torch.Tensor(ob).cuda(), torch.Tensor(done)
    
    with torch.no_grad():
        for env in range(args.num_envs):
            execute_points_bucket = []
            done_point = 0
            for j in range(args.num_steps):
                if dones[j][env] == True:
                    # print("startpoint", j)
                    done_point = j
                    execute_points_bucket = []
                if execute_point[j][env] and j-done_point-len(execute_points_bucket) > 0:
                    # print(j, len(execute_points_bucket), j-done_point-len(execute_points_bucket), rewards[j][env])
                    # print(rewards.shape, done_point, j)
                    # print(rewards[j][env])
                    # print(rewards[done_point:j],rewards[done_point:j].shape, rewards[done_point], rewards[done_point].shape)
                    # print(rewards[done_point:j, env])
                    rewards[done_point:j, env] += rewards[j][env] * (1-args.remaining)/(j-done_point-len(execute_points_bucket))
                    for ep in execute_points_bucket:
                        # print(ep, rewards[j][env] * (1-args.remaining)/(j-done_point-len(execute_points_bucket)), rewards[j][env], (1-args.remaining)/(j-done_point-len(execute_points_bucket)) )
                        rewards[ep][env] -= rewards[j][env] * (1-args.remaining)/(j-done_point-len(execute_points_bucket))
                    rewards[j][env] = rewards[j][env] * args.remaining
                    execute_points_bucket.append(j)
                    # print(execute_points_bucket)
    
    with torch.no_grad():
        next_value = 0
        returns = torch.zeros_like(rewards)
        for t in reversed(range(args.num_steps)):
            if t == args.num_steps - 1:
                nextnonterminal = 1.0 - done
                next_return = next_value
            else:
                nextnonterminal = 1.0 - dones[t + 1]
                next_return = returns[t + 1]
            returns[t] = rewards[t] + args.gamma * nextnonterminal * next_return

    env_endpoint = torch.zeros((args.num_envs, ))
    for env in range(args.num_envs):
        for j in range(args.num_steps-1, 0, -1):
            if dones[j, env] == True:
                env_endpoint[env] = j
                break
    sample_length = int(torch.sum(env_endpoint).item())
    print("rewards, values", returns.mean(), rewards.mean())

    b_obs = torch.zeros((sample_length, args.input_size, args.T))
    b_logprobs = torch.zeros((sample_length,))
    b_actions = torch.zeros((sample_length,))
    b_returns = torch.zeros((sample_length,))
    start, end = 0, 0
    for env in range(args.num_envs):
        end += int(env_endpoint[env].item())
        b_obs[start:end] = obs[:int(env_endpoint[env].item()), env]
        b_logprobs[start:end] = logprobs[:int(env_endpoint[env].item()), env]
        b_actions[start:end] = actions[:int(env_endpoint[env].item()), env]
        b_returns[start:end] = returns[:int(env_endpoint[env].item()), env]
        start = end

    train_dataset = stock.StockAggregate36(b_obs, b_logprobs, b_actions, b_returns)
    train_loader = torch.utils.data.DataLoader(train_dataset, batch_size=args.batch_size, shuffle=True, num_workers=8, pin_memory=True)
    train(model, train_loader, opt, epoch)
    
