import numpy as np
import pandas as pd
from args import args
import datetime
import matplotlib.dates as dates
import matplotlib.pyplot as plt


def genflist(date_list):
    print(date_list)
    start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
    print(start_month, start_day, end_month, end_day)
    start = datetime.date(2022,start_month,start_day)
    end = datetime.date(2022,end_month,end_day)
    x_l = []
    print(start, end)
    for i in range((end-start).days+1):
        day = start + datetime.timedelta(days=i)
        month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
        day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
        x_l.append(month_str+'_'+day_str)
    return x_l

print(args.test, "???")
flist = genflist(args.test[0])
print(flist)
filename = "fu"
data = pd.DataFrame()

first = True
for file in flist:
    if first:
        data = pd.read_pickle('data_6/data_'+file+'.pkl')
        print(data['sellprice_'+filename])
        print(data['sellpriceT_'+filename])
        print(data.shape)
        first = False
        with open('data_6/y_'+file+'.npy', 'rb') as f:
            y_true = np.load(f)
        # break
    else:
        tmp = pd.read_pickle('data_6/data_'+file+'.pkl')
        print(data['sellprice_'+filename])
        print(data['sellpriceT_'+filename])
        print(tmp.shape)
        data = pd.concat([data, tmp])

        with open('data_6/y_'+file+'.npy', 'rb') as f:
            tmp = np.load(f)
        y_true = np.concatenate((y_true, tmp), axis=0)

with open("data_7/y0_"+args.arch+"_"+";".join(args.train)+"_"+";".join(args.valid)+"_"+";".join(args.test)+str(args.rand_number0)+".npy", 'rb') as f:
    y_predict0 = np.load(f)[:len(data)]

timepoint = args.timepoint

def backtest_7(a, b, d, y, type, thres, thres2=0, din=4, din_rl=None):
    total_profit = 0
    cnt = 0
    takercnt = 0

    data['mid_fu'] = data['ap1_fu']/2+data['bp1_fu']/2
    data['predict1']=pd.DataFrame(y, index = data.index)

    p1='predict1'
    resl = []
    lag = 0 
    filename='fu'
    buy_prices = []
    sell_prices = []
    volume_buy = [0]
    volume_sell = [0] 
    
    def buy_logic(buy_prices, volume_buy, volume_sel, buy_closed, din=4):
        delta_profit = 0
        buy_price = None

        if volume_buy[0] - volume_sell[0] < thres: #因为买入的现在是不知道买没买的，所以卖不了
            buy_price = data['bp1_'+filename][i]*(1-din/1e4)
            if type == "predict":
                buy_price *= (1+np.clip(4*(data[p1][i]-0.0)/1e4, -20/1e4, 0/1e4))
            tpb = data['sellpriceT_'+filename][i+1]                
                
        if data[p1][i] < -b:
            sell_price = data['bp1_fu'][i+5]*(1.0)
            volume_buy[0] -= len(buy_prices)
            for k in range(len(buy_prices)):
                delta_profit += sell_price / buy_prices[k] - 1 - 2/1e4
            buy_prices = []
            # return delta_profit, buy_prices
        else:
            sell_price = data['ap1_'+filename][i]*(1+d/1e4)
            if type == "predict":
                sell_price *= (1+np.clip(2*(data[p1][i]+0.0)/1e4,-0/1e4, 20/1e4))
            tp = data['buypriceT_'+filename][i+1]
            if tp >= sell_price+0.01 and tp != 0:
                volume_buy[0] -= len(buy_prices)
                for k in range(len(buy_prices)):
                    delta_profit += sell_price / buy_prices[k] - 1 + 0.4/1e4
                buy_prices = []
        
        if buy_price is not None and tpb <= buy_price-0.01 and tpb != 0:
            volume_buy[0] += 1
            delta_profit += 0.4/1e4
            buy_prices.append(buy_price)
        
        return delta_profit, buy_prices

    def sell_logic(buy_prices, sell_prices, volume_buy, volume_sell, sell_closed):
        delta_profit = 0
        sell_price = None
        if volume_buy[0] - volume_sell[0] > -thres:
            sell_price = data['ap1_'+filename][i]*(1+d/1e4)
            if type == "predict":
                sell_price *= (1+np.clip(4*(data[p1][i]+0.0)/1e4,-0/1e4, 20/1e4))
            tps = data['buypriceT_'+filename][i+1]
            
        if data[p1][i] > b:
            buy_price = data['ap1_fu'][i+5]*(1.0)
            volume_sell[0] -= len(sell_prices)
            for k in range(len(sell_prices)):
                delta_profit += sell_prices[k] / buy_price - 1 - 2/1e4
            sell_prices = []
        else:
            buy_price = data['bp1_'+filename][i]*(1-d/1e4)
            if type == "predict":
                buy_price *= (1+np.clip(2*(data[p1][i]-0.0)/1e4, -20/1e4, 0/1e4))
            tp = data['sellpriceT_'+filename][i+1]
            if tp <= buy_price-0.01 and tp != 0:
                volume_sell[0] -= len(sell_prices)
                for k in range(len(sell_prices)):
                    delta_profit += sell_prices[k] / buy_price - 1 + 0.4/1e4
                sell_prices = []

        if sell_price is not None and tps >= sell_price+0.01 and tps != 0:
            volume_sell[0] += 1
            delta_profit += 0.4/1e4
            sell_prices.append(sell_price)

        return delta_profit, sell_prices


    for i in range(0, len(data)-1-lag):
        # print(i)
        if i+5 >= len(data):
            total_profit -= 0.4/1e4 * (len(buy_prices)+len(sell_prices))
            break
        if din_rl is not None:
            din = din_rl[i]
        # print(din)
        delta_profit, buy_prices = buy_logic(buy_prices, volume_buy, volume_sell, False, din=din)
        total_profit += delta_profit
        delta_profit, sell_prices = sell_logic(buy_prices, sell_prices, volume_buy, volume_sell, False)
        total_profit += delta_profit
        resl.append((data.index[i], total_profit))
        if i > timepoint: 
            break
    print(total_profit, cnt, takercnt)
    return total_profit, cnt, takercnt, resl, volume_buy, volume_sell


def backtest_8(a, b, d, y, type, thres, thres2=0, din=4, din_rl=None):
    total_profit = 0
    cnt = 0
    takercnt = 0

    data['mid_fu'] = data['ap1_fu']/2+data['bp1_fu']/2
    data['predict1']=pd.DataFrame(y, index = data.index)

    p1='predict1'
    resl = []
    lag = 0 
    filename='fu'
    buy_prices = []
    sell_prices = []
    volume_buy = [0]
    volume_sell = [0] 
    
    def buy_logic(buy_prices, volume_buy, volume_sel, buy_closed, din=4):
        delta_profit = 0
        buy_price = None

        buy_price = data['bp1_'+filename][i]*(1-din/1e4)
        if type == "predict":
            buy_price *= (1+np.clip(4*(data[p1][i]-0.0)/1e4, -20/1e4, 0/1e4))
        tpb = data['sellpriceT_'+filename][i+1]                
                
        sell_price = data['ap1_'+filename][i]*(1+d/1e4)
        if type == "predict":
            sell_price *= (1+np.clip(2*(data[p1][i]+0.0)/1e4,-0/1e4, 20/1e4))
        tp = data['buypriceT_'+filename][i+1]
        if tp >= sell_price+0.01 and tp != 0:
            volume_buy[0] -= len(buy_prices)
            for k in range(len(buy_prices)):
                delta_profit += sell_price / buy_prices[k] - 1 + 0.4/1e4
            buy_prices = []
        
        if buy_price is not None and tpb <= buy_price-0.01 and tpb != 0:
            volume_buy[0] += 1
            delta_profit += 0.4/1e4
            buy_prices.append(buy_price)
        
        return delta_profit, buy_prices

    def sell_logic(buy_prices, sell_prices, volume_buy, volume_sell, sell_closed):
        delta_profit = 0
        sell_price = None
        if volume_buy[0] - volume_sell[0] > -thres:
            sell_price = data['ap1_'+filename][i]*(1+d/1e4)
            if type == "predict":
                sell_price *= (1+np.clip(4*(data[p1][i]+0.0)/1e4,-0/1e4, 20/1e4))
            tps = data['buypriceT_'+filename][i+1]
            
        if data[p1][i] > b:
            buy_price = data['ap1_fu'][i+5]*(1.0)
            volume_sell[0] -= len(sell_prices)
            for k in range(len(sell_prices)):
                delta_profit += sell_prices[k] / buy_price - 1 - 2/1e4
            sell_prices = []
        else:
            buy_price = data['bp1_'+filename][i]*(1-d/1e4)
            if type == "predict":
                buy_price *= (1+np.clip(2*(data[p1][i]-0.0)/1e4, -20/1e4, 0/1e4))
            tp = data['sellpriceT_'+filename][i+1]
            if tp <= buy_price-0.01 and tp != 0:
                volume_sell[0] -= len(sell_prices)
                for k in range(len(sell_prices)):
                    delta_profit += sell_prices[k] / buy_price - 1 + 0.4/1e4
                sell_prices = []

        if sell_price is not None and tps >= sell_price+0.01 and tps != 0:
            volume_sell[0] += 1
            delta_profit += 0.4/1e4
            sell_prices.append(sell_price)

        return delta_profit, sell_prices


    for i in range(0, len(data)-1-lag):
        # print(i)
        if i+5 >= len(data):
            total_profit -= 0.4/1e4 * (len(buy_prices)+len(sell_prices))
            break
        if din_rl is not None:
            din = din_rl[i]
        # print(din)
        delta_profit, buy_prices = buy_logic(buy_prices, volume_buy, volume_sell, False, din=din)
        total_profit += delta_profit
        delta_profit, sell_prices = sell_logic(buy_prices, sell_prices, volume_buy, volume_sell, False)
        total_profit += delta_profit
        resl.append((data.index[i], total_profit))
        if i > timepoint: 
            break
    print(total_profit, cnt, takercnt)
    return total_profit, cnt, takercnt, resl, volume_buy, volume_sell

import pickle
dic = {}
for a in [1.0]:
    for b in [1000]:
            for d in [4]:
                import matplotlib.pyplot as plt
                fig, ax1 = plt.subplots()
                fig.set_figwidth(16)
                fig.set_figheight(12)
                ax2 = ax1.twinx()
                # total_profit1, cnt2, takercnt2, resl1, volume_buy4, volume_sell4= backtest_8(a, b, d, y_predict0, "predict", 1, 100, din=4)   
                # total_profit1, cnt2, takercnt2, resl2, volume_buy4, volume_sell4= backtest_8(a, b, d, y_predict0, "predict", 5, 100, din=4)   
                total_profit1, cnt2, takercnt2, resl3, volume_buy4, volume_sell4= backtest_8(a, b, d, y_predict0, "predict", 10000, 100, din=4)   

                ax1.plot(*zip(*resl1))
                ax1.plot(*zip(*resl2))
                ax1.plot(*zip(*resl3))
                plt.grid()
                ax2.plot(data.index, (data['mid_fu']), color='blue')
                plt.title(args.arch+";a:"+str(a)+"b:"+str(b)+"d:"+str(d))
                plt.legend()
                plt.show()
                plt.savefig("result"+args.arch+";".join(args.train)+"_"+";".join(args.valid)+"_"+";".join(args.test)+str(a)+"_"+str(b)+"_"+str(d)+"compare.png")
