echo $1
for wdate in "11_19" "11_20" "11_21" "11_22" "11_23" "11_24" "11_25" "11_26" "11_27" "11_28" "11_29" "11_30" "12_01"
do  
# mv data_6/x_$wdate.npy  data_6/x2_$wdate.npy 
cat data_6/x2_$wdate.a? > data_6/x2_$wdate.npy 
echo "x"$wdate
#cat data_6/xabs_$wdate.a? > data_6/x_abs_$wdate.npy 
#echo "xabs_"$wdate
done  

