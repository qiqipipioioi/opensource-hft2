import numpy as np
import torch
from args import args
if False:
    indices = [*range(0, 48)] + [*range(153, 258)]
    # x = (torch.load("x_shuffuled.pt")[:, indices]).numpy()
    # y = torch.load("y_shuffuled.pt").numpy()
    x = x[:, indices]
    print(x.shape, y.shape)

    train_lim = 800000
    val_lim = 950000
    test_lim = -1
    from sklearn.model_selection import cross_val_score
    from sklearn.linear_model import Ridge
    from sklearn.preprocessing import StandardScaler

    scaler = StandardScaler(with_mean=False)
    # scaler = StandardScaler()
    x = scaler.fit_transform(x)

    linear = Ridge(fit_intercept=False, alpha=100)
    linear.fit(x[:train_lim], y[:train_lim])
    r2_train = linear.score(x[:train_lim], y[:train_lim])
    loss_train = ((linear.predict(x[:train_lim]) - y[:train_lim]) ** 2).mean()
    y_hat = torch.from_numpy(linear.predict(x[:train_lim]))
    y_true = torch.from_numpy(y[:train_lim])
    print(y_true.shape, y_hat.shape)
    corr_train = abs(np.corrcoef(torch.cat((y_true.unsqueeze(1), y_hat.unsqueeze(1)), 1).t().detach().cpu().numpy())[0, 1])
    print(corr_train)
    r2_val = linear.score(x[train_lim:val_lim], y[train_lim:val_lim])
    loss_val = ((linear.predict(x[train_lim:val_lim]) - y[train_lim:val_lim]) ** 2).mean()
    y_hat = torch.from_numpy(linear.predict(x[train_lim:val_lim]))
    y_true = torch.from_numpy(y[train_lim:val_lim])
    print(y_true.shape, y_hat.shape)
    corr_val = abs(np.corrcoef(torch.cat((y_true.unsqueeze(1), y_hat.unsqueeze(1)), 1).t().detach().cpu().numpy())[0, 1])
    print(corr_val)
    r2_test = linear.score(x[val_lim:test_lim], y[val_lim:test_lim])
    loss_test = ((linear.predict(x[val_lim:test_lim]) - y[val_lim:test_lim]) ** 2).mean()
    y_hat = torch.from_numpy(linear.predict(x[val_lim:test_lim]))
    y_true = torch.from_numpy(y[val_lim:test_lim])
    print(y_true.shape, y_hat.shape)
    corr_test = abs(np.corrcoef(torch.cat((y_true.unsqueeze(1), y_hat.unsqueeze(1)), 1).t().detach().cpu().numpy())[0, 1])
    print(corr_test)
    print(loss_train, r2_train, r2_val, loss_val, r2_test, loss_test)

# with open('x.npy', 'rb') as f:
#     x = np.load(f)
# with open('y.npy', 'rb') as f:
#     y = np.load(f)

# with open('x2.npy', 'rb') as f:
#     x2 = np.load(f)
# with open('y2.npy', 'rb') as f:
#     y2 = np.load(f)

if False:

    with open('data_4/xnn_05_24.npy', 'rb') as f:
        x = np.load(f)
    with open('data_4/xnn_05_25.npy', 'rb') as f:
        x2 = np.load(f)

    with open('data_4/y_05_24.npy', 'rb') as f:
        y = np.load(f)
    with open('data_4/y_05_25.npy', 'rb') as f:
        y2 = np.load(f)

    # x = torch.from_numpy(x)
    # y = torch.from_numpy(y)
    # x2 = torch.from_numpy(x2)
    # y2 = torch.from_numpy(y2)
    index = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33]

    x = torch.from_numpy(x)[:, index]
    x = (x/x.abs().max(0)[0]).clone().detach()
    y = torch.from_numpy(y)
    x2 = torch.from_numpy(x2)[:, index]
    x2 = (x2/x2.abs().max(0)[0]).clone().detach()
    y2 = torch.from_numpy(y2)

    print(x.mean(0), x.std(0))
    print(x2.mean(0), x2.std(0))

def load_data(start, end, tp):
    x_l = []
    for i in range(start, end+1):
        with open('data_4/'+tp+'_05_'+str(i)+'.npy', 'rb') as f:
            x_l.append(torch.from_numpy(np.load(f)))
    return torch.cat(x_l, dim=0)
    
if args.x == "xn":
    x = load_data(24, 28, "xn")
    x2 = load_data(29, 29, "xn")
else:
    x = load_data(24, 28, "xnn")
    x2 = load_data(29, 29, "xnn")
if args.y == "0":
    y = load_data(24, 28, "y")
    y2 = load_data(29, 29, "y")
elif args.y == "3":
    y = load_data(24, 28, "y3")
    y2 = load_data(29, 29, "y3")
elif args.y == "4":
    y = load_data(24, 28, "y4")
    y2 = load_data(29, 29, "y4")

print(x.shape, x2.shape, y.shape, y2.shape)
# x = torch.from_numpy(x)[:, :-2]
abs_v = x.abs().max(0)[0]
abs_v[abs_v==0] = 1
x = (x/abs_v).clone()
abs_v = x2.abs().max(0)[0]
abs_v[abs_v==0] = 1
x2 = (x2/abs_v).clone()
train_data_X, train_data_y, val_data_X, val_data_y, test_data_X, test_data_y, std, mean = [x, y, x, y, x2, y2, x.mean(0), x.std(0)]


from sklearn.model_selection import cross_val_score
from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler

train_data_X, val_data_X, test_data_X = train_data_X/std, val_data_X/std, test_data_X/std
train_data_X, train_data_y, val_data_X, val_data_y, test_data_X, test_data_y = train_data_X.numpy(), train_data_y.numpy(), val_data_X.numpy(), val_data_y.numpy(), test_data_X.numpy(), test_data_y.numpy()
linear = Ridge(fit_intercept=False, alpha=100)
linear.fit(train_data_X, train_data_y)
r2_train = linear.score(train_data_X, train_data_y)
loss_train = ((linear.predict(train_data_X) - train_data_y) ** 2).mean()
y_hat = torch.from_numpy(linear.predict(train_data_X))
y_true = torch.from_numpy(train_data_y)
print(y_true.shape, y_hat.shape)
corr_train = abs(np.corrcoef(torch.cat((y_true.unsqueeze(1), y_hat.unsqueeze(1)), 1).t().detach().cpu().numpy())[0, 1])
print(corr_train)
r2_val = linear.score(val_data_X, val_data_y)
loss_val = ((linear.predict(val_data_X) - val_data_y) ** 2).mean()
y_hat = torch.from_numpy(linear.predict(val_data_X))
y_true = torch.from_numpy(val_data_y)
print(y_true.shape, y_hat.shape)
corr_val = abs(np.corrcoef(torch.cat((y_true.unsqueeze(1), y_hat.unsqueeze(1)), 1).t().detach().cpu().numpy())[0, 1])
print(corr_val)
r2_test = linear.score(test_data_X, test_data_y)
loss_test = ((linear.predict(test_data_X) - test_data_y) ** 2).mean()
y_hat = torch.from_numpy(linear.predict(test_data_X))
y_true = torch.from_numpy(test_data_y)
print(y_true.shape, y_hat.shape)
corr_test = abs(np.corrcoef(torch.cat((y_true.unsqueeze(1), y_hat.unsqueeze(1)), 1).t().detach().cpu().numpy())[0, 1])
print(corr_test)
print(loss_train, r2_train, loss_val, r2_val, loss_test, r2_test)