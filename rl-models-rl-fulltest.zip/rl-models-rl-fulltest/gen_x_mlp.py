import numpy as np
import pandas as pd
from args import args
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.linear_model import Ridge
import datetime
from sklearn.neural_network import MLPRegressor
from joblib import dump, load
from sklearn.neural_network._base import ACTIVATIONS



date_list = args.valid[0]
start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
print(start_month, start_day, end_month, end_day)
start = datetime.date(2022,start_month,start_day)
end = datetime.date(2022,end_month,end_day)
x_l = []
print(start, end)
# models = [] 
models2 = []
for i in range((end-start).days+1):
    day = start + datetime.timedelta(days=i)
    print(day, day.month, day.day)
    month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
    day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 

    # models.append(load('mlp_'+month_str+'_'+day_str+'.joblib'))

    with open('data_6/x_'+month_str+'_'+day_str+'.npy', 'rb') as f:
        test = np.load(f)
    with open('data_6/y_'+month_str+'_'+day_str+'.npy', 'rb') as f:
        y = np.load(f)
    l_train = int(test.shape[0]*14/15)
    model = Ridge(normalize=False, fit_intercept=False, alpha=100)
    models2.append(model.fit(test[:l_train], y[:l_train]))
    # dump(model, 'results/linear_'+month_str+'_'+day_str+'.joblib') 

    print(r2_score(y[:l_train], model.predict(test[:l_train])))
    print(r2_score(y[l_train:], model.predict(test[l_train:])))



print("success")
date_list = args.train[0]
start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
print(start_month, start_day, end_month, end_day)
start = datetime.date(2022,start_month,start_day)
end = datetime.date(2022,end_month,end_day)
x_l = []
print(start, end)
for i in range((end-start).days+1):
    day = start + datetime.timedelta(days=i)
    print(day, day.month, day.day)
    month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
    day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
    index = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33]
    with open('data_6/x_'+month_str+'_'+day_str+'.npy', 'rb') as f:
        x = np.load(f)
    with open('data_6/xnn_'+month_str+'_'+day_str+'.npy', 'rb') as f:
        xnn = np.load(f)[:, index]
    with open('data_6/y_'+month_str+'_'+day_str+'.npy', 'rb') as f:
        y = np.load(f)
    print("for mlp")
    print("for xnn", xnn.shape)

    # a = pd.read_pickle('data_6/xnn2_'+month_str+'_'+day_str+'.pkl')
    # print(a.columns)
    for model in models2:
        print(r2_score(y, model.predict(x)))
        print(model.predict(x))
        # print(ACTIVATIONS['relu'](np.matmul(x, model.coefs_[0]) + model.intercepts_[0]))
        # o = ACTIVATIONS['relu'](np.matmul(x, model.coefs_[0]) + model.intercepts_[0])
        o = model.predict(x).reshape(-1, 1)
        # print(o)
        xnn = np.concatenate([xnn, o], axis=1)
        print(xnn.shape)

    with open('data_6/xnnfull_'+month_str+'_'+day_str+'.npy', 'wb') as f:
        np.save(f, xnn)
        # o = np.matmul(o, model.coefs_[1]) + model.intercepts_[1]
        # print(o)
    # print("for linear")
    # for model in models2:
        # print(r2_score(y, model.predict(x)))
    # print(r2_score(y2, model.predict(test2)))

    # print(model.predict(test2))


# with open('data_6/xnn_'+file2+'.npy', 'rb') as f:
#     test3 = np.load(f)

# print(test3)


# a = pd.read_pickle('data_6/xnn2_'+file2+'.pkl')
# print(a)
# c = a.to_numpy()
# print(c)

# 0.04769761679400908
# 0.04715703476543387
# 0.0398958424442174
