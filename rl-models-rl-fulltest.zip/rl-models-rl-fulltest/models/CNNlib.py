from args import args
import torch.nn as nn
import torch 
from torch.nn import TransformerEncoder, TransformerEncoderLayer
import math
from torch import Tensor
from torch.nn.parameter import Parameter
from torch.nn import init
from torch.nn import functional as F

class CNNLSTM(nn.Module):
    def __init__(self):
        super().__init__()                
        self.inp1 = nn.Sequential(
            nn.Conv1d(in_channels=args.input_size, out_channels=args.dim, kernel_size=1),
            nn.LeakyReLU(negative_slope=args.leaky),
            nn.BatchNorm1d(args.dim),
            nn.Conv1d(in_channels=args.dim, out_channels=args.dim, kernel_size=3, padding=1),
            nn.LeakyReLU(negative_slope=args.leaky),
            nn.BatchNorm1d(args.dim),
        )
        self.inp2 = nn.Sequential(
            nn.Conv1d(in_channels=args.input_size, out_channels=args.dim, kernel_size=1),
            nn.LeakyReLU(negative_slope=args.leaky),
            nn.BatchNorm1d(args.dim),
            nn.Conv1d(in_channels=args.dim, out_channels=args.dim, kernel_size=5, padding=2),
            nn.LeakyReLU(negative_slope=args.leaky),
            nn.BatchNorm1d(args.dim),
        )
        self.inp3 = nn.Sequential(
            nn.MaxPool1d(3, stride=1, padding=1),
            nn.Conv1d(in_channels=args.input_size, out_channels=args.dim, kernel_size=1),
            nn.LeakyReLU(negative_slope=args.leaky),
            nn.BatchNorm1d(args.dim),
        )
        
        # lstm layers
        self.lstm = nn.LSTM(input_size=3*args.dim, hidden_size=args.dim_lstm, num_layers=args.lstm_layers, batch_first=True, bidirectional=True, dropout=args.dropout)
        self.fc1 = nn.Linear(2*args.dim_lstm, 1)

    def forward(self, x):
        # h0: (number of hidden layers, batch size, hidden size)
        self.h0 = torch.zeros(2, x.size(0), args.dim_lstm).cuda()
        self.c0 = torch.zeros(2, x.size(0), args.dim_lstm).cuda()
        x_inp1 = self.inp1(x)
        x_inp2 = self.inp2(x)
        x_inp3 = self.inp3(x)  
        
        x = torch.cat((x_inp1, x_inp2, x_inp3), dim=1)
        x = x.permute(0, 2, 1)        
        x, _ = self.lstm(x, (self.h0, self.c0))
        x = x[:, -1, :]
        x = self.fc1(x)
        
        return x



class MyLN(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.ln = nn.LayerNorm(dim)
    def forward(self, x):
        return self.ln(x.permute(0, 2, 1)).permute(0, 2, 1)

class CNNLSTMLN(nn.Module):
    def __init__(self):
        super().__init__()                
        self.inp1 = nn.Sequential(
            nn.Conv1d(in_channels=args.input_size, out_channels=args.dim, kernel_size=1),
            nn.LeakyReLU(negative_slope=args.leaky),
            MyLN(args.dim),
            nn.Conv1d(in_channels=args.dim, out_channels=args.dim, kernel_size=3, padding=1),
            nn.LeakyReLU(negative_slope=args.leaky),
            MyLN(args.dim),
        )
        self.inp2 = nn.Sequential(
            nn.Conv1d(in_channels=args.input_size, out_channels=args.dim, kernel_size=1),
            nn.LeakyReLU(negative_slope=args.leaky),
            MyLN(args.dim),
            nn.Conv1d(in_channels=args.dim, out_channels=args.dim, kernel_size=5, padding=2),
            nn.LeakyReLU(negative_slope=args.leaky),
            MyLN(args.dim),
        )
        self.inp3 = nn.Sequential(
            nn.MaxPool1d(3, stride=1, padding=1),
            nn.Conv1d(in_channels=args.input_size, out_channels=args.dim, kernel_size=1),
            nn.LeakyReLU(negative_slope=args.leaky),
            MyLN(args.dim),
        )
        
        # lstm layers
        self.lstm = nn.LSTM(input_size=3*args.dim, hidden_size=args.dim_lstm, num_layers=args.lstm_layers, batch_first=True, bidirectional=True, dropout=args.dropout)
        self.fc1 = nn.Linear(2*args.dim_lstm, 1)

    def forward(self, x):
        # h0: (number of hidden layers, batch size, hidden size)
        self.h0 = torch.zeros(2, x.size(0), args.dim_lstm).cuda()
        self.c0 = torch.zeros(2, x.size(0), args.dim_lstm).cuda()
        x_inp1 = self.inp1(x)
        x_inp2 = self.inp2(x)
        x_inp3 = self.inp3(x)  
        
        x = torch.cat((x_inp1, x_inp2, x_inp3), dim=1)
        x = x.permute(0, 2, 1)        
        x, _ = self.lstm(x, (self.h0, self.c0))
        x = x[:, -1, :]
        x = self.fc1(x)
        
        return x

class MLPLSTM(nn.Module):
    def __init__(self):
        super().__init__()                
        
        self.fc0 = nn.Linear(args.input_size, 3*args.dim)
        # lstm layers
        self.lstm = nn.LSTM(input_size=3*args.dim, hidden_size=args.dim_lstm, num_layers=args.lstm_layers, batch_first=True, bidirectional=True, dropout=args.dropout)
        self.fc1 = nn.Linear(2*args.dim_lstm, 1)

    def forward(self, x):
        # h0: (number of hidden layers, batch size, hidden size)
        self.h0 = torch.zeros(2, x.size(0), args.dim_lstm).cuda()
        self.c0 = torch.zeros(2, x.size(0), args.dim_lstm).cuda()
        x = x.permute(0, 2, 1)
        x = self.fc0(x)
        x, _ = self.lstm(x, (self.h0, self.c0))
        x = x[:, -1, :]
        x = self.fc1(x)
        return x


class CNNTransformerModel(nn.Module):

    def __init__(self):
        super().__init__()
        self.inp1 = nn.Sequential(
            nn.Conv1d(in_channels=args.input_size, out_channels=args.dim, kernel_size=1),
            nn.LeakyReLU(negative_slope=args.leaky),
            nn.BatchNorm1d(args.dim),
            nn.Conv1d(in_channels=args.dim, out_channels=args.dim, kernel_size=3, padding=1),
            nn.LeakyReLU(negative_slope=args.leaky),
            nn.BatchNorm1d(args.dim),
        )
        self.inp2 = nn.Sequential(
            nn.Conv1d(in_channels=args.input_size, out_channels=args.dim, kernel_size=1),
            nn.LeakyReLU(negative_slope=args.leaky),
            nn.BatchNorm1d(args.dim),
            nn.Conv1d(in_channels=args.dim, out_channels=args.dim, kernel_size=5, padding=2),
            nn.LeakyReLU(negative_slope=args.leaky),
            nn.BatchNorm1d(args.dim),
        )
        self.inp3 = nn.Sequential(
            nn.MaxPool1d(3, stride=1, padding=1),
            nn.Conv1d(in_channels=args.input_size, out_channels=args.dim, kernel_size=1),
            nn.LeakyReLU(negative_slope=args.leaky),
            nn.BatchNorm1d(args.dim),
        )
        self.pos_encoder = PositionalEncoding(args.input_size, args.dropout)
        encoder_layers = TransformerEncoderLayer(3*args.dim, args.nhead, 12*args.dim, args.dropout, batch_first=True)
        self.transformer_encoder = TransformerEncoder(encoder_layers, args.nlayers)
        self.fc1 = nn.Linear(3*args.dim*args.T, 1)
        
    def init_weights(self) -> None:
        initrange = 0.1
        self.fc1.bias.data.zero_()
        self.fc1.weight.data.uniform_(-initrange, initrange)

    def forward(self, x):

        x_inp1 = self.inp1(x)
        x_inp2 = self.inp2(x)
        x_inp3 = self.inp3(x) 
        # print(x.size())

        x = torch.cat((x_inp1, x_inp2, x_inp3), dim=1)
        x = x.permute(0, 2, 1)
        if args.pos_encoding:
            x = self.pos_encoder(x)
        x = self.transformer_encoder(x)
        x = x.reshape(x.size(0), 3*args.dim*args.T)
        # print(x.size())
        x = self.fc1(x)

        # print(x.size())
        return x

class _NormBase(nn. Module):
    """Common base of _InstanceNorm and _BatchNorm"""

    _version = 2
    __constants__ = ["track_running_stats", "momentum", "eps", "num_features", "affine"]
    num_features: int
    eps: float
    momentum: float
    affine: bool
    track_running_stats: bool
    # WARNING: weight and bias purposely not defined here.
    # See https://github.com/pytorch/pytorch/issues/39670

    def __init__(
        self,
        num_features: int,
        eps: float = 1e-5,
        momentum: float = 0.1,
        affine: bool = True,
        track_running_stats: bool = True,
        device=None,
        dtype=None
    ) -> None:
        factory_kwargs = {'device': device, 'dtype': dtype}
        super(_NormBase, self).__init__()
        self.num_features = num_features
        self.eps = eps
        self.momentum = momentum
        self.affine = affine
        self.track_running_stats = track_running_stats
        if self.affine:
            self.weight = Parameter(torch.empty(num_features, **factory_kwargs))
            self.bias = Parameter(torch.empty(num_features, **factory_kwargs))
        else:
            self.register_parameter("weight", None)
            self.register_parameter("bias", None)
        if self.track_running_stats:
            self.register_buffer('running_mean', torch.zeros(num_features, **factory_kwargs))
            self.register_buffer('running_var', torch.ones(num_features, **factory_kwargs))
            self.running_mean: Optional[Tensor]
            self.running_var: Optional[Tensor]
            self.register_buffer('num_batches_tracked',
                                 torch.tensor(0, dtype=torch.long,
                                              **{k: v for k, v in factory_kwargs.items() if k != 'dtype'}))
            self.num_batches_tracked: Optional[Tensor]
        else:
            self.register_buffer("running_mean", None)
            self.register_buffer("running_var", None)
            self.register_buffer("num_batches_tracked", None)
        self.reset_parameters()

    def reset_running_stats(self) -> None:
        if self.track_running_stats:
            # running_mean/running_var/num_batches... are registered at runtime depending
            # if self.track_running_stats is on
            self.running_mean.zero_()  # type: ignore[union-attr]
            self.running_var.fill_(1)  # type: ignore[union-attr]
            self.num_batches_tracked.zero_()  # type: ignore[union-attr,operator]

    def reset_parameters(self) -> None:
        self.reset_running_stats()
        if self.affine:
            init.ones_(self.weight)
            init.zeros_(self.bias)

    def _check_input_dim(self, input):
        raise NotImplementedError

    def extra_repr(self):
        return (
            "{num_features}, eps={eps}, momentum={momentum}, affine={affine}, "
            "track_running_stats={track_running_stats}".format(**self.__dict__)
        )

    def _load_from_state_dict(
        self,
        state_dict,
        prefix,
        local_metadata,
        strict,
        missing_keys,
        unexpected_keys,
        error_msgs,
    ):
        version = local_metadata.get("version", None)

        if (version is None or version < 2) and self.track_running_stats:
            # at version 2: added num_batches_tracked buffer
            #               this should have a default value of 0
            num_batches_tracked_key = prefix + "num_batches_tracked"
            if num_batches_tracked_key not in state_dict:
                state_dict[num_batches_tracked_key] = torch.tensor(0, dtype=torch.long)

        super(_NormBase, self)._load_from_state_dict(
            state_dict,
            prefix,
            local_metadata,
            strict,
            missing_keys,
            unexpected_keys,
            error_msgs,
        )

class MyBN(_NormBase):
    def __init__(
        self,
        num_features: int,
        eps: float = 1e-5,
        momentum: float = 0.1,
        affine: bool = True,
        track_running_stats: bool = True,
        device=None,
        dtype=None
    ) -> None:
        factory_kwargs = {'device': device, 'dtype': dtype}
        super(MyBN, self).__init__(
            num_features, eps, momentum, affine, track_running_stats, **factory_kwargs
        )

    def _check_input_dim(self, input):
        if input.dim() != 2 and input.dim() != 3:
            raise ValueError(
                "expected 2D or 3D input (got {}D input)".format(input.dim())
            )

    def forward(self, input: Tensor) -> Tensor:
        self._check_input_dim(input)

        # exponential_average_factor is set to self.momentum
        # (when it is available) only so that it gets updated
        # in ONNX graph when this node is exported to ONNX.
        if self.momentum is None:
            exponential_average_factor = 0.0
        else:
            exponential_average_factor = self.momentum

        if self.training and self.track_running_stats:
            # TODO: if statement only here to tell the jit to skip emitting this when it is None
            if self.num_batches_tracked is not None:  # type: ignore[has-type]
                self.num_batches_tracked.add_(1)  # type: ignore[has-type]
                if self.momentum is None:  # use cumulative moving average
                    exponential_average_factor = 1.0 / float(self.num_batches_tracked)
                else:  # use exponential moving average
                    exponential_average_factor = self.momentum

        r"""
        Decide whether the mini-batch stats should be used for normalization rather than the buffers.
        Mini-batch stats are used in training mode, and in eval mode when buffers are None.
        """
        if self.training:
            bn_training = True
        else:
            bn_training = (self.running_mean is None) and (self.running_var is None)

        r"""
        Buffers are only updated if they are to be tracked and we are in training mode. Thus they only need to be
        passed when the update should occur (i.e. in training mode when they are tracked), or when buffer stats are
        used for normalization (i.e. in eval mode when buffers are not None).
        """
        return F.batch_norm(
            input.permute(0, 2, 1),
            # If buffers are not to be tracked, ensure that they won't be updated
            self.running_mean
            if not self.training or self.track_running_stats
            else None,
            self.running_var if not self.training or self.track_running_stats else None,
            self.weight,
            self.bias,
            bn_training,
            exponential_average_factor,
            self.eps,
        ).permute(0, 2, 1)

class MLPTransformerModel(nn.Module):

    def __init__(self):
        super().__init__()
        self.fc0 = nn.Linear(args.input_size, 3*args.dim)
        if not args.pos_before:
            if args.absolute_pos:
                self.pos_encoder = PositionalEncoding(3*args.dim, args.dropout)
            else:
                self.pos_embed = nn.Parameter(torch.zeros(1, args.T, 3*args.dim))
        else:
            if args.absolute_pos:
                self.pos_encoder = PositionalEncoding(args.input_size, args.dropout)
            else:
                self.pos_embed = nn.Parameter(torch.zeros(1, args.T, args.input_size))
        encoder_layers = TransformerEncoderLayer(3*args.dim, args.nhead, 12*args.dim, args.dropout, batch_first=True)
        if args.batch_norm:
            encoder_layers.norm1, encoder_layers.norm2 = MyBN(3*args.dim), MyBN(3*args.dim)
        self.transformer_encoder = TransformerEncoder(encoder_layers, args.nlayers)
        self.fc1 = nn.Linear(3*args.dim*args.T, 1)
        
    def init_weights(self):
        initrange = 0.1
        self.fc1.bias.data.zero_()
        self.fc1.weight.data.uniform_(-initrange, initrange)

    def forward(self, x):
        x = x.permute(0, 2, 1)
        if args.pos_before and args.pos_encoding:
            if args.absolute_pos:
                x = self.pos_encoder(x)
            else:
                x = x + self.pos_embed
        x = self.fc0(x)
        if not args.pos_before and args.pos_encoding:
            if args.absolute_pos:
                x = self.pos_encoder(x)
            else:
                x = x + self.pos_embed
        x = self.transformer_encoder(x)
        x = x.reshape(x.size(0), 3*args.dim*args.T)
        x = self.fc1(x)
        return x

class MLPTransformerModelClassification(nn.Module):

    def __init__(self):
        super().__init__()
        self.fc0 = nn.Linear(args.input_size, 3*args.dim)
        if not args.pos_before:
            if args.absolute_pos:
                self.pos_encoder = PositionalEncoding(3*args.dim, args.dropout)
            else:
                self.pos_embed = nn.Parameter(torch.zeros(1, args.T, 3*args.dim))
        else:
            if args.absolute_pos:
                self.pos_encoder = PositionalEncoding(args.input_size, args.dropout)
            else:
                self.pos_embed = nn.Parameter(torch.zeros(1, args.T, args.input_size))
        encoder_layers = TransformerEncoderLayer(3*args.dim, args.nhead, 12*args.dim, args.dropout, batch_first=True)
        if args.batch_norm:
            encoder_layers.norm1, encoder_layers.norm2 = MyBN(3*args.dim), MyBN(3*args.dim)
        self.transformer_encoder = TransformerEncoder(encoder_layers, args.nlayers)
        self.fc1 = nn.Linear(3*args.dim*args.T, 5)
        
    def init_weights(self):
        initrange = 0.1
        self.fc1.bias.data.zero_()
        self.fc1.weight.data.uniform_(-initrange, initrange)

    def forward(self, x):
        x = x.permute(0, 2, 1)
        if args.pos_before and args.pos_encoding:
            if args.absolute_pos:
                x = self.pos_encoder(x)
            else:
                x = x + self.pos_embed
        x = self.fc0(x)
        if not args.pos_before and args.pos_encoding:
            if args.absolute_pos:
                x = self.pos_encoder(x)
            else:
                x = x + self.pos_embed
        x = self.transformer_encoder(x)
        x = x.reshape(x.size(0), 3*args.dim*args.T)
        x = self.fc1(x)
        return x

class TransformerModel(nn.Module):

    def __init__(self):
        super().__init__()
        self.pos_encoder = PositionalEncoding(args.input_size, args.dropout)
        encoder_layers = TransformerEncoderLayer(args.input_size, args.nhead, args.input_size, args.dropout, batch_first=True)
        self.transformer_encoder = TransformerEncoder(encoder_layers, args.nlayers)
        self.fc1 = nn.Linear(args.input_size*args.T, 1)

    #     self.init_weights()

    def init_weights(self) -> None:
        initrange = 0.1
        self.fc1.bias.data.zero_()
        self.fc1.weight.data.uniform_(-initrange, initrange)

    def forward(self, x):
        x = x.permute(0, 2, 1) 
        # print(x.size())
        if args.pos_encoding:
            x = self.pos_encoder(x)
        x = self.transformer_encoder(x)
        x = x.reshape(x.size(0), args.T*args.input_size)
        # print(x.size())
        x = self.fc1(x)

        # print(x.size())
        return x

class PositionalEncoding(nn.Module):

    def __init__(self, d_model, dropout, max_len=5):
        super().__init__()
        self.dropout = nn.Dropout(p=dropout)
        self.d_model = d_model
        if d_model % 2 == 1:
            pseduo_d_model = d_model + 1
        else:
            pseduo_d_model = d_model
        position = torch.arange(max_len).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, pseduo_d_model, 2) * (-math.log(10000.0) / pseduo_d_model))
        pe = torch.zeros(1, max_len, pseduo_d_model)
        # print(position.size(), div_term.size(), (position * div_term).size())
        pe[0, :, 0::2] = torch.sin(position * div_term)
        pe[0, :, 1::2] = torch.cos(position * div_term)
        pe = pe[:, :, :self.d_model].clone().detach()
        self.register_buffer('pe', pe)

    def forward(self, x):
        # print(self.pe.size(), self.pe[:, :x.size(0),:self.d_model].size())
        x = x + self.pe
        return self.dropout(x)

class CNNLSTMScript(nn.Module):
    def __init__(self):
        super().__init__()                
        self.inp1 = nn.Sequential(
            nn.Conv1d(in_channels=args.input_size, out_channels=args.dim, kernel_size=1),
            nn.LeakyReLU(negative_slope=args.leaky),
            nn.BatchNorm1d(args.dim),
            nn.Conv1d(in_channels=args.dim, out_channels=args.dim, kernel_size=3, padding=1),
            nn.LeakyReLU(negative_slope=args.leaky),
            nn.BatchNorm1d(args.dim),
        )
        self.inp2 = nn.Sequential(
            nn.Conv1d(in_channels=args.input_size, out_channels=args.dim, kernel_size=1),
            nn.LeakyReLU(negative_slope=args.leaky),
            nn.BatchNorm1d(args.dim),
            nn.Conv1d(in_channels=args.dim, out_channels=args.dim, kernel_size=5, padding=2),
            nn.LeakyReLU(negative_slope=args.leaky),
            nn.BatchNorm1d(args.dim),
        )
        self.inp3 = nn.Sequential(
            nn.MaxPool1d(3, stride=1, padding=1),
            nn.Conv1d(in_channels=args.input_size, out_channels=args.dim, kernel_size=1),
            nn.LeakyReLU(negative_slope=args.leaky),
            nn.BatchNorm1d(args.dim),
        )
        
        # lstm layers
        self.lstm = nn.LSTM(input_size=3*args.dim, hidden_size=args.dim_lstm, num_layers=args.lstm_layers, batch_first=True, bidirectional=True, dropout=args.dropout)
        self.fc1 = nn.Linear(2*args.dim_lstm, 1)
        self.register_buffer("h0", torch.zeros(2, 1, args.dim_lstm))
        self.register_buffer("c0", torch.zeros(2, 1, args.dim_lstm))

    def forward(self, x):
        # h0: (number of hidden layers, batch size, hidden size)
        x_inp1 = self.inp1(x)
        x_inp2 = self.inp2(x)
        x_inp3 = self.inp3(x)  
        
        x = torch.cat((x_inp1, x_inp2, x_inp3), dim=1)
        x = x.permute(0, 2, 1)        
        x, _ = self.lstm(x, (self.h0, self.c0))
        x = x[:, -1, :]
        x = self.fc1(x)
        
        return x

class CNNLSTMNormal(nn.Module):
    def __init__(self):
        super().__init__()                
        self.inp1 = nn.Sequential(
            nn.Conv1d(in_channels=args.input_size, out_channels=args.dim, kernel_size=1),
            nn.LeakyReLU(negative_slope=args.leaky),
            nn.BatchNorm1d(args.dim),
            nn.Conv1d(in_channels=args.dim, out_channels=args.dim, kernel_size=3, padding=1),
            nn.LeakyReLU(negative_slope=args.leaky),
            nn.BatchNorm1d(args.dim),
        )
        self.inp2 = nn.Sequential(
            nn.Conv1d(in_channels=args.input_size, out_channels=args.dim, kernel_size=1),
            nn.LeakyReLU(negative_slope=args.leaky),
            nn.BatchNorm1d(args.dim),
            nn.Conv1d(in_channels=args.dim, out_channels=args.dim, kernel_size=5, padding=2),
            nn.LeakyReLU(negative_slope=args.leaky),
            nn.BatchNorm1d(args.dim),
        )
        self.inp3 = nn.Sequential(
            nn.MaxPool1d(3, stride=1, padding=1),
            nn.Conv1d(in_channels=args.input_size, out_channels=args.dim, kernel_size=1),
            nn.LeakyReLU(negative_slope=args.leaky),
            nn.BatchNorm1d(args.dim),
        )
        
        # lstm layers
        self.lstm = nn.LSTM(input_size=3*args.dim, hidden_size=args.dim_lstm, num_layers=args.lstm_layers, batch_first=True, bidirectional=True, dropout=args.dropout)
        self.fc1 = nn.Linear(2*args.dim_lstm, 2)

    def forward(self, x):
        # h0: (number of hidden layers, batch size, hidden size)
        
        x_inp1 = self.inp1(x)
        x_inp2 = self.inp2(x)
        x_inp3 = self.inp3(x)  
        
        x = torch.cat((x_inp1, x_inp2, x_inp3), dim=1)
        x = x.permute(0, 2, 1)        
        x, _ = self.lstm(x)
        x = x[:, -1, :]
        x = self.fc1(x)        
        return x
        

class CNN(nn.Module):
    def __init__(self):
        super().__init__()                
        self.inp1 = nn.Sequential(
            nn.Conv1d(in_channels=args.input_size, out_channels=args.dim, kernel_size=1),
            nn.LeakyReLU(negative_slope=args.leaky),
            nn.BatchNorm1d(args.dim),
            nn.Conv1d(in_channels=args.dim, out_channels=args.dim, kernel_size=3, padding=1),
            nn.LeakyReLU(negative_slope=args.leaky),
            nn.BatchNorm1d(args.dim),
        )
        self.inp2 = nn.Sequential(
            nn.Conv1d(in_channels=args.input_size, out_channels=args.dim, kernel_size=1),
            nn.LeakyReLU(negative_slope=args.leaky),
            nn.BatchNorm1d(args.dim),
            nn.Conv1d(in_channels=args.dim, out_channels=args.dim, kernel_size=5, padding=2),
            nn.LeakyReLU(negative_slope=args.leaky),
            nn.BatchNorm1d(args.dim),
        )
        self.inp3 = nn.Sequential(
            nn.MaxPool1d(3, stride=1, padding=1),
            nn.Conv1d(in_channels=args.input_size, out_channels=args.dim, kernel_size=1),
            nn.LeakyReLU(negative_slope=args.leaky),
            nn.BatchNorm1d(args.dim),
        )
        
        # lstm layers
        self.fc1 = nn.Linear(3*args.T*args.dim, 1)

    def forward(self, x):
        # h0: (number of hidden layers, batch size, hidden size)
        
        x_inp1 = self.inp1(x)
        x_inp2 = self.inp2(x)
        x_inp3 = self.inp3(x)  
        x = torch.cat((x_inp1, x_inp2, x_inp3), dim=1).reshape(-1, 3*args.T*args.dim)
        x = self.fc1(x)
        return x

class MLP(nn.Module):
    def __init__(self):
        super().__init__()                
        self.fc1 = nn.Linear(args.input_size, args.dim)
        self.fc2 = nn.Linear(args.dim, 1)
        self.bn1 = nn.BatchNorm1d(args.dim, eps=1e-5)

    def forward(self, x):
        x = x.squeeze()
        # print(x.size(), self.fc1(x).size())
        # print(nn.BatchNorm1d(args.dim, eps=1e-5)(self.fc1(x)).size())
        x = self.fc2(nn.ReLU(inplace=True)(self.bn1(self.fc1(x))))
        return x
