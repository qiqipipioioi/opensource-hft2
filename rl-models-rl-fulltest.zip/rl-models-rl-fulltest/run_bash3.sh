source ~/.bashrc
for date0 in "01_22"
do
date="${date0}-${date0}"
echo $date
# $HOME/go/bin/gdrive download -r 1pTbmcTp9hZGPajuz5xPqmNkQBonZ4ZCH --skip
# mv data/* data_6/
# bash combine_days_bash.sh $date0
conda activate python38
python trans_data.py --train $date --old 6
source ~/.bashrc
CUDA_VISIBLE_DEVICES=2  python main_cnnlstm.py --lr 0.0001 --dropout 0 --opt adamw --x xnn --y 0 --input_size 504 --wd 0.4 --T 5 --batch_size 2048 --old 18 --train 09_21-10_30 --valid 10_31-11_01 --test $date --arch TSTransformerEncoderClassiregressor --val_split 0.0001 --use_p23 11 --min_mean --div_std --nlayers 1 --dim 144 --nhead 8 --dim_feedforward 576 --test2 10_31-10_31 --wandb --generate_test_predict --seed 8313747812
conda activate python38
python backtest_2_compare_test6_19.py --test $date --seed 8313747812    --profit_type 19
python backtest_2_compare_test6_22.py  --test $date --profit_type 19 --seed 8313747812    --t2
source ~/.bashrc
CUDA_VISIBLE_DEVICES=2  python main_cnnlstm_rl_sim3_7.py --lr 0.001 --dropout 0 --opt adamw --x xnn4 --y 0 --input_size 96 --wd 0 --T 5 --batch_size 2048 --old 39 --train 12_07-01_05 --valid 01_06-01_15 --test $date --arch TSTransformerEncoderRLSeq7 --val_split 0.0001 --use_p23 3 --min_mean --div_std --nlayers 1 --dim 144 --nhead 8 --dim_feedforward 576 --test2 12_08-12_08 --test4 12_08-12_08 --test_interval 2000 --rlbuy_profit_path 219dout4easy_profit_sell_12_07-01_05std --rlbuy_profit_path2 "219dout4easy_profit_sell_${date}std" --rlbuy_profit_path3 219dout4easy_profit_sell_12_08-12_08std --rlbuy_profit_path4 219dout4easy_profit_sell_12_08-12_08std --valid_2ndsellpoint 219dout4valid_buy2ndpoint_12_07-01_05std --valid_2ndsellpoint2 "219dout4valid_buy2ndpoint_${date}std" --valid_2ndsellpoint3 219dout4valid_buy2ndpoint_12_08-12_08std --valid_2ndsellpoint4 219dout4valid_buy2ndpoint_12_08-12_08std --wandb --gradient_acc_step 30 --type sell --exp_neg --take_normal --updates_thres 200000 --profit_type 19 --action_size 1 --name "t2sellopendenseclose4 5 3 2 1 0" --not_squeeze --norm_y --set_seed --repeat_times 10 --consider_zero --gamma 0 --d_num 6 --offset 0 --bin 5 --t2 --d_list 4 5 3 2 1 0 --generate_test_predict --seed 1674188538.6107037
done



