from args import args
from plistlib import load
from re import T
import torch
import torch.nn as nn
import stock
import pickle5 as pickle
# with open('/home/ubuntu/55data_influx.pkl', "rb") as fh:
    # raw3 = pickle.load(fh)

import numpy as np
import tqdm
import logger
import wandb
import models
import torch.utils.benchmark as benchmark
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
import matplotlib.pyplot as plt
torch.set_default_dtype(torch.float32)
epochs = 1000
lr = args.lr
from stock import StockEnv, abs_profit, mean_profit, std_profit
import datetime
args.temp = 1
max_r2 = 0
max_r2_itr = -1
min_l = 0
min_l_itr = -1
max_test2_r2 = 0
max_test2_r2_itr = -1
corr_test2_r2 = 0
max_p = -1
max_p_itr = -1
corr_p = 0
from numba import jit
import random
import numpy as np
import torch
if args.set_seed:
    torch.manual_seed(3407)
    random.seed(3407)
    np.random.seed(3407)
    
def mean(l):
    return sum(l)/len(l)

def count_parameters(model):
    return sum(p.numel() for p in model.parameters() if p.requires_grad)

def assign_learning_rate(optimizer, new_lr):
    for param_group in optimizer.param_groups:
        param_group["lr"] = new_lr
import pandas as pd
interval = int(1e3)

def calculate_train_RLd3_34(model, dataset, rlbuy_profit_path, rlsell_profit_path, valid_sellpoint, valid_buypoint, step=0, test_field="", tag="train", rand_number=str(args.seed)):
    model = model.actor_mean
    model.eval()
    args.eval = True
    loader_seq = torch.utils.data.DataLoader(dataset, shuffle=False, sampler=torch.utils.data.SequentialSampler(dataset), batch_size=args.batch_size, num_workers=4, pin_memory=True)
    y_hat_total = torch.zeros((dataset.data_X.size(0))).cuda()
    y_hat_total_shrink = torch.zeros((len(dataset),)).cuda()
    with torch.no_grad():
        start, end = 0, 0
        for i, (x, y, index, mask) in tqdm.tqdm(enumerate(loader_seq), ascii=True, total=len(loader_seq)):
            x = x.cuda()
            out = model(x).squeeze()
            end += out.size(0)
            y_hat_total[index] = out
            y_hat_total_shrink[start:end] = out
            start = end
    np.save("data_7/d"+args.type+";".join(test_field)+args.seed+".npy", torch.exp(y_hat_total).cpu().detach().numpy())
    if 1==0:
        from influxdb import DataFrameClient
        client = DataFrameClient(args.ip, 8086, 'xz', 'xzquant2022', 'signal')
        time_index = np.load(str(args.profit_type)+"dout4time"+"_"+";".join(test_field)+"std"+".npy")
        data_1 = pd.DataFrame()
        data_1['time'] = pd.DataFrame(time_index)
        data_1['d'] = pd.DataFrame(torch.exp(y_hat_total).cpu().detach().numpy())
        data_1.index = data_1.time
        i = 0
        for i in range(1, int(len(data_1.index)//1e5)):
            print((i-1)*int(1e5), i*int(1e5))
            client.write_points(data_1[['d']][(i-1)*int(1e5):i*int(1e5)], "backtest_d"+args.type, {})
        print(i*int(1e5), len(data_1[['d']]))
        client.write_points(data_1[['d']][i*int(1e5):],  "backtest_d"+args.type, {})
    return torch.exp(y_hat_total).cpu().detach().numpy()

def train(model, loader, opt, epoch):
    global max_r2, max_r2_itr, min_l, min_l_itr, max_test2_r2_itr, max_test2_r2, corr_test2_r2, max_p, max_p_itr, corr_p
    model.train()
    pg_loss_meter = logger.AverageMeter("pg_loss", ":.3f")
    ratio_meter = logger.AverageMeter("ratio", ":.3f")
    opt.zero_grad()
    l = [pg_loss_meter, ratio_meter]
    progress = logger.ProgressMeter(len(loader), l, prefix=f"Train Epoch: [{epoch}]")
    num_updates = 0
    for i, (b_obs, b_logprobs, b_actions, b_returns) in tqdm.tqdm(enumerate(loader), ascii=True, total=len(loader)):
        model.train()
        #
        b_obs, b_logprobs, b_actions, b_returns = b_obs.cuda(), b_logprobs.cuda(), b_actions.cuda(), b_returns.cuda()
        # print(b_actions, b_actions.float())
        # with torch.no_grad():
        _, newlogprob = model.get_action(b_obs, b_actions)
        logratio = newlogprob - b_logprobs
        # for i in range(2048):
            # print("newlogprob, b_logprobs", newlogprob[i], b_logprobs[i])
        # print("newlogprob, b_logprobs", newlogprob, b_logprobs, torch.isinf(newlogprob).sum(), torch.isinf(b_logprobs).sum())
        ratio = torch.clamp(logratio, max=50).exp()
        # print("2", ratio, ratio.mean(), torch.isinf(ratio).sum(), torch.isinf(logratio).sum(), torch.isinf(ratio).nonzero())
        # if i >= 3:
            # ind = torch.isinf(ratio).nonzero()[0]
            # print("why", logratio[ind], ratio[ind], newlogprob[ind], b_logprobs[ind]) 

        pg_loss1 = -b_returns * ratio

        pg_loss2 = -b_returns * torch.clamp(ratio, 1 - args.clip_coef, 1 + args.clip_coef)
        # print("3", pg_loss1.mean(), pg_loss2.mean())
        pg_loss = torch.max(pg_loss1, pg_loss2).mean()
        # print(pg_loss)
        loss = pg_loss
        pg_loss_meter.update(pg_loss.item(), b_obs.size(0))
        ratio_meter.update(ratio.mean().item(), b_obs.size(0))
        wandb.log({"train/pg_loss": pg_loss.item()}, step=epoch)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 3)
        if (i+1) % args.gradient_acc_step == 0:
            if args.div_grad_acc:
                for name, param in model.named_parameters():
                    param.grad.data = param.grad.data/args.gradient_acc_step
                # print(name, param.grad, args.gradient_acc_step)
                
            opt.step()
            opt.zero_grad()
            num_updates += 1
            if num_updates >= args.updates_thres:
                break
            


        if "RL" in args.arch:
            if i % 200 == 0:
                progress.display(i) 
    return 0, 0, 0


@jit
def calculate_profit_with_chosen(valid_sellpoint, chosen_value_total, position=5, lag=1, lag2=1):
    # print(valid_sellpoint)
    chosen_vt = chosen_value_total
    positions_dict = [0 for i in range(len(valid_sellpoint))]
    # profit_positions = [0 for i in range(len(valid_sellpoint))]
    # addedvb_positions = [[] for i in range(len(valid_sellpoint))]

    valid_buypoint = (chosen_vt != 0).nonzero()[0]
    # for i in range(len(chosen_vt)):
        # print(chosen_vt[i])
    profit_position = np.zeros(len(chosen_vt))
    def get_loc(vb):
        for i in range(len(valid_sellpoint)):
            if vb < valid_sellpoint[i]:
                return i, False
            if valid_sellpoint[i] <= vb and vb < valid_sellpoint[i] + lag + lag2 -1:
                return i, True

    total_profit = 0
    # print(len(valid_buypoint))
    deferred_positions = [(0, 0)]
    deferred_positions = deferred_positions[1:]
    for vb in valid_buypoint:
        i = 0
        retained_items = []
        for i in range(len(deferred_positions)):
            if vb >= deferred_positions[i][1]:
                positions_dict[deferred_positions[i][0]] += 1
            else:
                retained_items.append(deferred_positions[i])
        deferred_positions = retained_items
        # print(positions_dict[:10], max(positions_dict), deferred_positions, lag)
        if vb < valid_sellpoint[-1]:
            bin, atpoint = get_loc(vb)
            if not atpoint:
                if positions_dict[bin] < position:
                    total_profit += chosen_vt[vb]
                    # profit_position[vb] = chosen_vt[vb]
                    profit_position[valid_sellpoint[bin]+2*lag-1] += chosen_vt[vb]

                    deferred_positions.append((bin, vb + lag))
                    # print(deferred_positions)

            else:
                if positions_dict[bin+1] < position:
                    total_profit += chosen_vt[vb]
                    # profit_position[vb] = chosen_vt[vb]
                    profit_position[valid_sellpoint[bin+1]+2*lag-1] += chosen_vt[vb]

                    # deferred_positions.append((bin, vb + lag))
                    deferred_positions.append((bin+1, vb + lag))
                    # print(deferred_positions)
        else:
            # print(vb, valid_sellpoint[-1], valid_sellpoint)
            print("why larger")
        # if vb > 10000:
            # break
    return total_profit, profit_position, positions_dict  



def calculate_profit_with_chosen_2(valid_sellpoint, chosen_value_total, position=5, lag=1, lag2=1):
    # print(valid_sellpoint)
    chosen_vt = chosen_value_total
    positions_dict = [0 for i in range(len(valid_sellpoint))]
    # profit_positions = [0 for i in range(len(valid_sellpoint))]
    # addedvb_positions = [[] for i in range(len(valid_sellpoint))]

    valid_buypoint = (chosen_vt != 0).nonzero()[0]
    # for i in range(len(chosen_vt)):
        # print(chosen_vt[i])
    profit_position = np.zeros(len(chosen_vt))
    def get_loc(vb):
        for i in range(len(valid_sellpoint)):
            if vb < valid_sellpoint[i]:
                return i, False
            if valid_sellpoint[i] <= vb and vb < valid_sellpoint[i] + lag + lag2 -1:
                return i, True

    total_profit = 0
    # print(len(valid_buypoint))
    deferred_positions = [(0, 0)]
    deferred_positions = deferred_positions[1:]
    trades = []
    position_np = np.zeros(len(chosen_vt))
    for vb in valid_buypoint:
        
        i = 0
        retained_items = []
        for i in range(len(deferred_positions)):
            if vb >= deferred_positions[i][1]:
                positions_dict[deferred_positions[i][0]] += 1
            else:
                retained_items.append(deferred_positions[i])
        deferred_positions = retained_items
        # print(positions_dict[:10], max(positions_dict), deferred_positions, lag)
        if vb < valid_sellpoint[-1]:
            bin, atpoint = get_loc(vb)
            if not atpoint:
                if positions_dict[bin] < position:
                    total_profit += chosen_vt[vb]
                    profit_position[valid_sellpoint[bin]+lag+lag2-1] += chosen_vt[vb]
                    trades.append((vb, vb+lag, valid_sellpoint[bin]+lag-1, valid_sellpoint[bin]+lag+lag2-1))
                    deferred_positions.append((bin, vb + lag))
                    # print(deferred_positions)

            else:
                if positions_dict[bin] < position:
                    total_profit += chosen_vt[vb]
                    profit_position[valid_sellpoint[bin+1]+lag+lag2-1] += chosen_vt[vb]
                    deferred_positions.append((bin, vb + lag))
                    deferred_positions.append((bin+1, vb + lag))
                    trades.append((vb, vb+lag, valid_sellpoint[bin+1]+lag-1, valid_sellpoint[bin+1]+lag+lag2-1))

                    # print(deferred_positions)
        else:
            print(vb, valid_sellpoint[-1], valid_sellpoint)
            print("why larger")
        # if vb > 10000:
            # break
    segments = valid_sellpoint+lag+lag2-1
    for tr in trades:
        position_np[tr[1]] += 1
    for i in range(len(segments)-1):
        position_np[segments[i]:segments[i+1]] = np.cumsum(position_np[segments[i]:segments[i+1]])
    return total_profit, profit_position, sum(positions_dict), trades, position_np


@jit
def calculate_profit_with_chosen_3(valid_sellpoint, chosen_value_total, position=5, lag=1, lag2=1):
    # print(valid_sellpoint)
    chosen_vt = chosen_value_total
    positions_dict = [0 for i in range(len(valid_sellpoint))]
    # profit_positions = [0 for i in range(len(valid_sellpoint))]
    # addedvb_positions = [[] for i in range(len(valid_sellpoint))]

    valid_buypoint = (chosen_vt != 0).nonzero()[0]
    # for i in range(len(chosen_vt)):
        # print(chosen_vt[i])
    profit_position = np.zeros(len(chosen_vt))
    def get_loc(vb):
        for i in range(len(valid_sellpoint)):
            if vb < valid_sellpoint[i]:
                return i, False
            if valid_sellpoint[i] <= vb and vb < valid_sellpoint[i] + lag + lag2 -1:
                return i, True
    total_profit = 0
    # print(len(valid_buypoint))
    deferred_positions = [(0, 0)]
    deferred_positions = deferred_positions[1:]
    clear_list = []
    # print(len(valid_buypoint), len(valid_sellpoint))
    for vb in valid_buypoint:
        # print(vb)
        # print(total_profit, np.sum(profit_position))
        # if len(clear_list) != 0:
            # print(sum(clear_list)/len(clear_list), len(clear_list), len(valid_buypoint), len(valid_sellpoint))
        i = 0
        retained_items = []
        for i in range(len(deferred_positions)):
            if vb >= deferred_positions[i][1]:
                positions_dict[deferred_positions[i][0]] += 1
            else:
                retained_items.append(deferred_positions[i])
        deferred_positions = retained_items
        # print(positions_dict[:10], max(positions_dict), deferred_positions, lag)
        if vb < valid_sellpoint[-1]:
            bin, atpoint = get_loc(vb)
            if not atpoint:
                if positions_dict[bin] < position:
                    total_profit += chosen_vt[vb]
                    profit_position[valid_sellpoint[bin]+lag+lag2-1] += chosen_vt[vb]
                    deferred_positions.append((bin, vb + lag))
                    clear_list.append(valid_sellpoint[bin]+lag+lag2-1-vb - lag)
                    # print(deferred_positions)

            else:
                if positions_dict[bin] < position:
                    total_profit += chosen_vt[vb]
                    profit_position[valid_sellpoint[bin+1]+lag+lag2-1] += chosen_vt[vb]
                    deferred_positions.append((bin, vb + lag))
                    deferred_positions.append((bin+1, vb + lag))
                    clear_list.append(valid_sellpoint[bin+1]+lag+lag2-1-vb - lag)


                    # print(deferred_positions)
        else:
            print("why larger")
    return total_profit, profit_position, sum(positions_dict)

model = models.__dict__[args.arch]()
model = model.cuda()
print("number of parameters:", count_parameters(model))
print(model)


bn_params = [v for n, v in list(model.named_parameters()) if ("bn" in n) and v.requires_grad]
rest_params = [v for n, v in list(model.named_parameters()) if ("bn" not in n) and v.requires_grad]

opt = torch.optim.AdamW([
    {
        "params": bn_params,
        "weight_decay": 0 if args.no_bn_decay else args.wd,
    },
    {"params": rest_params, "weight_decay": args.wd},
], lr=lr, weight_decay = args.wd)

from random import randrange
import time
args.rand_number = str(time.time())

import gym


def make_env(fulltest=False, i=0, split="train", num_envs=256, lag1=1, lag2=1, test_field=""):
    def thunk():
        if args.old == 40:
            env = stock.StockEnv40(fulltest, i, split, num_envs, lag1, lag2, test_field)
        elif args.old == 38:
            env = stock.StockEnv38(fulltest, i, split, num_envs, lag1, lag2)
        elif args.old == 37:
            env = stock.StockEnv37(fulltest, i, split, num_envs, lag1, lag2)
        elif args.old == 36:
            env = stock.StockEnv36(fulltest, i, split, num_envs)
        elif args.old == 35:
            env = stock.StockEnv35(fulltest, i, split, num_envs)
        else:
            env = stock.StockEnv(fulltest, i, split, num_envs)
        return env
    return thunk



def transAct(preaction):
    if args.clamp_neg:
        action = torch.clamp(preaction, min=0)
    elif args.sigmoid_neg:
        action = torch.sigmoid(preaction)*args.sig_alpha
    elif args.exp_neg:
        action = torch.exp(preaction)
    else:
        action = preaction
    return action


if args.generate_test_predict:
    print(args.test4)
    args.rand_number = str(args.seed)
    # model = torch.load("best_model_y"+args.arch+args.y+"_"+';'.join(args.train)+"_"+';'.join(args.valid)+"_copy.pt")
    model = torch.load("results/best_model_RL"+args.arch+"_"+';'.join(args.train)+"_"+';'.join(args.valid)+"_"+';'.join(args.test2)+args.rand_number+"lagallavg.pt")
    # model = torch.jit.load("/home/xzhoubi/paperreading/results_new_3/best_model_RLTSTransformerEncoderRLSeq3_08_11-10_20_10_21-10_25_10_27-11_081669902193.173553lagallavg_script(1).pt")
    model.eval()
        
    old_test_dataset = stock.StockAggregate35("test4")
    action = calculate_train_RLd3_34(model, old_test_dataset, args.rlbuy_profit_path4, args.rlsell_profit_path4, args.valid_2ndsellpoint4, args.valid_2ndbuypoint4, step=0, tag="test4", test_field=args.test4)
    for lag1, lag2 in [(1, 1), (5, 5), (1, 2), (2, 1), (2, 2)]:
        if lag1 == 5 and lag2 == 5:
            abbr = "2"
            lag1, lag2 = 1, 1
        else:
            abbr = ""
        profit = np.zeros((stock.y04.shape[0], ))
        psu_env = make_env(True, 0, "test4", 256, lag1, lag2)()
        valid_sellpoint = np.load(abbr+args.valid_2ndsellpoint4+"_"+str(lag1)+str(lag2)+".npy")
        y0 = np.load(abbr+args.rlbuy_profit_path4+"_"+str(lag1)+str(lag2)+".npy")
        dout = 4
        if args.type == "sell":
            tpb = np.load(abbr+str(args.profit_type)+"dout"+str(dout)+"tps"+"_"+";".join(args.test4)+"std"+"_"+str(lag1)+str(lag2)+"train.npy")
            valid_sellprice = np.load(abbr+str(args.profit_type)+"dout"+str(dout)+"valid_buyprice"+"_"+";".join(args.test4)+"std"+"_"+str(lag1)+str(lag2)+".npy")
            buy_price = psu_env.buy_price_base
            buy_price = buy_price * (1+action/1e4) 
            tradable_points = np.logical_and(tpb >= buy_price+0.01, tpb != 0)
            tradable_points = np.logical_and(tradable_points, valid_sellprice!=0)
            profit[tradable_points] = (buy_price[tradable_points] - valid_sellprice[tradable_points] + 0.4/1e4*(buy_price[tradable_points] + valid_sellprice[tradable_points]))/args.max_p
        else:
            tpb = np.load(abbr+str(args.profit_type)+"dout"+str(dout)+"tpb"+"_"+";".join(args.test4)+"std"+"_"+str(lag1)+str(lag2)+"train.npy")
            valid_sellprice = np.load(abbr+str(args.profit_type)+"dout"+str(dout)+"valid_sellprice"+"_"+";".join(args.test4)+"std"+"_"+str(lag1)+str(lag2)+".npy")
            buy_price = psu_env.buy_price_base
            buy_price = buy_price * (1-action/1e4) 
            tradable_points = np.logical_and(tpb <= buy_price-0.01, tpb != 0)
            tradable_points = np.logical_and(tradable_points, valid_sellprice!=0)
            profit[tradable_points] = (valid_sellprice[tradable_points] - buy_price[tradable_points] + 0.4/1e4*(buy_price[tradable_points] + valid_sellprice[tradable_points]))/args.max_p
        if args.test_clamp:
            profit[action>5] = 0
        if args.write_db:
            p, profit_pos, pos_dict, trades, position_np = calculate_profit_with_chosen_2(valid_sellpoint, profit, position=5, lag=lag1, lag2=lag2)
        else:
            print("why")
            p, profit_pos, pos_dict = calculate_profit_with_chosen_3(valid_sellpoint, profit, position=5, lag=lag1, lag2=lag2)
        print(p, profit_pos, pos_dict)
        print("for argmax sampler:", lag1, lag2, np.sum(profit_pos))
        if args.write_db:
            time_index = np.load(str(args.profit_type)+"dout4time"+"_"+";".join(args.test4)+"std"+".npy")
            import pandas as pd
            from influxdb import DataFrameClient
            client = DataFrameClient(args.ip, 8086, 'xz', 'xzquant2022', 'signal')
            data_1 = pd.DataFrame()
            b_ = 4564.07 if args.type == "buy" else 5371.64
            itemp = abbr+'2rl'+args.type+'profit_lag'+str(lag1)+str(lag2)
            itemp2 = abbr+'2rl'+args.type+'position_lag'+str(lag1)+str(lag2)
            itemp3 = abbr+'2rl'+args.type+'price'+str(lag1)+str(lag2)
            data_1[itemp2]=pd.DataFrame(position_np*5)
            data_1[itemp3]=pd.DataFrame(buy_price)
            data_1[itemp]=pd.DataFrame(np.cumsum(profit_pos).reshape(profit_pos.shape[0], 1)*args.max_p*5+b_)
            data_1['time'] = pd.DataFrame(time_index)
            data_1.index = data_1.time
            i = 0
            for i in range(1, int(len(data_1[[itemp]])//1e5)):
                print((i-1)*int(1e5), i*int(1e5))
                client.write_points(data_1[[itemp]][(i-1)*int(1e5):i*int(1e5)], itemp, {})
                client.write_points(data_1[[itemp2]][(i-1)*int(1e5):i*int(1e5)], itemp2, {})
                client.write_points(data_1[[itemp3]][(i-1)*int(1e5):i*int(1e5)], itemp3, {})

            print(i*int(1e5), len(data_1[[itemp]]))
            client.write_points(data_1[[itemp]][i*int(1e5):], itemp, {}) 
            client.write_points(data_1[[itemp2]][i*int(1e5):], itemp2, {}) 
            client.write_points(data_1[[itemp3]][i*int(1e5):], itemp3, {})

        lines_position = []
        
        for pos in [args.pos]:
            for j in range(0, args.d_num-1): 
                
                p, profit_fix_position, pos_dict = calculate_profit_with_chosen_3(valid_sellpoint, y0[:, j], position=5, lag=lag1, lag2=lag2)

                lines_position.append(np.cumsum(profit_fix_position))
            
        fig, ax1 = plt.subplots()
        fig.set_figwidth(16)
        fig.set_figheight(12)
        for j in range(args.start, args.d_num-1):
            ax1.plot(lines_position[j][::interval], label=str(j))
        ax1.plot(np.cumsum(profit_pos)[::interval], label="rl")
        plt.legend()
        plt.show()
        plt.savefig("results_new_3/result_"+args.arch+";".join(args.test4)+"RLfix"+args.type+"position"+str(5)+args.rand_number+str(lag1)+str(lag2)+".png")
        np.save("lines_poisiton.npy"+args.rand_number, lines_position)
        np.save("profit.npy"+args.rand_number, np.cumsum(profit_pos))
    
    exit(-1)

envs = getattr(gym.vector, args.synctype)(
    [make_env(num_envs=args.num_envs, test_field=args.train)] * args.num_envs,
)

obs = torch.zeros((args.num_steps, args.num_envs, args.input_size, args.T))
actions = torch.zeros((args.num_steps, args.num_envs, args.action_size))
logprobs = torch.zeros((args.num_steps, args.num_envs))
rewards = torch.zeros((args.num_steps, args.num_envs))
dones = torch.zeros((args.num_steps, args.num_envs))
execute_point = torch.zeros((args.num_steps, args.num_envs))
points = torch.zeros((args.num_steps, args.num_envs))

envs.reset()
ob = torch.Tensor(envs.reset()).cuda()
done = torch.zeros(args.num_envs)
max_p = np.zeros((4, ))
pathwise_p = np.zeros((epochs, 4))
max_p_sum = 0
max_p_itr_all = 0


def calculate_profit_2nd(action, length, lag1, lag2, test_field_2):
    action = action.cpu().detach().numpy()
    dout = 4
    m1, m2 = 2, 4
    returns, profit_position = np.zeros((length, )), np.zeros((length, ))
    y0 = np.load(str(args.profit_type)+"dout"+str(dout)+"y0"+"_"+";".join(test_field_2)+"std"+".npy")
    if args.type == "sell":
        buy_price_base = np.load(str(args.profit_type)+"dout"+str(dout)+"buy2nd_price_base"+"_"+";".join(test_field_2)+"std"+"_"+str(lag1)+str(lag2)+".npy")
        buy_price = buy_price_base * (1-action[:, 1]/1e4) 
        sell_price_base = np.load(str(args.profit_type)+"dout"+str(dout)+"sell_price_base"+"_"+";".join(test_field_2)+"std"+"_"+str(lag1)+str(lag2)+".npy")
        sell_price = sell_price_base * (1+action[:, 0]/1e4) 

        tps = np.load(str(args.profit_type)+"dout"+str(dout)+"tps"+"_"+";".join(test_field_2)+"std"+"_"+str(lag1)+str(lag2)+"train.npy")
        tpb = np.load(str(args.profit_type)+"dout"+str(dout)+"tpb2nd"+"_"+";".join(test_field_2)+"std"+"_"+str(lag1)+str(lag2)+".npy")
        
        valid_buypoint = np.logical_and(tpb <= buy_price-0.01, tpb != 0).nonzero()[0]
        valid_sellpoint = np.logical_and(tps >= sell_price+0.01, tps != 0).nonzero()[0]

        colored_valid_buypoint = [(vb, 0) for vb in valid_buypoint]
        colored_valid_sellpoint = [(vs, 1) for vs in valid_sellpoint]
        sorted_full_list = (colored_valid_buypoint + colored_valid_sellpoint).sort(key=take_first)
        position = 0
        position_list = []
        deferred_positions = []
        for vp in sorted_full_list:
            i = 0   
            retained_items = []
            for i in range(len(deferred_positions)):
                if vp[0] >= deferred_positions[i][0]:
                    if deferred_positions[i][1] == 1:
                        position_list.append(deferred_positions[i][0]-lag1)
                        position += 1
                    else:
                        print(position, len(position_list))
                        position = 0
                        for j in range(len(position_list)):
                            profit = (sell_price[position_list[j]] - buy_price[deferred_positions[i][0]-lag2] + 0.4/1e4*(sell_price[position_list[j]] + buy_price[deferred_positions[i][0]-lag2]))/args.max_p
                            returns[deferred_positions[i][0]-lag2] += 0.5 * profit
                            returns[position_list[j]] += 0.5 * profit
                            profit_position[deferred_positions[i][0]] += profit
                            del position_list[j]

                else:
                    retained_items.append(deferred_positions[i])
            deferred_positions = retained_items
            if vp[1] == 1:
                if position < 5:
                    deferred_positions.append((vp[0]+lag1, 1))
            if vp[1] == 0:
                if position != 0:
                    deferred_positions.append((vp[0]+lag2, 0))
    else:
        buy_price_base = np.load(str(args.profit_type)+"dout"+str(dout)+"buy_price_base"+"_"+";".join(test_field_2)+"std"+"_"+str(lag1)+str(lag2)+".npy")
        buy_price = buy_price_base * (1-action[:, 0]/1e4)
        sell_price_base = np.load(str(args.profit_type)+"dout"+str(dout)+"sell2nd_price_base"+"_"+";".join(test_field_2)+"std"+"_"+str(lag1)+str(lag2)+".npy")
        sell_price = sell_price_base * (1+action[:, 1]/1e4)
        tpb = np.load(str(args.profit_type)+"dout"+str(dout)+"tpb"+"_"+";".join(test_field_2)+"std"+"_"+str(lag1)+str(lag2)+".npy")
        tps = np.load(str(args.profit_type)+"dout"+str(dout)+"tps2nd"+"_"+";".join(test_field_2)+"std"+"_"+str(lag1)+str(lag2)+".npy")
        valid_buypoint = np.logical_and(tpb <= buy_price-0.01, tpb != 0).nonzero()[0]
        valid_sellpoint = np.logical_and(tps >= sell_price+0.01, tps != 0).nonzero()[0]
        colored_valid_buypoint = [(vb, 1) for vb in valid_buypoint]
        colored_valid_sellpoint = [(vs, 0) for vs in valid_sellpoint]
        sorted_full_list = (colored_valid_buypoint + colored_valid_sellpoint)
        sorted_full_list.sort(key=lambda x: (x[0],x[1]))
        position = 0
        position_list = []
        deferred_positions = []
        clear_list = []
        for vp in sorted_full_list:
            # print(vp)
            i = 0   
            retained_items = []
            for i in range(len(deferred_positions)):
                if vp[0] >= deferred_positions[i][0]:
                    if deferred_positions[i][1] == 1:
                        position_list.append(deferred_positions[i][0]-lag1)
                        position += 1
                    else:
                        # position = 0
                        # for j in range(len(position_list)):
                        #     profit = (sell_price[deferred_positions[i][0]-lag2] - buy_price[position_list[j]] + 0.4/1e4*(buy_price[position_list[j]] + sell_price[deferred_positions[i][0]-lag2]))/args.max_p
                        #     # if positinon_list[j] == 1010076:
                        #         # print("here!!!", profit, sell_price[deferred_positions[i][0]-lag2], deferred_positions[i][0]-lag2, buy_price[position_list[j]], position_list[j])
                        #         # exit(-1)
                        #     # returns[deferred_positions[i][0]-lag2] += profit
                        #     # returns[position_list[j]] += profit
                        #     returns[position_list[j]] += profit
                        #     profit_position[deferred_positions[i][0]] += profit
                        #     clear_list.append(deferred_positions[i][0]-lag2-position_list[j])
                        # position_list = []

                        if position > 0:
                            position -= 1
                            profit = (sell_price[deferred_positions[i][0]-lag2] - buy_price[position_list[0]] + 0.4/1e4*(buy_price[position_list[0]] + sell_price[deferred_positions[i][0]-lag2]))/args.max_p
                            returns[deferred_positions[i][0]-lag2] += 0.5 * profit
                            returns[position_list[0]] += 0.5 * profit
                            profit_position[deferred_positions[i][0]] += profit
                            clear_list.append(deferred_positions[i][0]-lag2-position_list[0])
                            del position_list[0]
                else:
                    retained_items.append(deferred_positions[i])
            deferred_positions = retained_items
            if vp[1] == 1:
                if position < 5:
                    deferred_positions.append((vp[0]+lag1, 1))
            if vp[1] == 0:
                if position > 0:
                    deferred_positions.append((vp[0]+lag2, 0))
    return torch.from_numpy(returns), profit_position

def calculate_train_RLd3_35(model, dataset, test_field="", argmax=False):
    model.eval()
    loader_seq = torch.utils.data.DataLoader(dataset, shuffle=False, sampler=torch.utils.data.SequentialSampler(dataset), batch_size=args.batch_size, num_workers=4, pin_memory=True)
    actions = torch.zeros((dataset.data_X.size(0), args.action_size)).cuda()
    logprobs = torch.zeros((dataset.data_X.size(0))).cuda()
    with torch.no_grad():
        start, end = 0, 0
        for i, (x, y, index, mask) in tqdm.tqdm(enumerate(loader_seq), ascii=True, total=len(loader_seq)):
            x = x.cuda()
            action, logprob = model.get_action(x, argmax=argmax)
            actions[index] = action
            logprobs[index] = logprob
    return dataset.data_X, actions.cpu().detach(), logprobs.cpu().detach()

def calculate_profit(action, length, test_field, valid_2ndsellpoint, rlbuy_profit_path, lag1, lag2, test_field_2):
    profit = np.zeros((length, ))
    psu_env = make_env(True, 0, test_field, 256, lag1, lag2)()
    valid_sellpoint = np.load(valid_2ndsellpoint+"_"+str(lag1)+str(lag2)+".npy")
    y0 = np.load(rlbuy_profit_path+"_"+str(lag1)+str(lag2)+".npy")
    dout = 4
    if args.type == "sell":
        tpb = np.load(str(args.profit_type)+"dout"+str(dout)+"tps"+"_"+";".join(test_field_2)+"std"+"_"+str(lag1)+str(lag2)+"train.npy")
        valid_sellprice = np.load(str(args.profit_type)+"dout"+str(dout)+"valid_buyprice"+"_"+";".join(test_field_2)+"std"+"_"+str(lag1)+str(lag2)+".npy")
        buy_price = psu_env.buy_price_base
        buy_price = buy_price * (1+action/1e4) 
        tradable_points = np.logical_and(tpb >= buy_price+0.01, tpb != 0)
        tradable_points = np.logical_and(tradable_points, valid_sellprice!=0)
        profit[tradable_points] = (buy_price[tradable_points] - valid_sellprice[tradable_points] + 0.4/1e4*(buy_price[tradable_points] + valid_sellprice[tradable_points]))/args.max_p
    else:
        tpb = np.load(str(args.profit_type)+"dout"+str(dout)+"tpb"+"_"+";".join(test_field_2)+"std"+"_"+str(lag1)+str(lag2)+"train.npy")
        valid_sellprice = np.load(str(args.profit_type)+"dout"+str(dout)+"valid_sellprice"+"_"+";".join(test_field_2)+"std"+"_"+str(lag1)+str(lag2)+".npy")
        buy_price = psu_env.buy_price_base
        buy_price = buy_price * (1-action/1e4) 
        tradable_points = np.logical_and(tpb <= buy_price-0.01, tpb != 0)
        tradable_points = np.logical_and(tradable_points, valid_sellprice!=0)
        profit[tradable_points] = (valid_sellprice[tradable_points] - buy_price[tradable_points] + 0.4/1e4*(buy_price[tradable_points] + valid_sellprice[tradable_points]))/args.max_p
    if args.test_clamp:
        profit[action>5] = 0
    return profit, valid_sellpoint, y0

for epoch in range(epochs):
    model.eval()
    if epoch >= args.start:
        _, action, _ = calculate_train_RLd3_35(model, stock.StockAggregate38("train", test_field=args.train), test_field=args.train, argmax=True)
        _, action2, _ = calculate_train_RLd3_35(model, stock.StockAggregate38("test", test_field=args.test), test_field=args.test, argmax=True)
        _, action3, _ = calculate_train_RLd3_35(model, stock.StockAggregate38("test2", test_field=args.test2), test_field=args.test2, argmax=True)
        _, action4, _ = calculate_train_RLd3_35(model, stock.StockAggregate38("test4", test_field=args.test4), test_field=args.test4, argmax=True)
        for lag1, lag2 in [(1, 1)]:
            returns, profit_tr = calculate_profit_2nd(transAct(action), stock.x.size(0), lag1, lag2, args.train)
            reward_sum = torch.sum(returns)
            print("for argmax sampler:", reward_sum)
            if lag1*lag2 == 1:
                wandb.log({"train/reward_sum": reward_sum}, step=epoch)
            else:
                wandb.log({"train/reward_sum"+str(lag1)+str(lag2): reward_sum}, step=epoch)
            
            returns, profit0 = calculate_profit_2nd(transAct(action2), stock.x2.size(0), lag1, lag2, args.test)
            reward_sum0 = torch.sum(returns)
            print("for argmax sampler:", reward_sum0)
            if lag1*lag2 == 1:
                wandb.log({"test/reward_sum": reward_sum0}, step=epoch)
            else:
                wandb.log({"test/reward_sum"+str(lag1)+str(lag2): reward_sum0}, step=epoch)
            

            returns, profit2 = calculate_profit_2nd(transAct(action3), stock.x3.size(0), lag1, lag2, args.test2)
            reward_sum2 = torch.sum(returns)
            print("for argmax sampler:", reward_sum2)
            if lag1*lag2 == 1:
                wandb.log({"test2/reward_sum": reward_sum2}, step=epoch)
            else:
                wandb.log({"test2/reward_sum"+str(lag1)+str(lag2): reward_sum2}, step=epoch)

            pathwise_p[epoch][2*(lag1-1)+lag2-1] = reward_sum2+reward_sum0

            best_epoch = False
            if reward_sum2+reward_sum0 >= max_p[2*(lag1-1)+lag2-1]:
                max_p[2*(lag1-1)+lag2-1] = reward_sum2+reward_sum0
                max_p_itr = epoch
                best_epoch = True
                torch.save(model, "results/best_model_RL"+args.arch+"_"+';'.join(args.train)+"_"+';'.join(args.test)+"_"+';'.join(args.test2)+args.rand_number+"lag"+str(lag1)+str(lag2)+".pt")
            print("max_p_itr, max_p, rand_number", max_p_itr, max_p, args.rand_number)
            
            returns, profit4 = calculate_profit_2nd(transAct(action4), stock.x4.size(0), lag1, lag2, args.test4)
            reward_sum = torch.sum(returns)
            print("for argmax sampler:", reward_sum)
            if lag1*lag2 == 1:
                wandb.log({"test4/reward_sum": reward_sum}, step=epoch)
                wandb.log({"test4+2/reward_sum": reward_sum+reward_sum2}, step=epoch) 
                wandb.log({"test4+2+0/reward_sum": reward_sum+reward_sum2+reward_sum0}, step=epoch) 
                wandb.log({"test2+0/reward_sum": reward_sum2+reward_sum0}, step=epoch) 
            else:
                wandb.log({"test4/reward_sum"+str(lag1)+str(lag2): reward_sum}, step=epoch)
                wandb.log({"test4+2/reward_sum"+str(lag1)+str(lag2): reward_sum+reward_sum2}, step=epoch) 
                wandb.log({"test4+2+0/reward_sum"+str(lag1)+str(lag2): reward_sum+reward_sum2+reward_sum0}, step=epoch) 
                wandb.log({"test2+0/reward_sum"+str(lag1)+str(lag2): reward_sum2+reward_sum0}, step=epoch) 

            if best_epoch:
                lines_position0 = []
                y0 = np.load(args.rlbuy_profit_path2+"_"+str(lag1)+str(lag2)+".npy")
                valid_sellpoint = np.load(args.valid_2ndsellpoint2+"_"+str(lag1)+str(lag2)+".npy")
                for pos in [args.pos]:
                    for j in range(0, args.d_num-1): 
                        p, profit_fix_position, pos_dict = calculate_profit_with_chosen(valid_sellpoint, y0[:, j], position=5, lag=lag1, lag2=lag2)
                        lines_position0.append(profit_fix_position)
                fig, ax1 = plt.subplots()
                fig.set_figwidth(16)
                fig.set_figheight(12)
                for j in range(args.start, args.d_num-1):
                    ax1.plot(np.cumsum(lines_position0[j])[::interval], label=str(j))
                ax1.plot(np.cumsum(profit0)[::interval], label="rl")
                plt.legend()
                plt.show()
                plt.savefig("results_new_2/result_"+args.arch+";".join(args.test)+"RLfix"+args.type+"position"+str(5)+args.rand_number+str(lag1)+str(lag2)+".png")
                plt.close('all')

                lines_position = []
                y0 = np.load(args.rlbuy_profit_path+"_"+str(lag1)+str(lag2)+".npy")
                valid_sellpoint = np.load(args.valid_2ndsellpoint+"_"+str(lag1)+str(lag2)+".npy")
                for pos in [args.pos]:
                    for j in range(0, args.d_num-1): 
                        p, profit_fix_position, pos_dict = calculate_profit_with_chosen(valid_sellpoint, y0[:, j], position=5, lag=lag1, lag2=lag2)
                        lines_position.append(profit_fix_position)
                fig, ax1 = plt.subplots()
                fig.set_figwidth(16)
                fig.set_figheight(12)
                for j in range(args.start, args.d_num-1):
                    ax1.plot(np.cumsum(lines_position[j])[::interval], label=str(j))
                ax1.plot(np.cumsum(profit_tr)[::interval], label="rl")
                plt.legend()
                plt.show()
                plt.savefig("results_new_2/result_"+args.arch+";".join(args.train)+"RLfix"+args.type+"position"+str(5)+args.rand_number+str(lag1)+str(lag2)+".png")
                plt.close('all')

                lines_position2 = []
                y0 = np.load(args.rlbuy_profit_path3+"_"+str(lag1)+str(lag2)+".npy")
                valid_sellpoint = np.load(args.valid_2ndsellpoint3+"_"+str(lag1)+str(lag2)+".npy")
                for pos in [args.pos]:
                    for j in range(0, args.d_num-1): 
                        p, profit_fix_position, pos_dict = calculate_profit_with_chosen(valid_sellpoint, y0[:, j], position=5, lag=lag1, lag2=lag2)
                        lines_position2.append(profit_fix_position)
                fig, ax1 = plt.subplots()
                fig.set_figwidth(16)
                fig.set_figheight(12)
                for j in range(args.start, args.d_num-1):
                    ax1.plot(np.cumsum(lines_position2[j])[::interval], label=str(j))
                ax1.plot(np.cumsum(profit2)[::interval], label="rl")
                plt.legend()
                plt.show()
                plt.savefig("results_new_2/result_"+args.arch+";".join(args.test2)+"RLfix"+args.type+"position"+str(5)+args.rand_number+str(lag1)+str(lag2)+".png")
                plt.close('all')

            if best_epoch:
                lines_position4 = []
                y0 = np.load(args.rlbuy_profit_path4+"_"+str(lag1)+str(lag2)+".npy")
                valid_sellpoint = np.load(args.valid_2ndsellpoint4+"_"+str(lag1)+str(lag2)+".npy")
                for pos in [args.pos]:
                    for j in range(0, args.d_num-1): 
                        p, profit_fix_position, pos_dict = calculate_profit_with_chosen(valid_sellpoint, y0[:, j], position=5, lag=lag1, lag2=lag2)
                        lines_position4.append(profit_fix_position)
                fig, ax1 = plt.subplots()
                fig.set_figwidth(16)
                fig.set_figheight(12)
                for j in range(args.start, args.d_num-1):
                    ax1.plot(np.cumsum(lines_position4[j])[::interval], label=str(j))
                ax1.plot(np.cumsum(profit4)[::interval], label="rl")
                plt.legend()
                plt.show()
                plt.savefig("results_new_2/result_"+args.arch+";".join(args.test4)+"RLfix"+args.type+"position"+str(5)+args.rand_number+str(lag1)+str(lag2)+".png")
                plt.close('all')

            if best_epoch:
                fig, ax1 = plt.subplots()
                fig.set_figwidth(16)
                fig.set_figheight(12)
                for j in range(args.start, args.d_num-1):
                    ax1.plot(np.cumsum(np.concatenate([lines_position2[j], lines_position4[j]], axis=0))[::interval], label=str(j))
                ax1.plot(np.cumsum(np.concatenate([profit2, profit4], axis=0))[::interval], label="rl")
                plt.legend()
                plt.show()
                plt.savefig("results_new_2/result_"+args.arch+";".join(args.test2)+";".join(args.test4)+"RLfix"+args.type+"position"+str(5)+args.rand_number+str(lag1)+str(lag2)+".png")
                plt.close('all')

                fig, ax1 = plt.subplots()
                fig.set_figwidth(16)
                fig.set_figheight(12)
                for j in range(args.start, args.d_num-1):
                    ax1.plot(np.cumsum(np.concatenate([lines_position0[j], lines_position2[j], lines_position4[j]], axis=0))[::interval], label=str(j))
                ax1.plot(np.cumsum(np.concatenate([profit0, profit2, profit4], axis=0))[::interval], label="rl")
                plt.legend()
                plt.show()
                plt.savefig("results_new_2/result_"+args.arch+";".join(args.test)+";".join(args.test2)+";".join(args.test4)+"RLfix"+args.type+"position"+str(5)+args.rand_number+str(lag1)+str(lag2)+".png")
                plt.close('all')

                fig, ax1 = plt.subplots()
                fig.set_figwidth(16)
                fig.set_figheight(12)
                for j in range(args.start, args.d_num-1):
                    ax1.plot(np.cumsum(np.concatenate([lines_position0[j], lines_position2[j]], axis=0))[::interval], label=str(j))
                ax1.plot(np.cumsum(np.concatenate([profit0, profit2], axis=0))[::interval], label="rl")
                plt.legend()
                plt.show()
                plt.savefig("results_new_2/result_"+args.arch+";".join(args.test)+";".join(args.test2)+"RLfix"+args.type+"position"+str(5)+args.rand_number+str(lag1)+str(lag2)+".png")
                plt.close('all')
            if lag1 == 2 and lag2 == 2 and np.sum(pathwise_p[epoch]) > max_p_sum:
                max_p_sum = np.sum(pathwise_p[epoch])
                max_p_itr_all = epoch
                torch.save(model, "results/best_model_RL"+args.arch+"_"+';'.join(args.train)+"_"+';'.join(args.test)+"_"+';'.join(args.test2)+args.rand_number+"epoch"+str(epoch)+"lagallavg.pt")

            print("All avg max_p_itr, max_p_sum, rand_number", max_p_itr_all, max_p_sum, args.rand_number)
    ob = torch.Tensor(envs.reset()).cuda()
    done = torch.zeros(args.num_envs)
    for step in range(0, args.num_steps):
        # print(step)
        args.step = step
        obs[step] = ob.detach().cpu()
        # print(obs[0].size(), ob.size())
        dones[step] = done 
        with torch.no_grad():
            action, logprob = model.get_action(ob)
            # print(action, logprob)
        actions[step] = action
        logprobs[step] = logprob

        ob, reward, done, info = envs.step(transAct(action).cpu().numpy())
        rewards[step] = torch.tensor(reward).cuda().view(-1)

        for i in range(len(info)):
            # print(i, info[i]["execute"])
            execute_point[step][i] = info[i]["execute"]
            points[step][i] = info[i]["full_range_step"]
            # print(info[i])
            if info[i]["execute"]:
                # print("1", rewards[info[i]["reward_back"][1]][i], reward[i], rewards[step][i])
                rewards[info[i]["reward_back"][1]][i] += reward[i]
                # print("2", rewards[info[i]["reward_back"][1]][i], reward[i], rewards[step][i])
                assert info[i]["reward_back"][0] == points[info[i]["reward_back"][1]][i]
                # print("3", rewards[info[i]["reward_back"][1]][i], rewards[step][i])
        ob, done = torch.Tensor(ob).cuda(), torch.Tensor(done)
    rewards = (rewards/stock.abs_profit-stock.mean_profit)/stock.std_profit

    with torch.no_grad():
        next_value = 0
        returns = torch.zeros_like(rewards)
        for t in reversed(range(args.num_steps)):
            if t == args.num_steps - 1:
                nextnonterminal = 1.0 - done
                next_return = next_value
            else:
                nextnonterminal = 1.0 - dones[t + 1]
                next_return = returns[t + 1]
            returns[t] = rewards[t] + args.gamma * nextnonterminal * next_return

    print("rewards, values", returns.mean(), rewards.mean())

    b_obs = obs.reshape((-1, args.input_size, args.T))
    b_logprobs = logprobs.reshape((-1))
    b_actions = actions.reshape((-1, args.action_size))
    b_returns = returns.reshape((-1))

    train_dataset = stock.StockAggregate36(b_obs, b_logprobs, b_actions, b_returns)
    train_loader = torch.utils.data.DataLoader(train_dataset, batch_size=args.batch_size, shuffle=True, num_workers=8)
    train(model, train_loader, opt, epoch)
    
