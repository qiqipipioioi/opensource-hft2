import datetime
from args import args

from pickletools import uint1
import re
import torch.utils.data as data
import torch
import numpy as np

from torch.utils.data import Dataset, DataLoader
from torch.utils.data.sampler import WeightedRandomSampler


def calculate_length(date_list, tp):
    start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
    print(start_month, start_day, end_month, end_day)
    start = datetime.date(2022,start_month,start_day)
    if end_month < start_month:
        year = 2023
    else:
        year = 2022
    end = datetime.date(year,end_month,end_day)
    print(start, end)
    total_length = 0
    for i in range((end-start).days+1):
        day = start + datetime.timedelta(days=i)
        print(day)
        month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
        day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
        total_length += np.load('data_6/'+tp+'_'+month_str+'_'+day_str+'.npy').astype(float).shape[0]
        print(total_length)
    return total_length


def combine_days_x(date_list, fp):
    start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
    print(start_month, start_day, end_month, end_day)
    start = datetime.date(2022,start_month,start_day)
    if end_month < start_month:
        year = 2023
    else:
        year = 2022
    end = datetime.date(year,end_month,end_day)
    print(start, end)
    start_index = 0
    for i in range((end-start).days+1):
        day = start + datetime.timedelta(days=i)
        print(day)
        month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
        day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day)
        xnn_i = np.load('data_6/'+"xnn5"+'_'+month_str+'_'+day_str+'.npy').astype(float)[:, :33]
        print("write", 0)
        fp[start_index: start_index+xnn_i.shape[0], :33] = xnn_i  
        print("write", 1) 
        fp.flush()
        x_i = np.load('data_6/'+"x2"+'_'+month_str+'_'+day_str+'.npy').astype(float)      
        print("write", 2) 
        fp[start_index: start_index+x_i.shape[0], 33:] = x_i   
        print("write", 3) 

        fp.flush()
   
        start_index += x_i.shape[0]

total_length = calculate_length(args.train[0], "y")
print(total_length)

fp = np.memmap("data_6/x2_all_"+args.train[0]+".npy", dtype='float32', mode='w+', shape=(total_length,601))
combine_days_x(args.train[0], fp)




def combine_days_y(date_list, tp):
    start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
    print(start_month, start_day, end_month, end_day)
    start = datetime.date(2022,start_month,start_day)
    if end_month < start_month:
        year = 2023
    else:
        year = 2022
    end = datetime.date(year,end_month,end_day)
    print(start, end)
    for i in range((end-start).days+1):
        day = start + datetime.timedelta(days=i)
        print(day)
        month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
        day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
        y_i = torch.from_numpy(np.load('data_6/'+tp+'_'+month_str+'_'+day_str+'.npy').astype(float))
        if i == 0:
            y_all = y_i
        else:
            y_all = torch.cat([y_all, y_i], dim=0)
    return y_all



y_all = combine_days_y(args.train[0], "y")
np.save("data_6/y_all_"+args.train[0]+".npy", y_all)
