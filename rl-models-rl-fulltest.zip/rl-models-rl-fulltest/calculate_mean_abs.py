import datetime
from args import args

from pickletools import uint1
import re
import torch.utils.data as data
import torch
import numpy as np

from torch.utils.data import Dataset, DataLoader
from torch.utils.data.sampler import WeightedRandomSampler

def calculate_abs_v(date_list, tp):
    start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
    print(start_month, start_day, end_month, end_day)
    start = datetime.date(2022,start_month,start_day)
    end = datetime.date(2022,end_month,end_day)
    print(start, end)
    # x_l = []
    for i in range((end-start).days+1):
        day = start + datetime.timedelta(days=i)
        print(day)
        month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
        day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
        x_i = np.load('data_6/'+tp+'_'+month_str+'_'+day_str+'.npy', mmap_mode="r")
        # x_l.append(x_i)
        x_i_abs_v = np.amax(np.abs(x_i), axis=0).reshape((1, x_i.shape[1]))
        if i != 0:
            # print(np.concatenate([x_i_abs_v, abs_v],axis=0).shape)
            abs_v = np.amax(np.concatenate([x_i_abs_v, abs_v], axis=0), axis=0).reshape((1, x_i.shape[1]))
            # print(x_i_abs_v, abs_v)
        else:
            abs_v = x_i_abs_v
        # print(x_i_abs_v.shape, abs_v.shape)
    # print("True abs", np.amax(np.abs(np.concatenate(x_l, axis=0)), axis=0))
    # print("Another abs", abs_v)
    abs_v[abs_v==0] = 1
    print(abs_v)
    return abs_v

def calculate_mean(date_list, tp, abs_v):
    start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
    print(start_month, start_day, end_month, end_day)
    start = datetime.date(2022,start_month,start_day)
    end = datetime.date(2022,end_month,end_day)
    print(start, end)
    # x_l = []
    # mean_l = []
    # nums_l = []
    sum_tensor = 0
    sum_nums = 0
    for i in range((end-start).days+1):
        day = start + datetime.timedelta(days=i)
        # print(day)
        month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
        day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
        x_i = np.load('data_6/'+tp+'_'+month_str+'_'+day_str+'.npy', mmap_mode="r")/abs_v
        print("what is shape", x_i.shape)
        # x_l.append(x_i)
        # nums_l.append(x_i.shape[0])
        # mean_l.append(np.mean(x_i, axis=0))
        sum_tensor += x_i.shape[0]*np.mean(x_i, axis=0)
        sum_nums += x_i.shape[0]
        # print(nums_l, mean_l, sum_tensor, sum_nums)
    # print("real mean:", np.mean(np.concatenate(x_l, axis=0), axis=0))
    # print("real std:", np.std(np.concatenate(x_l, axis=0), axis=0))
    # print("real std:", torch.std(torch.from_numpy(np.concatenate(x_l, axis=0)), 0))

    return sum_tensor/sum_nums

def calculate_std(date_list, tp, abs_v, mean):
    start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
    print(start_month, start_day, end_month, end_day)
    start = datetime.date(2022,start_month,start_day)
    end = datetime.date(2022,end_month,end_day)
    print(start, end)
    # nums_l = []
    sum_tensor = 0
    sum_nums = 0
    for i in range((end-start).days+1):
        day = start + datetime.timedelta(days=i)
        print(day)
        month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
        day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
        x_i = np.load('data_6/'+tp+'_'+month_str+'_'+day_str+'.npy', mmap_mode="r")
        print("what is shape", x_i.shape)
        # nums_l.append(x_i.shape[0])
        # print(x_i.shape, mean.shape)
        # print((x_i-mean)[0].shape)
        # print((x_i-mean)[0]+mean, x_i[0])
        sum_tensor += x_i.shape[0]*np.mean((x_i/abs_v-mean)**2, axis=0)
        sum_nums += x_i.shape[0]
        # print(nums_l, sum_tensor, sum_nums)
    # print("calculate_std", (sum_tensor/sum_nums)**0.5)
    return  (sum_tensor/sum_nums)**0.5

abs_v = calculate_abs_v(args.train[0], "xnn")
print(abs_v.shape)
mean = calculate_mean(args.train[0], "xnn", abs_v)
std = calculate_std(args.train[0], "xnn", abs_v, mean)
print(abs_v, mean, std)

np.save('data_6/abs_v_xnn'+args.train[0], abs_v)
np.save('data_6/mean_xnn'+args.train[0], mean)
np.save('data_6/std_xnn'+args.train[0], std)

abs_v = calculate_abs_v(args.train[0], "x")
mean = calculate_mean(args.train[0], "x", abs_v)
std = calculate_std(args.train[0], "x", abs_v, mean)

np.save('data_6/abs_v_x'+args.train[0], abs_v)
np.save('data_6/mean_x'+args.train[0], mean)
np.save('data_6/std_x'+args.train[0], std)

abs_v = calculate_abs_v(args.train[0], "xabs")
mean = calculate_mean(args.train[0], "xabs", abs_v)
std = calculate_std(args.train[0], "xabs", abs_v, mean)

np.save('data_6/abs_v_xabs'+args.train[0], abs_v)
np.save('data_6/mean_xabs'+args.train[0], mean)
np.save('data_6/std_xabs'+args.train[0], std)



