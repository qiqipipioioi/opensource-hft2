import torch
import models
from args import args
args.temp = 1
# model = torch.load("best_model_y"+args.arch+args.y+"_"+';'.join(args.train)+"_"+';'.join(args.test)+str(args.seed)+".pt")
model = torch.load("results/best_model_RLTSTransformerEncoderRLSeq3_08_11-10_20_10_21-10_25_10_27-11_081670137302.338087epoch38lagallavg.pt")
model = model.actor_mean
model.eval()
model.cpu()
input = torch.ones(1, args.input_size, args.T)
traced_script_module = torch.jit.trace(model, input)
print(model(input), model(input).size())
# traced_script_module.save("best_model_y"+args.arch+args.y+"_"+";".join(args.train)+"_"+";".join(args.test)+str(args.seed)+"script.pt")
traced_script_module.save("results_new_3/best_model_RLTSTransformerEncoderRLSeq3_08_11-10_20_10_21-10_25_10_27-11_081670137302.338087epoch38lagallavg_script.pt")